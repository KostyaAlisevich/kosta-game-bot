import asyncio
from sim import Sim, OWNER, CHAT_BASE
from app.vk import VKAPIError

CHAT = CHAT_BASE + 5


async def main():
    s = await Sim.create()

    # ===== личные сообщения: /start и меню =====
    ev = await s.say(1, '/start')
    assert s.vk.cleared == [1], 'старая нижняя клавиатура должна быть убрана при первом контакте'
    m = ev[-1]
    assert 'Добро пожаловать' in m.text and '5 000 ₽' in m.text and '[id1|Юзер1]' in m.text
    assert len(m.buttons()) == 10 and '💰 Кошелёк' in m.labels()
    ev = await s.say(1, '/menu')
    assert s.vk.cleared == [1], 'клавиатура очищается один раз'
    assert 'Главное меню' in ev[-1].text and 'личные сообщения' in ev[-1].text
    assert (await s.db.fetchrow('SELECT role, dm_ok FROM users WHERE id=1')) == {'role': 0, 'dm_ok': 1}
    # команды без префикса в личке работают; ё/е не различаются
    assert 'Главное меню' in (await s.last(1, 'меню')).text
    assert 'Главное меню' in (await s.last(1, '/Меню')).text
    print('OK  /start и меню в личных сообщениях, очистка старой клавиатуры, команды без префикса')

    # неизвестный текст
    ev = await s.say(1, 'абракадабра')
    assert 'Не понял' in ev[-1].text and ev[-1].find('Меню')
    assert await s.say(1, 'ещё что-то') == [], 'подсказка не чаще раза в 30 секунд'
    print('OK  непонятный текст -> подсказка (с троттлингом)')

    # владелец автоматически получает высшую должность
    await s.say(OWNER, '/start')
    assert (await s.db.fetchrow('SELECT role FROM users WHERE id=$1', OWNER))['role'] == 8
    print('OK  основатель (ADMIN_ID) получает должность 8')

    # ===== бан в боте =====
    await s.say(2, '/start')
    await s.db.execute("UPDATE users SET banned=1, ban_reason='спам' WHERE id=2")
    ev = await s.say(2, '/menu')
    assert 'заблокирован' in ev[-1].text and 'спам' in ev[-1].text
    assert await s.say(2, '/menu') == [], 'повторное уведомление о бане не чаще раза в 10 минут'
    print('OK  заблокированный пользователь не может пользоваться ботом')

    # ===== беседа: бота добавили =====
    ev = await s.say(10, '', peer=CHAT, action={'type': 'chat_invite_user', 'member_id': -777})
    assert 'Выдайте мне права администратора' in ev[-1].text and ev[-1].find('Активировать')
    # пока не активирована - только подсказка
    ev = await s.say(10, '/menu', peer=CHAT)
    assert 'не активирован' in ev[-1].text
    assert await s.say(10, '/menu', peer=CHAT) == [], 'подсказка не чаще раза в 2 минуты'
    # приглашён не наш бот / другой человек - событие не обрабатывается
    assert await s.say(10, '', peer=CHAT, action={'type': 'chat_invite_user', 'member_id': -555}) == []
    print('OK  бот добавлен в беседу: приветствие с кнопкой активации; до активации команды не работают')

    # ===== активация =====
    s.vk.members_error.add(CHAT)
    ev = await s.say(10, '/start', peer=CHAT)
    assert 'выдайте боту права администратора' in ev[-1].text
    s.vk.members_error.discard(CHAT)
    s.vk.members_by_peer[CHAT] = [
        {'id': 10, 'admin': True, 'owner': True}, {'id': 11, 'admin': True, 'owner': False},
        {'id': 12, 'admin': False, 'owner': False}, {'id': -777, 'admin': True, 'owner': False}]
    ev = await s.say(12, '/start', peer=CHAT)
    assert 'только создатель или администратор' in ev[-1].text
    ev = await s.say(10, '/start', peer=CHAT)
    assert 'Бот активирован' in ev[-1].text and 'Создатель' in ev[-1].text and 'Администраторов: 1' in ev[-1].text
    roles = {r['user_id']: r['role'] for r in await s.db.fetch('SELECT user_id, role FROM chat_members WHERE peer_id=$1', CHAT)}
    assert roles == {10: 100, 11: 90}, roles
    assert (await s.db.fetchrow('SELECT activated FROM chats WHERE peer_id=$1', CHAT))['activated'] == 1
    print('OK  активация: создатель -> роль 100, администратор -> 90, остальные без роли; не-админ активировать не может')

    # повторный /start не понижает вручную выданную роль
    await s.db.execute('UPDATE chat_members SET role=95 WHERE peer_id=$1 AND user_id=11', CHAT)
    ev = await s.say(11, '/start', peer=CHAT)
    assert 'синхронизированы' in ev[-1].text
    assert (await s.db.fetchrow('SELECT role FROM chat_members WHERE peer_id=$1 AND user_id=11', CHAT))['role'] == 95
    print('OK  повторный /start синхронизирует роли, не понижая выданные вручную')

    # ===== в беседе меню работает, префиксы / и ! =====
    ev = await s.say(12, '/menu', peer=CHAT)
    assert 'эта беседа' in ev[-1].text
    ev = await s.say(12, '!меню', peer=CHAT)
    assert 'Главное меню' in ev[-1].text
    assert await s.say(12, 'меню', peer=CHAT) == [], 'в беседе без префикса команды не срабатывают'
    ev = await s.say(12, '[club777|@bot] /меню', peer=CHAT)
    assert 'Главное меню' in ev[-1].text, 'обращение через упоминание бота'
    print('OK  в беседе: префиксы / и !, обращение через упоминание, без префикса - игнор')

    # ===== кнопки: чужие нажимать не могут, свои редактируют сообщение =====
    msg = (await s.say(12, '/menu', peer=CHAT))[-1]
    n_before = len(s.peer_msgs(CHAT))
    res = await s.press(13, 'Помощь', peer=CHAT, msg=msg)
    assert s.vk.answers[-1] == (13, 'Эта кнопка предназначена не для вас')
    assert len(s.peer_msgs(CHAT)) == n_before
    res = await s.press(12, 'Помощь', peer=CHAT, msg=msg)
    assert res is msg and msg.version == 1 and 'Команды пользователя' in msg.text, 'своя кнопка редактирует то же сообщение'
    assert len(s.peer_msgs(CHAT)) == n_before
    print('OK  чужая кнопка отклоняется, своя редактирует сообщение на месте')

    # ===== бота удалили из беседы =====
    await s.say(10, '', peer=CHAT, action={'type': 'chat_kick_user', 'member_id': -777})
    assert (await s.db.fetchrow('SELECT activated FROM chats WHERE peer_id=$1', CHAT))['activated'] == 0
    print('OK  бота удалили из беседы - она деактивируется')

    print('\nВсе тесты start пройдены')

asyncio.run(main())
