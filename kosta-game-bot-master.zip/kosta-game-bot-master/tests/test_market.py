import asyncio
import math
import random
from sim import Sim, OWNER
from app.data.market import TICKERS, TRADABLE
from app.services import accounts, market_engine


async def main():
    s = await Sim.create()
    await s.say(1, '/start')
    db = s.db

    # ===== движок цен =====
    px0 = await market_engine.prices(db)
    assert len(px0) == len(TICKERS) and px0['BTC'] == 6_000_000 and px0['USD'] == 90
    rng = random.Random(7)
    events_total = 0
    t0 = accounts.now()
    for i in range(600):
        ev = await market_engine.tick(db, rng, ts=t0 + i * 300)
        events_total += len(ev)
    px = await market_engine.prices(db)
    for tk in TICKERS:
        assert tk.base * 0.2 <= px[tk.symbol] <= tk.base * 5, (tk.symbol, px[tk.symbol])
        assert px[tk.symbol] != tk.base
    assert 10 <= events_total <= 45, f'ожидается около 4% от 600 шагов, получили {events_total}'
    news = await db.fetch('SELECT * FROM market_news')
    assert len(news) == events_total and all(abs(n['pct']) >= 4 for n in news)
    hist = await db.fetchval("SELECT COUNT(*) FROM market_history WHERE symbol='BTC'")
    assert hist <= 26 * 12 + 2, 'старая история должна удаляться (хранится ~26 часов)'
    print(f'OK  движок цен: 600 шагов, цены в границах, событий {events_total}, история обрезается ({hist} точек)')
    await market_engine.seed_market(db)   # повторная инициализация ничего не ломает
    vol = [abs(math.log(px[t.symbol] / t.base)) for t in TRADABLE]
    assert max(vol) < math.log(5)

    # цены на старт тестов: обнуляем и делаем предсказуемыми
    await db.execute('DELETE FROM market_news')
    await db.execute('DELETE FROM market_history')
    now = accounts.now()
    for sym, price in {'NFTX': 100.0, 'BTC': 1_000_000.0, 'GRNB': 320.0, 'USD': 90.0, 'EUR': 98.0}.items():
        await db.execute('UPDATE market_prices SET price=$2, base=$2 WHERE symbol=$1', sym, price)
    for i in range(24):    # история за сутки: цена NFTX росла от 80 до 100
        await db.execute("INSERT INTO market_history (symbol, ts, price) VALUES ('NFTX', $1, $2)", now - (23 - i) * 3600, 80 + i * 20 / 23)
        await db.execute("INSERT INTO market_history (symbol, ts, price) VALUES ('BTC', $1, $2)", now - (23 - i) * 3600, 1_000_000)

    # ===== обзор и списки =====
    m = await s.last(1, '/рынок')
    assert 'Индекс акций' in m.text and 'Лидеры роста' in m.text and m.find('Акции') and m.find('Крипта')
    m = await s.last(1, '/акции')
    assert 'Акции | стр. 1/2' in m.text and 'NFTX' in m.text and len(m.buttons()) <= 10
    m = await s.press(1, '▶'); assert 'стр. 2/2' in m.text
    m = await s.last(1, '/крипта')
    assert 'BTC' in m.text and 'DOGE' in m.text and 'стр. 1/1' in m.text
    for alias in ('/биржа', '/market', '/stocks', '/crypto', '/крипто', '/криптовалюта'):
        await s.last(1, alias)
    print('OK  /рынок, /акции, /крипта и псевдонимы, страницы')

    # ===== график / карточка =====
    m = await s.last(1, '/график NFTX')
    assert 'NFTX · НефтьГаз' in m.text and '100 ₽' in m.text and '+25.00%' in m.text and '▁' in m.text and '█' in m.text
    assert 'Мин: 80 ₽ · Макс: 100 ₽' in m.text and m.find('Купить 1 000') and m.find('Продать всё')
    assert 'BTC' in (await s.last(1, '/chart биткоин')).text and 'Укажите бумагу' in (await s.last(1, '/график')).text
    assert 'Укажите бумагу' in (await s.last(1, '/график USD')).text, 'валюты на бирже не торгуются'
    print('OK  /график: цена, изменение за сутки, спарклайн, мин/макс, алиасы тикеров')

    # ===== покупка =====
    await s.give(1, rub=100_000)
    m = await s.last(1, '/купить NFTX 10')
    cost = math.ceil(10 * 100 * 1.002)             # 1002
    assert 'Покупка выполнена' in m.text and f'Списано: {cost:,} ₽'.replace(',', ' ') in m.text, m.text
    assert (await s.wallet(1))['rub'] == 100_000 - cost
    h = await db.fetchrow("SELECT * FROM holdings WHERE user_id=1 AND symbol='NFTX'")
    assert h['qty'] == 10 and h['invested'] == cost
    m = await s.last(1, '/купить NFTX на 5000')                 # 5000 / 100.2 = 49.9 -> 49 шт.
    h = await db.fetchrow("SELECT * FROM holdings WHERE user_id=1 AND symbol='NFTX'")
    assert h['qty'] == 59, h
    m = await s.last(1, '/chart NFTX')
    m = await s.press(1, '10 000 ₽')
    assert (await db.fetchrow("SELECT qty FROM holdings WHERE user_id=1 AND symbol='NFTX'"))['qty'] == 59 + 99
    print('OK  покупка акций: по количеству, на сумму (целые штуки), кнопкой; комиссия 0,2%')

    # криптовалюта дробными долями
    m = await s.last(1, '/купить BTC на 50000')
    q = await db.fetchval("SELECT qty FROM holdings WHERE user_id=1 AND symbol='BTC'")
    assert abs(q - math.floor(50000 / (1_000_000 * 1.002) * 1e6) / 1e6) < 1e-12 and 0.049 < q < 0.05, q
    m = await s.last(1, '/купить доге 100')
    assert 'Недостаточно средств' in (await s.last(1, '/купить BTC 5')).text
    assert 'минимальную долю' in (await s.last(1, '/купить NFTX на 50')).text     # акции только целыми штуками
    assert 'Формат' in (await s.last(1, '/купить')).text and 'Формат' in (await s.last(1, '/купить NFTX')).text
    assert 'Формат' in (await s.last(1, '/купить XXX 5')).text
    print('OK  крипта дробными долями, ошибки ввода, нехватка денег, минимальная доля')

    # ===== портфель =====
    m = await s.last(1, '/портфель')
    assert 'NFTX' in m.text and 'BTC' in m.text and 'Стоимость портфеля' in m.text and 'Свободные деньги' in m.text
    assert m.find('NFTX') and len(m.buttons()) <= 10
    print('OK  /портфель')

    # ===== продажа =====
    bal = (await s.wallet(1))['rub']
    m = await s.last(1, '/продать NFTX 8')
    assert 'Продажа выполнена' in m.text
    got = math.floor(8 * 100 * 0.998)
    assert (await s.wallet(1))['rub'] == bal + got
    h = await db.fetchrow("SELECT * FROM holdings WHERE user_id=1 AND symbol='NFTX'")
    assert h['qty'] == 158 - 8
    m = await s.last(1, '/продать NFTX 50%')
    assert (await db.fetchrow("SELECT qty FROM holdings WHERE user_id=1 AND symbol='NFTX'"))['qty'] == 75
    m = await s.last(1, '/продать NFTX все')
    assert not await db.fetchrow("SELECT 1 FROM holdings WHERE user_id=1 AND symbol='NFTX'"), 'пустая позиция удаляется'
    assert 'нет NFTX' in (await s.last(1, '/продать NFTX 1')).text
    assert 'только' in (await s.last(1, '/продать BTC 99')).text
    assert 'Укажите количество' in (await s.last(1, '/продать BTC abc')).text
    print('OK  продажа: количество, процент, всё; позиция удаляется; ошибки')

    # ===== прибыль/убыток =====
    await db.execute("UPDATE market_prices SET price=200.0 WHERE symbol='NFTX'")
    await s.last(1, '/купить NFTX 10')                          # по 200
    await db.execute("UPDATE market_prices SET price=300.0 WHERE symbol='NFTX'")
    m = await s.last(1, '/продать NFTX все')
    assert 'Результат сделки: +' in m.text
    pnl = math.floor(10 * 300 * 0.998) - math.ceil(10 * 200 * 1.002)
    assert f'+{pnl:,} ₽'.replace(',', ' ') in m.text, m.text
    print('OK  результат сделки считается от цены покупки')

    # ===== беседа: отдельный портфель =====
    from sim import CHAT_BASE
    CH = CHAT_BASE + 4
    await s.make_chat(CH, creator=10, members=(1,))
    await s.last(1, '/купить NFTX 3', peer=CH)
    assert await db.fetchval("SELECT qty FROM holdings WHERE scope=$1 AND user_id=1 AND symbol='NFTX'", CH) == 3
    assert not await db.fetchrow("SELECT 1 FROM holdings WHERE scope=0 AND user_id=1 AND symbol='NFTX'")
    print('OK  в беседе свой портфель; цены общие')

    # ===== параллельная продажа =====
    await s.say(2, '/start'); await s.give(2, rub=100_000)
    await s.last(2, '/купить NFTX 100')
    from app.modules import market
    await asyncio.gather(*[s.say(2, '/продать NFTX все') for _ in range(4)])
    assert not await db.fetchrow("SELECT 1 FROM holdings WHERE user_id=2"), 'продано'
    w = (await s.wallet(2))['rub']
    assert w == 100_000 - math.ceil(100 * 300 * 1.002) + math.floor(100 * 300 * 0.998), 'выручка получена один раз'
    print('OK  повторные продажи подряд не дают двойной выручки')

    # ===== новости =====
    assert 'Пока тихо' in (await s.last(1, '/новости')).text
    await db.execute("INSERT INTO market_news (ts, symbol, pct, text) VALUES ($1, 'NFTX', 7.5, 'НефтьГаз: подписан выгодный контракт')", accounts.now() - 120)
    await db.execute("INSERT INTO market_news (ts, symbol, pct, text) VALUES ($1, 'BTC', -5.0, 'Bitcoin: ужесточение регулирования')", accounts.now() - 7300)
    m = await s.last(1, '/news')
    assert '+7.50%' in m.text and '−' not in m.text and '-5.00%' in m.text and '2 мин назад' in m.text and '2 ч назад' in m.text
    m = await s.last(1, '/рынок')
    assert 'Последние события' in m.text and 'контракт' in m.text
    print('OK  /новости и блок событий в /рынок')

    print('\nВсе тесты market пройдены')

asyncio.run(main())
