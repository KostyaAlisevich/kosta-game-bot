"""Симулятор для тестов: заглушка ВК + «пользователь пишет сообщение / нажимает кнопку»."""
import asyncio
import json
import sys
from pathlib import Path
from collections import defaultdict
from dataclasses import dataclass, field

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'tests'))

from app.config import CHAT_BASE  # noqa: E402
from app.db import init_schema  # noqa: E402
from app.framework.app import App  # noqa: E402
from app.framework.dispatcher import handle_event, handle_message  # noqa: E402
from app.framework.events import ButtonEvent, Incoming  # noqa: E402
from app.framework.registry import registry  # noqa: E402
from app.vk import VKAPIError  # noqa: E402
from sqlite_db import SqliteDatabase  # noqa: E402

OWNER = 1000


@dataclass
class Msg:
    peer: int
    cmid: int
    text: str
    kb: dict | None
    version: int = 0

    def buttons(self):
        if not self.kb:
            return []
        return [b for row in self.kb['buttons'] for b in row]

    def labels(self):
        return [b['action']['label'] for b in self.buttons()]

    def find(self, part):
        for b in self.buttons():
            if part in b['action']['label']:
                return b
        return None


class FakeVK:
    def __init__(self):
        self.msgs: dict[tuple, Msg] = {}
        self.events: list[Msg] = []
        self.counter = defaultdict(int)
        self.users: dict[int, str] = {}
        self.auto_users = True
        self.screen: dict[str, int] = {}
        self.members_by_peer: dict[int, list] = {}
        self.members_error: set = set()
        self.kicked: list = []
        self.deleted: list = []
        self.cleared: list = []
        self.answers: list = []
        self.blocked: set = set()
        self.kick_fail: set = set()
        self.gid = 777

    # --- API ---
    async def send(self, peer_id, text, keyboard=None):
        if peer_id in self.blocked:
            return False
        self.counter[peer_id] += 1
        m = Msg(peer_id, self.counter[peer_id], text, json.loads(keyboard) if keyboard else None)
        self.msgs[(peer_id, m.cmid)] = m
        self.events.append(m)
        assert len(text) <= 4000, f'сообщение длиннее лимита: {len(text)}'
        if m.kb:
            n = sum(len(r) for r in m.kb['buttons'])
            assert n <= 10, f'в inline-клавиатуре {n} кнопок (>10): {m.labels()}'
            assert len(m.kb['buttons']) <= 6
            for b in m.buttons():
                assert len(b['action']['label']) <= 40 and len(b['action']['payload'].encode()) <= 255
        return True

    async def clear_reply_keyboard(self, peer_id, text):
        self.cleared.append(peer_id)
        return await self.send(peer_id, text)

    async def edit(self, peer_id, cmid, text, keyboard=None):
        m = self.msgs.get((peer_id, cmid))
        if m is None:
            return False
        m.text, m.kb = text, (json.loads(keyboard) if keyboard else m.kb)
        m.version += 1
        self.events.append(m)
        assert len(text) <= 4000
        if m.kb:
            n = sum(len(r) for r in m.kb['buttons'])
            assert n <= 10, f'в inline-клавиатуре {n} кнопок (>10): {m.labels()}'
        return True

    async def event_answer(self, event_id, user_id, peer_id, text=None):
        self.answers.append((user_id, text))

    async def delete(self, peer_id, cmid):
        self.deleted.append((peer_id, cmid))
        return True

    async def kick(self, peer_id, user_id):
        if user_id in self.kick_fail:
            return False
        self.kicked.append((peer_id, user_id))
        return True

    async def members(self, peer_id):
        if peer_id in self.members_error:
            raise VKAPIError('917 no access to chat')
        return self.members_by_peer.get(peer_id, [])

    async def names(self, ids):
        out = {}
        for i in ids:
            if i in self.users:
                out[i] = self.users[i]
            elif self.auto_users and 0 < i < 10**9:
                out[i] = f'Юзер{i}'
        return out

    async def resolve(self, screen_name):
        return self.screen.get(screen_name)

    async def group_id(self):
        return self.gid


class Sim:
    def __init__(self):
        self.vk = FakeVK()
        self.db = SqliteDatabase()
        self.app = App(self.db, self.vk, registry, admin_id=OWNER, limiter=None)
        self.cmid = defaultdict(int)

    @classmethod
    async def create(cls):
        import app.modules  # noqa: F401  (регистрирует все команды)
        sim = cls()
        await init_schema(sim.db)
        from app.modules import load_all
        await load_all(sim.app)
        return sim

    # --- действия пользователей ---
    async def say(self, uid, text, peer=None, reply_from=None, fwd=None, action=None, payload=None):
        peer = peer or uid
        self.cmid[peer] += 1
        before = len(self.vk.events)
        await handle_message(self.app, Incoming(
            peer_id=peer, from_id=uid, text=text, cmid=self.cmid[peer],
            reply_from=reply_from, fwd_from=fwd or [], action=action, payload=payload))
        return self.vk.events[before:]

    async def last(self, uid, text, peer=None, **kw):
        events = await self.say(uid, text, peer, **kw)
        assert events, f'на «{text}» бот ничего не ответил'
        return events[-1]

    def latest_msg_with(self, peer, label_part):
        for (p, _), m in sorted(self.vk.msgs.items(), key=lambda kv: kv[0][1], reverse=True):
            if p == peer and m.find(label_part):
                return m
        return None

    async def press(self, uid, label_part, peer=None, msg=None):
        peer = peer or uid
        msg = msg or self.latest_msg_with(peer, label_part)
        assert msg is not None, f'нет кнопки «{label_part}» в беседе {peer}'
        b = msg.find(label_part)
        assert b is not None, f'в сообщении нет кнопки «{label_part}»: {msg.labels()}'
        before = len(self.vk.events)
        await handle_event(self.app, ButtonEvent(
            peer_id=peer, user_id=uid, cmid=msg.cmid, event_id='ev', payload=json.loads(b['action']['payload'])))
        events = self.vk.events[before:]
        return events[-1] if events else None

    async def cb(self, uid, cmd, args='', peer=None):
        """Нажатие кнопки по ключу команды (для служебных команд, которых нет в тексте)."""
        peer = peer or uid
        before = len(self.vk.events)
        await handle_event(self.app, ButtonEvent(
            peer_id=peer, user_id=uid, cmid=None, event_id='ev', payload={'c': cmd, 'a': args, 'u': uid}))
        events = self.vk.events[before:]
        return events[-1] if events else None

    def peer_msgs(self, peer):
        return [m for (p, _), m in sorted(self.vk.msgs.items(), key=lambda kv: kv[0][1]) if p == peer]

    # --- удобства ---
    async def wallet(self, uid, scope=0):
        return await self.db.fetchrow('SELECT * FROM wallets WHERE scope=$1 AND user_id=$2', scope, uid)

    async def set_role(self, uid, role):
        await self.say(uid, '/menu') if not await self.db.fetchrow('SELECT 1 FROM users WHERE id=$1', uid) else None
        await self.db.execute('UPDATE users SET role=$2 WHERE id=$1', uid, role)

    async def give(self, uid, rub=None, scope=0, **cols):
        await self.app.db.execute(
            'INSERT INTO wallets (scope, user_id, rub, created_at) VALUES ($1,$2,0,0) ON CONFLICT (scope, user_id) DO NOTHING',
            scope, uid)
        if rub is not None:
            cols['rub'] = rub
        for k, v in cols.items():
            await self.db.execute(f'UPDATE wallets SET {k}=$3 WHERE scope=$1 AND user_id=$2', scope, uid, v)

    async def chat_role(self, peer, uid, level):
        await self.db.execute(
            'INSERT INTO chat_members (peer_id, user_id, role) VALUES ($1, $2, $3) '
            'ON CONFLICT (peer_id, user_id) DO UPDATE SET role = EXCLUDED.role', peer, uid, level)

    async def make_chat(self, peer, creator, admins=(), members=()):
        """Активированная беседа: создатель получает 100, админы 90."""
        lst = [{'id': creator, 'admin': True, 'owner': True}]
        lst += [{'id': a, 'admin': True, 'owner': False} for a in admins]
        lst += [{'id': m, 'admin': False, 'owner': False} for m in members]
        self.vk.members_by_peer[peer] = lst
        events = await self.say(creator, '/start', peer=peer)
        return events
