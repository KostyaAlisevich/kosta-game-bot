import asyncio
from sim import Sim, OWNER, CHAT_BASE
from app.data.assets import ITEMS, ITEMS_BY_KEY, CATEGORIES, ITEMS_BY_CATEGORY
from app.services import accounts

CHAT = CHAT_BASE + 11


async def main():
    s = await Sim.create()
    await s.say(1, '/start')

    # ===== пустое состояние =====
    m = await s.last(1, '/бизнес')
    assert 'нет бизнесов' in m.text and m.find('Бизнесы') and m.find('Майнинг')
    assert 'нет источников дохода' in (await s.last(1, '/собрать')).text
    assert 'Пока ничего нет' in (await s.last(1, '/имущество')).text
    print('OK  пустые /бизнес, /собрать, /имущество')

    # ===== магазин: категории, карточки, покупка =====
    m = await s.press(1, 'Бизнесы')
    assert 'Бизнесы | стр. 1/3' in m.text and 'Ларёк с шаурмой' in m.text
    m = await s.press(1, 'Ларёк с шаурмой')
    assert 'Окупится примерно за' in m.text and m.find('Купить за 4 000 ₽')
    m = await s.press(1, 'Купить')
    assert 'Вы приобрели' in m.text and '/собрать' in m.text
    assert (await s.wallet(1))['rub'] == 1000
    assert 'уже есть' in (await s.cb(1, 'asset', 'shawarma')).text
    print('OK  магазин -> карточка -> покупка; деньги списаны')

    # недостаточно денег: транзакция откатывается, предмет не появляется
    m = await s.cb(1, 'shop', 'business')
    m = await s.press(1, 'Кофейня')
    assert 'Не хватает 11 000 ₽' in m.text
    m = await s.press(1, 'Купить')
    assert 'Недостаточно средств' in m.text
    assert not await s.db.fetchrow("SELECT 1 FROM owned_assets WHERE user_id=1 AND item_key='coffee'")
    assert (await s.wallet(1))['rub'] == 1000
    print('OK  не хватает денег: ни списания, ни предмета')

    # ===== сбор дохода =====
    now = accounts.now()
    await s.db.execute("UPDATE owned_assets SET collected_at=$1 WHERE user_id=1 AND item_key='shawarma'", now - 3 * 3600)
    m = await s.last(1, '/бизнес')
    assert 'накоплено 210 ₽' in m.text and 'Готово к сбору: 210 ₽' in m.text, m.text
    m = await s.last(1, '/собрать')
    assert '+210 ₽' in m.text and 'Получено: 210 ₽' in m.text
    assert (await s.wallet(1))['rub'] == 1210
    assert 'нечего собирать' in (await s.last(1, '/collect')).text
    print('OK  /собрать: доход за 3 часа, повторный сбор пуст')

    # ===== дома (аренда) и майнинг в одном сборе =====
    await s.db.execute('UPDATE wallets SET rub=100000 WHERE scope=0 AND user_id=1')
    await s.cb(1, 'abuy', 'flat')            # квартира в центре: 140 000 - не хватит
    assert not await s.db.fetchrow("SELECT 1 FROM owned_assets WHERE user_id=1 AND item_key='flat'")
    for key in ('studio', 'gpu_mid', 'gpu_high'):
        assert 'Вы приобрели' in (await s.cb(1, 'abuy', key)).text
    now = accounts.now()
    await s.db.execute("UPDATE owned_assets SET collected_at=$1 WHERE user_id=1 AND item_key IN ('studio','gpu_mid','gpu_high','shawarma')", now - 2 * 3600)
    m = await s.last(1, '/собрать')
    # студия 45000//400=112/ч, карты 80+250, ларёк 70 -> за 2 часа
    assert f'Бизнесы: +140 ₽' in m.text and 'Аренда: +224 ₽' in m.text and 'Майнинг: +660 ₽' in m.text, m.text
    assert 'Получено: 1 024 ₽' in m.text
    print('OK  сбор дохода с бизнеса, аренды дома и майнинга одной командой')

    # ===== имущество =====
    m = await s.last(1, '/имущество')
    assert 'Общая стоимость: 81 500 ₽' in m.text and 'Студия в панельном доме' in m.text and 'Майнинг-карта «Профи»' in m.text
    assert len(m.buttons()) == 8
    m = await s.press(1, 'Машины')
    assert 'Машины | стр. 1/3' in m.text
    m = await s.press(1, '▶')
    assert 'стр. 2/3' in m.text and m.version >= 1
    m = await s.press(1, 'Имущество')
    assert 'Моё имущество' in m.text
    print('OK  /имущество, разделы транспорта, листание и возврат')

    # ===== беседа: отдельное имущество и налог =====
    await s.make_chat(CHAT, creator=10, members=(1,))
    await s.give(1, rub=20000, scope=CHAT)
    assert 'Вы приобрели' in (await s.cb(1, 'abuy', 'coffee', peer=CHAT)).text
    assert not await s.db.fetchrow("SELECT 1 FROM owned_assets WHERE scope=0 AND user_id=1 AND item_key='coffee'")
    await s.db.execute('UPDATE chats SET tax=20 WHERE peer_id=$1', CHAT)
    await s.db.execute("UPDATE owned_assets SET collected_at=$1 WHERE scope=$2 AND item_key='coffee'", accounts.now() - 10 * 3600, CHAT)
    m = await s.last(1, '/собрать', peer=CHAT)                 # 210*10 = 2100, налог 20% = 420
    assert 'Налог в казну беседы: −420 ₽' in m.text and 'Получено: 1 680 ₽' in m.text, m.text
    assert (await s.db.fetchrow('SELECT treasury FROM chats WHERE peer_id=$1', CHAT))['treasury'] == 420
    print('OK  в беседе своё имущество, налог казны со сбора')

    # ===== все предметы доступны через кнопки, лимиты клавиатур =====
    await s.say(7, '/start')
    await s.db.execute('UPDATE wallets SET rub=9000000000 WHERE scope=0 AND user_id=7')
    for item in ITEMS:
        m = await s.cb(7, 'asset', item.key)
        assert item.title in m.text
        assert 'Вы приобрели' in (await s.cb(7, 'abuy', item.key)).text, item.key
    assert len(await s.db.fetch('SELECT 1 FROM owned_assets WHERE user_id=7')) == len(ITEMS)
    m = await s.last(7, '/имущество')
    assert len(m.text) < 4000
    for cat in CATEGORIES:
        n = (len(ITEMS_BY_CATEGORY[cat.key]) + 3) // 4
        for p in range(n):
            await s.cb(7, 'shop', f'{cat.key} {p}')
    print(f'OK  все {len(ITEMS)} предметов покупаются, все страницы магазина помещаются в лимиты ВК')

    # ===== гонка: параллельные сборы =====
    await s.say(8, '/start'); await s.give(8, rub=100000)
    await s.cb(8, 'abuy', 'coffee')
    await s.db.execute("UPDATE owned_assets SET collected_at=$1 WHERE user_id=8", accounts.now() - 10 * 3600)
    from app.modules.assets import collect_income
    res = await asyncio.gather(*[collect_income(s.db, 0, 8) for _ in range(5)])
    assert sum(r['net'] for r in res) == 2100, [r['net'] for r in res]
    print('OK  5 параллельных сборов - доход выплачен один раз')

    print('\nВсе тесты assets пройдены')

asyncio.run(main())
