"""Проверка main.py и app/vk.py на заглушке vkbottle (имитирует форму его API)."""
import asyncio
import json
import os
import sys
import types
from pathlib import Path
from types import SimpleNamespace as NS

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'tests'))

os.environ.update(TOKEN='t', DATABASE_URL='postgresql://x', ADMIN_ID='1000', PRICE_TICK_SECONDS='3600')


class VKAPIError(Exception):
    pass


calls = []          # (метод, параметры)
fail_send = set()   # peer_id, которым нельзя писать


class Messages:
    async def send(self, **kw):
        calls.append(('messages.send', kw))
        if kw['peer_id'] in fail_send:
            raise VKAPIError('901 can not send')
        return 1

    async def edit(self, **kw):
        calls.append(('messages.edit', kw))
        if kw.get('message') == 'SAME':
            raise VKAPIError('One of the parameters specified was missing or invalid: message is not changed')
        if kw.get('message') == 'FAIL':
            raise VKAPIError('too old')
        return 1

    async def send_message_event_answer(self, **kw):
        calls.append(('messages.send_message_event_answer', kw))

    async def delete(self, **kw):
        calls.append(('messages.delete', kw))

    async def remove_chat_user(self, **kw):
        calls.append(('messages.remove_chat_user', kw))

    async def get_conversation_members(self, **kw):
        calls.append(('messages.get_conversation_members', kw))
        return NS(items=[NS(member_id=10, is_admin=True, is_owner=True), NS(member_id=11, is_admin=True, is_owner=False),
                         NS(member_id=12, is_admin=False, is_owner=False), NS(member_id=-777, is_admin=True, is_owner=False)])


class Users:
    async def get(self, user_ids):
        calls.append(('users.get', {'user_ids': user_ids}))
        known = {'ivan': 55}
        out = []
        for u in user_ids:
            uid = known.get(u, u if isinstance(u, int) else None)
            if uid is None:
                raise VKAPIError('113 invalid user id')
            out.append(NS(id=uid, first_name='Имя', last_name=f'Фам{uid}'))
        return out


class Groups:
    async def get_by_id(self):
        return NS(groups=[NS(id=777)])


class On:
    def __init__(self):
        self.message_handlers, self.event_handlers = [], []

    def message(self, *a, **k):
        def deco(fn):
            self.message_handlers.append(fn)
            return fn
        return deco

    def raw_event(self, event_type, dataclass=None, **k):
        def deco(fn):
            self.event_handlers.append((event_type, fn))
            return fn
        return deco


class Bot:
    def __init__(self, token=None):
        self.token = token
        self.api = NS(messages=Messages(), users=Users(), groups=Groups())
        self.on = On()
        self.loop_wrapper = NS(on_startup=[], on_shutdown=[])


vk_mod = types.ModuleType('vkbottle')
vk_mod.Bot, vk_mod.VKAPIError = Bot, VKAPIError
vk_mod.GroupEventType = NS(MESSAGE_EVENT='message_event')
vk_mod.GroupTypes = NS(MessageEvent=object)
sys.modules['vkbottle'] = vk_mod
bot_mod = types.ModuleType('vkbottle.bot')
bot_mod.Message = object
sys.modules['vkbottle.bot'] = bot_mod

from sqlite_db import SqliteDatabase  # noqa: E402
import app.db as app_db  # noqa: E402
app_db.Database = lambda dsn: SqliteDatabase()

import main  # noqa: E402


def msg(peer, frm, text, **kw):
    base = dict(peer_id=peer, from_id=frm, text=text, payload=None, conversation_message_id=kw.pop('cmid', 1),
                action=None, reply_message=None, fwd_messages=None)
    base.update(kw)
    return NS(**base)


def sends(peer=None):
    return [kw for name, kw in calls if name == 'messages.send' and (peer is None or kw['peer_id'] == peer)]


async def main_test():
    await main.bot.loop_wrapper.on_startup[0]          # startup(): база, схема, приложение, цены
    assert main.app is not None and len(main.app.registry.commands) > 80
    assert await main.app.db.fetchval('SELECT COUNT(*) FROM market_prices') == 15
    on_message = main.bot.on.message_handlers[0]
    on_button = main.bot.on.event_handlers[0][1]
    assert main.bot.on.event_handlers[0][0] == 'message_event'

    # --- личное сообщение: /start ---
    await on_message(msg(5, 5, '/start'))
    s = sends(5)
    assert len(s) == 2
    assert json.loads(s[0]['keyboard']) == {'buttons': [], 'one_time': True}, 'первая отправка убирает нижнюю клавиатуру'
    assert s[1]['random_id'] == 0 and s[1]['disable_mentions'] is True and s[1]['peer_id'] == 5
    kb = json.loads(s[1]['keyboard'])
    assert kb['inline'] is True and kb['buttons'][0][0]['action']['type'] == 'callback'
    assert json.loads(kb['buttons'][0][0]['action']['payload']) == {'c': 'wallet', 'u': 5}
    assert 'Добро пожаловать, [id5|Имя Фам5]' in s[1]['message']
    print('OK  /start в ЛС: очистка нижней клавиатуры, inline-кнопки callback, имя из users.get')

    # --- кнопка: правка сообщения + ответ на событие ---
    calls.clear()
    ev = NS(object=NS(peer_id=5, user_id=5, conversation_message_id=42, event_id='abc', payload={'c': 'wallet', 'u': 5}))
    await on_button(ev)
    names = [n for n, _ in calls]
    assert names.count('messages.send_message_event_answer') == 1 and 'messages.edit' in names
    ans = dict(calls)['messages.send_message_event_answer']
    assert ans == {'event_id': 'abc', 'user_id': 5, 'peer_id': 5}
    edit = dict(calls)['messages.edit']
    assert edit['peer_id'] == 5 and edit['conversation_message_id'] == 42 and 'Кошелёк' in edit['message'] and 'keyboard' in edit
    print('OK  кнопка: ответ на событие и редактирование сообщения по conversation_message_id')

    # чужая кнопка: показ сообщения-подсказки
    calls.clear()
    await on_button(NS(object=NS(peer_id=5, user_id=6, conversation_message_id=42, event_id='x', payload={'c': 'wallet', 'u': 5})))
    ans = [kw for n, kw in calls if n == 'messages.send_message_event_answer'][0]
    assert json.loads(ans['event_data'])['type'] == 'show_snackbar' and 'не для вас' in json.loads(ans['event_data'])['text']
    assert 'messages.edit' not in [n for n, _ in calls]
    print('OK  чужая кнопка: всплывающая подсказка (snackbar), сообщение не меняется')

    # редактирование: «не изменилось» - не ошибка, провал - отправка нового сообщения
    vk = main.app.vk
    assert await vk.edit(5, 1, 'SAME') is True
    assert await vk.edit(5, 1, 'FAIL') is False

    # --- беседа: бота пригласили ---
    calls.clear()
    CH = 2_000_000_007
    await on_message(msg(CH, 10, '', action=NS(type=NS(value='chat_invite_user'), member_id=-777)))
    assert sends(CH) and 'Выдайте мне права администратора' in sends(CH)[0]['message']
    assert [n for n, _ in calls].count('messages.send') == 1
    # активация: /start, список участников, роли
    calls.clear()
    await on_message(msg(CH, 10, '/start'))
    assert ('messages.get_conversation_members', {'peer_id': CH}) in calls
    assert 'Бот активирован' in sends(CH)[0]['message']
    roles = {r['user_id']: r['role'] for r in await main.app.db.fetch('SELECT user_id, role FROM chat_members WHERE peer_id=$1', CH)}
    assert roles == {10: 100, 11: 90}
    print('OK  беседа: приглашение бота -> /start -> участники из VK, роли 100 и 90 (id группы определён через groups.getById)')

    # --- модерация: кик, удаление, ответ на сообщение ---
    calls.clear()
    await on_message(msg(CH, 10, '/кик', reply_message=NS(from_id=12), cmid=5))
    assert ('messages.remove_chat_user', {'chat_id': 7, 'member_id': 12}) in calls, 'chat_id = peer_id - 2000000000'
    await main.app.db.execute(
        'INSERT INTO chat_members (peer_id, user_id, muted_until) VALUES ($1, 12, $2) '
        'ON CONFLICT (peer_id, user_id) DO UPDATE SET muted_until = EXCLUDED.muted_until', CH, 4_000_000_000)
    calls.clear()
    await on_message(msg(CH, 12, 'привет всем', cmid=77))
    assert ('messages.delete', {'peer_id': CH, 'cmids': [77], 'delete_for_all': True}) in calls
    assert not sends(CH)
    print('OK  кик по ответу на сообщение, удаление сообщений замученного (cmids, delete_for_all)')

    # --- пересланное сообщение как цель, @имя через users.get ---
    calls.clear()
    await main.app.db.execute('UPDATE chat_members SET role=100 WHERE peer_id=$1 AND user_id=10', CH)
    await on_message(msg(CH, 10, '/варн @ivan спам', cmid=8))
    assert ('users.get', {'user_ids': ['ivan']}) in calls
    assert 'предупреждение 1/3' in sends(CH)[-1]['message']
    print('OK  цель по короткому имени: users.get(user_ids=[имя]) -> id')

    # --- рассылка с недоставкой ---
    fail_send.add(5)
    assert await vk.send(5, 'x') is False and await vk.send(6, 'y') is True
    fail_send.clear()

    # --- имена: пачкой, ошибка -> пусто ---
    assert await vk.names([1, 2, -3, 0]) == {1: 'Имя Фам1', 2: 'Имя Фам2'}
    print('OK  недоставка сообщения (VKAPIError) не падает, имена пачкой')

    # --- ошибка внутри команды не роняет бота ---
    orig = main.app.registry.commands['wallet'].handler
    async def boom(ctx):
        raise RuntimeError('boom')
    main.app.registry.commands['wallet'].handler = boom
    calls.clear()
    await on_message(msg(5, 5, '/кошелёк'))
    assert 'Что-то пошло не так' in sends(5)[-1]['message']
    main.app.registry.commands['wallet'].handler = orig
    print('OK  необработанная ошибка в команде: пользователю мягкое сообщение, бот продолжает работать')

    # --- тик цен ---
    from app.services import market_engine
    before = await main.app.db.fetchval("SELECT price FROM market_prices WHERE symbol='BTC'")
    await market_engine.tick(main.app.db)
    assert await main.app.db.fetchval("SELECT price FROM market_prices WHERE symbol='BTC'") != before
    print('\nВсе проверки glue пройдены')

asyncio.run(main_test())
