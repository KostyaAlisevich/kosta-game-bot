import asyncio
from sim import Sim, OWNER, CHAT_BASE

CHAT = CHAT_BASE + 21


async def main():
    s = await Sim.create()
    for u in (1, 2, 3):
        await s.say(u, '/start')
    await s.give(1, rub=20000)

    # ===== семья: создание =====
    m = await s.last(1, '/семья')
    assert 'нет семьи' in m.text and 'создать' in m.text
    assert 'Укажите название' in (await s.last(1, '/семья создать')).text
    m = await s.last(1, '/семья создать [Ромашка]')
    assert 'Семья «Ромашка» создана' in m.text and 'Глава: [id1|Юзер1]' in m.text
    assert (await s.wallet(1))['rub'] == 15000
    assert 'уже состоите' in (await s.last(1, '/семья создать Другая')).text
    await s.give(2, rub=20000)
    assert 'уже есть' in (await s.last(2, '/семья создать ромашка')).text, 'названия различаются без учёта регистра'
    await s.give(3, rub=100)
    assert 'Не хватает денег' in (await s.last(3, '/семья создать Бедняки')).text
    print('OK  семья: создание за 5 000 ₽, уникальное название, повторное создание, нехватка денег')

    # ===== приглашения (личные сообщения) =====
    s.vk.screen['petya'] = 2
    ev = await s.say(1, '/семья пригласить @petya')
    assert any(e.peer == 2 and 'приглашают в семью «Ромашка»' in e.text for e in ev)
    invite = [e for e in ev if e.peer == 2][-1]
    assert (await s.last(2, '/семья')).find('Принять приглашение')
    m = await s.press(2, 'Принять', msg=invite)
    assert 'Вы вступили в семью' in m.text and 'Участников: 2 из 10' in m.text
    assert 'Приглашать может только глава' in (await s.last(2, '/семья пригласить @1')).text
    assert 'уже состоит' in (await s.last(1, '/семья пригласить @petya')).text
    assert 'нет приглашений' in (await s.last(3, '/семья принять')).text
    print('OK  приглашение в личке: уведомление с кнопкой, принятие, ограничения')

    # ===== бюджет =====
    m = await s.last(2, '/бюджет')
    assert 'В бюджете: 0 ₽' in m.text and not m.find('Всё')
    m = await s.last(2, '/бюджет положить 1000')
    assert 'внесено: 1 000 ₽' in m.text and (await s.wallet(2))['rub'] == 19000
    m = await s.press(2, '➕ 50%')
    assert (await s.wallet(2))['rub'] == 9500
    assert 'только глава' in (await s.last(2, '/бюджет снять 100')).text
    m = await s.last(1, '/бюджет снять 5000')
    assert 'снято: 5 000 ₽' in m.text and (await s.wallet(1))['rub'] == 20000
    assert 'только 5 500' in (await s.last(1, '/бюджет снять 99999')).text.replace('\xa0', ' ')
    assert 'Недостаточно средств' in (await s.last(2, '/бюджет положить 99999')).text
    print('OK  семейный бюджет: взносы, снятие только главой, лимиты')

    # форбс показывает семьи
    m = await s.last(1, '/форбс')
    assert 'Богатейшие семьи' in m.text and '«Ромашка»' in m.text and '(2 чел.)' in m.text
    # исключение, выход
    assert 'нет в вашей семье' in (await s.last(1, '/семья исключить @3')).text
    assert 'Глава не может' in (await s.last(1, '/семья выйти')).text
    m = await s.last(2, '/семья выйти')
    assert 'вышли из семьи' in m.text
    assert 'нет семьи' in (await s.last(2, '/семья')).text
    await s.say(1, '/семья пригласить @petya'); await s.last(2, '/семья принять')
    m = await s.last(1, '/семья исключить @petya')
    assert 'исключён' in m.text
    # роспуск возвращает бюджет главе
    bal = (await s.wallet(1))['rub']
    m = await s.last(1, '/семья распустить')
    assert 'распущена' in m.text and (await s.wallet(1))['rub'] == bal + 5500
    assert not await s.db.fetchrow('SELECT 1 FROM families') and not await s.db.fetchrow('SELECT 1 FROM family_members')
    print('OK  выход, исключение, роспуск с возвратом бюджета')

    # ===== семья в беседе: приглашение кнопкой, чужие не нажимают =====
    await s.make_chat(CHAT, creator=10, members=(1, 2, 3))
    await s.give(1, rub=20000, scope=CHAT)
    await s.say(1, '/семья создать Беседа', peer=CHAT)
    ev = await s.say(1, '/семья пригласить', peer=CHAT, reply_from=2)
    inv = ev[-1]
    assert 'приглашают в семью «Беседа»' in inv.text
    await s.press(3, 'Принять', peer=CHAT, msg=inv)
    assert s.vk.answers[-1] == (3, 'Эта кнопка предназначена не для вас')
    m = await s.press(2, 'Принять', peer=CHAT, msg=inv)
    assert 'Вы вступили' in m.text
    print('OK  в беседе: приглашение ответом на сообщение, принять может только приглашённый')

    # ===== казна, налог =====
    await s.make_chat(CHAT + 1, creator=10, admins=(11,), members=(1, 2))
    C = CHAT + 1
    await s.say(11, '/start'); await s.say(1, '/start')
    await s.chat_role(C, 1, 80)   # старший модератор
    m = await s.last(2, '/казна', peer=C)
    assert 'В казне: 0 ₽' in m.text and 'Налог: 0%' in m.text and '/казнавыдать' not in m.text
    assert 'Нужна роль 90+' in (await s.last(2, '/налог 10', peer=C)).text
    assert 'Нужна роль 90+' in (await s.last(1, '/налог 10', peer=C)).text, 'ст. модератор (80) налог менять не может'
    assert 'Налог беседы теперь 10%' in (await s.last(11, '/налог 10', peer=C)).text
    assert 'от 0 до 30' in (await s.last(11, '/налог 50', peer=C)).text
    assert 'Укажите налог' in (await s.last(11, '/налог abc', peer=C)).text
    assert 'Налог: 10%' in (await s.last(1, '/казна', peer=C)).text and '/казнавыдать' in (await s.last(1, '/казна', peer=C)).text
    assert 'только в беседах' in (await s.last(1, '/казна')).text
    print('OK  казна и налог: права по ролям беседы (90 - налог, 80 - выплаты)')

    # выплата из казны
    await s.db.execute('UPDATE chats SET treasury=5000 WHERE peer_id=$1', C)
    s.vk.screen['vasya'] = 2
    m = await s.last(1, '/казнавыдать @vasya 2000', peer=C)
    assert 'выплачено 2 000 ₽' in m.text and 'Остаток казны: 3 000 ₽' in m.text
    assert (await s.wallet(2, C))['rub'] == 7000
    assert 'недостаточно средств: 3 000' in (await s.last(1, '/казна-выдать @vasya 99999', peer=C)).text.replace('\xa0', ' ')
    assert 'Формат' in (await s.last(1, '/казнавыдать @vasya', peer=C)).text
    assert 'Нужна роль 80+' in (await s.last(2, '/казнавыдать @vasya 1', peer=C)).text
    print('OK  /казнавыдать: списание из казны, остаток, ограничения')

    # ===== эковыдать / экозабрать / экосброс =====
    m = await s.last(1, '/эковыдать @vasya 500', peer=C)
    assert 'начислено 500 ₽' in m.text and (await s.wallet(2, C))['rub'] == 7500
    m = await s.last(1, '/ecogive @vasya 10$', peer=C)
    assert (await s.wallet(2, C))['usd'] == 1000
    m = await s.last(1, '/экозабрать @vasya 100000', peer=C)
    assert 'списано 7 500 ₽' in m.text and 'больше нет' in m.text and (await s.wallet(2, C))['rub'] == 0
    assert 'нет такой валюты' in (await s.last(1, '/ecotake @vasya 5 евро', peer=C)).text
    assert 'Нужна роль 80+' in (await s.last(2, '/эковыдать @vasya 5', peer=C)).text
    await s.give(2, rub=5000, scope=C)
    await s.db.execute("INSERT INTO owned_assets (scope, user_id, item_key, bought_at, collected_at) VALUES ($1, 2, 'tent', 0, 0)", C)
    assert 'Нужна роль 100+' in (await s.last(11, '/экосброс @vasya', peer=C)).text, 'админ (90) сбросить не может'
    m = await s.last(10, '/экосброс @vasya', peer=C)
    assert 'Обнулить экономику' in m.text and m.find('Да, обнулить')
    assert (await s.wallet(2, C))['rub'] == 5000, 'до подтверждения ничего не меняется'
    m = await s.press(10, 'Да, обнулить', peer=C, msg=m)
    assert 'обнулена' in m.text
    assert await s.wallet(2, C) is None and not await s.db.fetchrow('SELECT 1 FROM owned_assets WHERE scope=$1', C)
    assert (await s.wallet(2)) is not None, 'личная экономика не затронута'
    # подтверждение чужой кнопкой невозможно
    m = await s.last(10, '/экосброс @vasya', peer=C)
    await s.press(11, 'Да, обнулить', peer=C, msg=m)
    assert s.vk.answers[-1][1] == 'Эта кнопка предназначена не для вас'
    print('OK  /эковыдать, /экозабрать, /экосброс (с подтверждением) и ограничения по ролям')

    # ===== личные сообщения: права по должности бота =====
    assert 'Недостаточно прав' in (await s.last(1, '/эковыдать @petya 100')).text
    await s.set_role(1, 5)
    m = await s.last(1, '/эковыдать @petya 100')
    assert 'начислено 100 ₽' in m.text and (await s.wallet(2))['rub'] == 9500 + 100
    assert 'Недостаточно прав' in (await s.last(1, '/экосброс @petya')).text, 'для /экосброс в личке нужна должность 7+'
    await s.set_role(1, 7)
    assert 'Обнулить экономику' in (await s.last(1, '/экосброс @petya')).text
    print('OK  в личных сообщениях экономические команды доступны по должности бота (5+ и 7+)')

    print('\nВсе тесты family/treasury пройдены')

asyncio.run(main())
