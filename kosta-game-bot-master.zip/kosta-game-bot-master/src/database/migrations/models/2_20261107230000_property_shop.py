from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        CREATE TABLE IF NOT EXISTS "owned_items" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    "item_key" VARCHAR(32) NOT NULL,
    "purchased_at" BIGINT NOT NULL,
    "collected_at" BIGINT NOT NULL,
    "user_id" INT NOT NULL REFERENCES "users" ("id") ON DELETE CASCADE,
    CONSTRAINT "uid_owned_items_user_id_45323c" UNIQUE ("user_id", "item_key")
);"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        DROP TABLE IF EXISTS "owned_items";"""
