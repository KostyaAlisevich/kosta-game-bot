"""Реестр команд: у каждой команды есть ключ, псевдонимы, описание и требования к роли.

Одна и та же функция вызывается и по тексту (/кошелёк), и по кнопке (payload {"c": "wallet"}).
"""
from dataclasses import dataclass
from typing import Awaitable, Callable


def norm(name: str) -> str:
    """Единый вид имени команды: нижний регистр, ё -> е."""
    return name.strip().lower().replace('ё', 'е')


@dataclass
class Command:
    key: str
    names: tuple[str, ...]
    desc: str
    handler: Callable[..., Awaitable]
    section: str = ''
    where: str = 'any'      # 'any' | 'chat' | 'dm'
    level: int = 0          # минимальная роль в беседе (в ЛС - соответствующая должность бота)
    staff: int = 0          # минимальная должность бота (0 - не требуется)
    hidden: bool = False    # скрыть из /help (служебные команды для кнопок)
    usage: str = ''
    display: tuple[str, ...] = ()   # имена в исходном написании (с «ё») - для справки


class Registry:
    def __init__(self):
        self.commands: dict[str, Command] = {}
        self.by_name: dict[str, Command] = {}
        self.pendings: dict[str, Callable[..., Awaitable]] = {}
        self.chat_events: list[Callable[..., Awaitable]] = []
        self.pre_message: list[Callable[..., Awaitable]] = []

    def command(self, key: str, names=(), desc: str = '', section: str = '', where: str = 'any',
                level: int = 0, staff: int = 0, hidden: bool = False, usage: str = ''):
        def deco(fn):
            assert key not in self.commands, f'дублирующийся ключ команды: {key}'
            cmd = Command(key, tuple(norm(n) for n in names), desc, fn, section, where, level, staff, hidden, usage,
                          tuple(n.strip().lower() for n in names))
            self.commands[key] = cmd
            for name in cmd.names:
                assert name not in self.by_name, f'имя команды {name} уже занято ({self.by_name[name].key})'
                self.by_name[name] = cmd
            return fn
        return deco

    def pending(self, kind: str):
        """Обработчик ответа пользователя на вопрос бота (например, ввод промокода)."""
        def deco(fn):
            self.pendings[kind] = fn
            return fn
        return deco

    def on_chat_event(self, fn):
        self.chat_events.append(fn)
        return fn

    def on_pre_message(self, fn):
        """Хук перед обработкой сообщения в беседе (мут, бан беседы). Вернул True - сообщение поглощено."""
        self.pre_message.append(fn)
        return fn

    def find(self, name: str) -> Command | None:
        return self.by_name.get(norm(name))


registry = Registry()
