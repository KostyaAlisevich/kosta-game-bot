from dataclasses import dataclass, field


@dataclass
class Incoming:
    """Входящее сообщение (после разбора слоем ВК)."""
    peer_id: int
    from_id: int
    text: str = ''
    cmid: int | None = None            # conversation_message_id
    reply_from: int | None = None      # автор сообщения, на которое ответили
    fwd_from: list = field(default_factory=list)
    action: dict | None = None         # служебное событие беседы: {'type': ..., 'member_id': ...}
    payload: dict | None = None        # payload кнопки «Начать» и подобных


@dataclass
class ButtonEvent:
    """Нажатие inline-кнопки (callback)."""
    peer_id: int
    user_id: int
    cmid: int | None
    event_id: str
    payload: dict
