"""Inline-клавиатуры под сообщениями (кнопки-«callback»).

JSON собирается вручную, поэтому код не зависит от версии vkbottle.
Лимиты ВК для inline: не более 10 кнопок, не более 6 рядов, подпись до 40 символов,
payload до 255 байт. Лишнее отбрасывается (и помечается флагом overflow).
"""
import json

MAX_BUTTONS = 10
MAX_ROWS = 6
MAX_PER_ROW = 4
COLORS = ('primary', 'secondary', 'positive', 'negative')


class KB:
    def __init__(self, uid: int = 0):
        self.uid = uid
        self.rows: list[list[dict]] = [[]]
        self.overflow = False

    def btn(self, label: str, cmd: str, args: str = '', color: str = 'secondary', u: int | None = None) -> 'KB':
        """Кнопка, которая вызывает команду cmd (ключ из реестра) с аргументами args.

        u - кому разрешено нажимать: по умолчанию тому, для кого собрана клавиатура;
        u=0 - всем участникам беседы.
        """
        payload = {'c': cmd}
        if args:
            payload['a'] = args
        owner = self.uid if u is None else u
        if owner:
            payload['u'] = owner
        data = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
        if len(data.encode('utf-8')) > 255:
            raise ValueError(f'payload кнопки длиннее 255 байт: {data}')
        if color not in COLORS:
            color = 'secondary'
        if len(self.rows[-1]) >= MAX_PER_ROW:
            self.row()
        self.rows[-1].append({
            'action': {'type': 'callback', 'label': label[:40], 'payload': data},
            'color': color,
        })
        return self

    def row(self) -> 'KB':
        if self.rows[-1]:
            self.rows.append([])
        return self

    def buttons(self) -> list[dict]:
        return [b for r in self.rows for b in r]

    def to_json(self) -> str | None:
        rows = [r for r in self.rows if r]
        if not rows:
            return None
        out, count = [], 0
        for row in rows[:MAX_ROWS]:
            kept = row[:max(0, MAX_BUTTONS - count)]
            if len(kept) < len(row):
                self.overflow = True
            if kept:
                out.append(kept)
                count += len(kept)
        if len(rows) > MAX_ROWS:
            self.overflow = True
        return json.dumps({'inline': True, 'buttons': out}, ensure_ascii=False, separators=(',', ':'))


def home_row(kb: KB, cmd: str = 'menu', label: str = '🏠 Меню') -> KB:
    return kb.row().btn(label, cmd)
