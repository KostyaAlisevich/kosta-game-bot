"""Движок рынка: случайное блуждание цен, новости, история котировок (общие для всех бесед)."""
import math
import random

from ..data.market import (
    NEWS_DOWN, NEWS_DOWN_CRYPTO, NEWS_UP, NEWS_UP_CRYPTO, TICKERS, TICKERS_BY_SYMBOL, TRADABLE,
)
from .accounts import now

HISTORY_KEEP = 26 * 3600     # хранить историю котировок, секунд
EVENT_CHANCE = 0.04          # шанс новости на каждом шаге
REVERT = 0.002               # сила возврата цены к базовой


def _round_price(price: float) -> float:
    return round(price, 4 if price < 100 else 2)


def next_price(price: float, base: float, vol: float, rng=random) -> float:
    """Один шаг блуждания: случайный шок + лёгкое возвращение к базовой цене, в пределах 0.2x-5x от базы."""
    shock = rng.gauss(0, vol)
    revert = REVERT * math.log(base / price)
    new = price * math.exp(shock + revert)
    return _round_price(min(max(new, base * 0.2), base * 5))


async def seed_market(db) -> None:
    t = now()
    for tk in TICKERS:
        await db.execute(
            'INSERT INTO market_prices (symbol, kind, price, base, updated) VALUES ($1, $2, $3, $4, $5) '
            'ON CONFLICT (symbol) DO NOTHING', tk.symbol, tk.kind, tk.base, tk.base, t)
        has = await db.fetchval('SELECT COUNT(*) FROM market_history WHERE symbol=$1', tk.symbol)
        if not has:
            await db.execute('INSERT INTO market_history (symbol, ts, price) VALUES ($1, $2, $3)',
                             tk.symbol, t, tk.base)


async def tick(db, rng=random, ts: int | None = None) -> list[tuple[str, float, str]]:
    """Обновляет все цены. Возвращает список событий-новостей: (символ, процент, текст)."""
    ts = ts or now()
    rows = await db.fetch('SELECT symbol, price, base FROM market_prices')
    for r in rows:
        tk = TICKERS_BY_SYMBOL.get(r['symbol'])
        if tk is None:
            continue
        price = next_price(r['price'], r['base'], tk.vol, rng)
        await db.execute('UPDATE market_prices SET price=$2, updated=$3 WHERE symbol=$1', r['symbol'], price, ts)
        await db.execute('INSERT INTO market_history (symbol, ts, price) VALUES ($1, $2, $3)', r['symbol'], ts, price)

    events = []
    if rng.random() < EVENT_CHANCE:
        tk = rng.choice(TRADABLE)
        up = rng.random() < 0.5
        pct = round(rng.uniform(4, 12), 1) * (1 if up else -1)
        row = await db.fetchrow('SELECT price, base FROM market_prices WHERE symbol=$1', tk.symbol)
        new = _round_price(min(max(row['price'] * (1 + pct / 100), row['base'] * 0.2), row['base'] * 5))
        await db.execute('UPDATE market_prices SET price=$2, updated=$3 WHERE symbol=$1', tk.symbol, new, ts)
        await db.execute('UPDATE market_history SET price=$3 WHERE symbol=$1 AND ts=$2', tk.symbol, ts, new)
        pool = (NEWS_UP_CRYPTO if up else NEWS_DOWN_CRYPTO) if tk.kind == 'crypto' else (NEWS_UP if up else NEWS_DOWN)
        text = rng.choice(pool).format(name=tk.name)
        await db.execute('INSERT INTO market_news (ts, symbol, pct, text) VALUES ($1, $2, $3, $4)',
                         ts, tk.symbol, pct, text)
        events.append((tk.symbol, pct, text))

    await db.execute('DELETE FROM market_history WHERE ts < $1', ts - HISTORY_KEEP)
    await db.execute('DELETE FROM market_news WHERE ts < $1', ts - 3 * 86400)
    return events


async def prices(db) -> dict[str, float]:
    rows = await db.fetch('SELECT symbol, price FROM market_prices')
    return {r['symbol']: r['price'] for r in rows}


async def price(db, symbol: str) -> float | None:
    return await db.fetchval('SELECT price FROM market_prices WHERE symbol=$1', symbol)


async def fx_rates(db) -> dict[str, float]:
    p = await prices(db)
    return {'rub': 1.0, 'usd': p.get('USD', 90.0), 'eur': p.get('EUR', 98.0)}


async def history(db, symbol: str, hours: int = 24, points: int = 24) -> list[float]:
    """Цены за последние hours часов, сжатые до points значений."""
    since = now() - hours * 3600
    rows = await db.fetch('SELECT price FROM market_history WHERE symbol=$1 AND ts >= $2 ORDER BY ts', symbol, since)
    values = [r['price'] for r in rows]
    if len(values) <= points:
        return values
    step = (len(values) - 1) / (points - 1)
    return [values[round(i * step)] for i in range(points)]


async def change_24h(db, symbol: str) -> float:
    """Изменение цены за сутки в процентах (относительно самой ранней точки в окне)."""
    since = now() - 24 * 3600
    first = await db.fetchval(
        'SELECT price FROM market_history WHERE symbol=$1 AND ts >= $2 ORDER BY ts LIMIT 1', symbol, since)
    cur = await price(db, symbol)
    if not first or not cur:
        return 0.0
    return (cur - first) / first * 100


async def changes(db, symbols=None) -> dict[str, float]:
    return {tk.symbol: await change_24h(db, tk.symbol) for tk in TICKERS if symbols is None or tk.symbol in symbols}
