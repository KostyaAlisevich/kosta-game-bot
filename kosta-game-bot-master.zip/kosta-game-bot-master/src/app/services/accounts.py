"""Пользователи, кошельки и журнал операций."""
import time

from ..config import START_RUB
from ..roles import MAX_STAFF

# Допустимые валюты и соответствующие колонки (только из этого списка попадают в SQL)
COLS = {'rub': 'rub', 'usd': 'usd', 'eur': 'eur'}


def now() -> int:
    return int(time.time())


async def get_user(db, uid: int):
    return await db.fetchrow('SELECT * FROM users WHERE id=$1', uid)


async def register_user(app, uid: int, dm: bool = False):
    """Возвращает пользователя, создавая запись при первом обращении к боту."""
    row = await get_user(app.db, uid)
    t = now()
    if row is None:
        name = (await app.vk.names([uid])).get(uid, '')
        role = MAX_STAFF if uid == app.admin_id else 0
        await app.db.execute(
            'INSERT INTO users (id, name, role, created_at, last_seen, dm_ok) '
            'VALUES ($1, $2, $3, $4, $4, $5) ON CONFLICT (id) DO NOTHING',
            uid, name, role, t, 1 if dm else 0,
        )
        row = await get_user(app.db, uid)
    else:
        need_dm = dm and not row['dm_ok']
        if t - row['last_seen'] > 60 or need_dm:
            await app.db.execute(
                'UPDATE users SET last_seen=$2, dm_ok = CASE WHEN $3 = 1 THEN 1 ELSE dm_ok END WHERE id=$1',
                uid, t, 1 if dm else 0,
            )
        if not row['name']:
            name = (await app.vk.names([uid])).get(uid, '')
            if name:
                await app.db.execute('UPDATE users SET name=$2 WHERE id=$1', uid, name)
        if uid == app.admin_id and row['role'] < MAX_STAFF:
            await app.db.execute('UPDATE users SET role=$2 WHERE id=$1', uid, MAX_STAFF)
        row = await get_user(app.db, uid)
    app.names[uid] = row['name']
    return row


async def ensure_target(app, uid: int):
    """Пользователь, к которому обращаются в команде. Если он ещё не в базе, но это реальный
    аккаунт ВК, регистрируем его автоматически. None - такого человека нет."""
    row = await get_user(app.db, uid)
    if row is not None:
        return row
    names = await app.vk.names([uid])
    if uid not in names:
        return None
    return await register_user(app, uid)


async def display_name(app, uid: int) -> str:
    name = app.names.get(uid)
    if name is None:
        row = await get_user(app.db, uid)
        name = row['name'] if row else ''
        app.names[uid] = name
    return name or f'id{uid}'


async def ensure_wallet(db, scope: int, uid: int):
    await db.execute(
        'INSERT INTO wallets (scope, user_id, rub, created_at) VALUES ($1, $2, $3, $4) '
        'ON CONFLICT (scope, user_id) DO NOTHING',
        scope, uid, START_RUB, now(),
    )
    return await db.fetchrow('SELECT * FROM wallets WHERE scope=$1 AND user_id=$2', scope, uid)


async def log_tx(db, scope: int, uid: int, kind: str, currency: str, amount: int, balance: int, note: str = '') -> None:
    await db.execute(
        'INSERT INTO transactions (scope, user_id, kind, currency, amount, balance, note, ts) '
        'VALUES ($1, $2, $3, $4, $5, $6, $7, $8)',
        scope, uid, kind, currency, amount, balance, note[:120], now(),
    )


async def change(db, scope: int, uid: int, amount: int, cur: str = 'rub', kind: str = '', note: str = '') -> int | None:
    """Атомарно меняет баланс. Возвращает новый баланс или None, если не хватило денег
    (или кошелька нет). Для списания условие balance >= сумма проверяется в самом UPDATE."""
    col = COLS[cur]
    if amount >= 0:
        row = await db.fetchrow(
            f'UPDATE wallets SET {col} = {col} + $3 WHERE scope=$1 AND user_id=$2 RETURNING {col} AS bal',
            scope, uid, amount,
        )
    else:
        row = await db.fetchrow(
            f'UPDATE wallets SET {col} = {col} + $3 WHERE scope=$1 AND user_id=$2 AND {col} >= $4 '
            f'RETURNING {col} AS bal',
            scope, uid, amount, -amount,
        )
    if row is None:
        return None
    if amount:
        await log_tx(db, scope, uid, kind, cur, amount, row['bal'], note)
    return row['bal']


async def apply_tax(db, scope: int, gross: int) -> tuple[int, int]:
    """Налог беседы: возвращает (сколько получит игрок, сколько ушло в казну)."""
    if scope == 0 or gross <= 0:
        return gross, 0
    row = await db.fetchrow('SELECT tax FROM chats WHERE peer_id=$1', scope)
    rate = row['tax'] if row else 0
    if rate <= 0:
        return gross, 0
    tax = gross * rate // 100
    if tax:
        await db.execute('UPDATE chats SET treasury = treasury + $2 WHERE peer_id=$1', scope, tax)
    return gross - tax, tax


def placeholders(start: int, count: int) -> str:
    """'$3, $4, $5' - для запросов вида IN (...) (без массивов, чтобы работало и в SQLite)."""
    return ', '.join(f'${start + i}' for i in range(count))
