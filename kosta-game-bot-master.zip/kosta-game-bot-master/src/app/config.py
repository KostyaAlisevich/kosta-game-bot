"""Настройки бота. Всё берётся из переменных окружения (на Railway - вкладка Variables)."""
import os

try:  # локально можно держать переменные в файле .env
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # pragma: no cover
    pass


def _int(name: str, default: int = 0) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


TOKEN = os.getenv('TOKEN', '')
ADMIN_ID = _int('ADMIN_ID')                 # ID основателя: всегда имеет высшую должность
GROUP_ID = _int('GROUP_ID')                 # ID сообщества (необязательно, бот определит сам)
DATABASE_URL = os.getenv('DATABASE_URL', '')  # строка подключения к PostgreSQL

START_RUB = _int('START_RUB', 5000)         # стартовый капитал в каждом кошельке
PRICE_TICK_SECONDS = _int('PRICE_TICK_SECONDS', 300)  # как часто обновляются курсы и котировки

CHAT_BASE = 2_000_000_000                   # peer_id беседы = CHAT_BASE + номер беседы
