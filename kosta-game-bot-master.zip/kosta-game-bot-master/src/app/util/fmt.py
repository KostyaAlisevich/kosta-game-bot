"""Форматирование чисел, денег, времени и упоминаний."""
import re

SEP = '━━━━━━━━━━━━━━'
_BAD_NAME = re.compile(r'[\[\]|]')


def num(n) -> str:
    return f'{int(n):,}'.replace(',', ' ')


def rub(n) -> str:
    return f'{num(n)} ₽'


def usd(cents) -> str:
    return '$' + f'{cents / 100:,.2f}'.replace(',', ' ')


def eur(cents) -> str:
    return '€' + f'{cents / 100:,.2f}'.replace(',', ' ')


def fnum(x: float, digits: int = 2) -> str:
    s = f'{x:,.{digits}f}'.replace(',', ' ')
    if '.' in s:
        s = s.rstrip('0').rstrip('.')
    return s


def money(currency: str, amount: int) -> str:
    """amount: рубли для rub, центы для usd/eur."""
    if currency == 'usd':
        return usd(amount)
    if currency == 'eur':
        return eur(amount)
    return rub(amount)


def pct(value: float, signed: bool = True) -> str:
    sign = '+' if signed and value > 0 else ''
    return f'{sign}{value:.2f}%'


def arrow(value: float) -> str:
    return '📈' if value > 0.005 else '📉' if value < -0.005 else '➖'


def dur(seconds) -> str:
    seconds = max(0, int(seconds))
    if seconds < 60:
        return f'{seconds} сек'
    if seconds < 3600:
        m, s = divmod(seconds, 60)
        return f'{m} мин {s} сек' if s else f'{m} мин'
    if seconds < 86400:
        h, rest = divmod(seconds, 3600)
        m = rest // 60
        return f'{h} ч {m} мин' if m else f'{h} ч'
    d, rest = divmod(seconds, 86400)
    h = rest // 3600
    return f'{d} д {h} ч' if h else f'{d} д'


def mention(uid: int, name: str = '') -> str:
    """Кликабельное упоминание [id123|Имя] (имя очищается от символов, ломающих разметку)."""
    name = _BAD_NAME.sub('', name or '').strip() or f'id{uid}'
    return f'[id{uid}|{name}]'


def bar(value: float, total: float, width: int = 10) -> str:
    if total <= 0:
        return '▱' * width
    filled = max(0, min(width, round(width * value / total)))
    return '▰' * filled + '▱' * (width - filled)


_SPARK = '▁▂▃▄▅▆▇█'


def spark(values: list[float]) -> str:
    if not values:
        return ''
    lo, hi = min(values), max(values)
    if hi - lo < 1e-12:
        return _SPARK[3] * len(values)
    step = (hi - lo) / (len(_SPARK) - 1)
    return ''.join(_SPARK[round((v - lo) / step)] for v in values)


def clip(text: str, limit: int) -> str:
    text = text or ''
    return text if len(text) <= limit else text[:limit - 1] + '…'


def parse_amount(token: str, maximum: int | None = None) -> int | None:
    """'1500', '1 500', '1.5к', '2кк', 'всё'/'все'/'all' (нужен maximum), '50%' (нужен maximum)."""
    if token is None:
        return None
    t = token.strip().lower().replace('_', '').replace(',', '.')
    if t in ('все', 'всё', 'all', 'max', 'макс'):
        return maximum if maximum and maximum > 0 else None
    if t.endswith('%') and maximum is not None:
        try:
            p = float(t[:-1])
        except ValueError:
            return None
        return int(maximum * p / 100) if 0 < p <= 100 else None
    mult = 1
    if t.endswith('кк') or t.endswith('kk') or t.endswith('м'):
        mult, t = 1_000_000, t[:-2] if t.endswith(('кк', 'kk')) else t[:-1]
    elif t.endswith('к') or t.endswith('k'):
        mult, t = 1_000, t[:-1]
    try:
        value = float(t)
    except ValueError:
        return None
    amount = int(round(value * mult))
    return amount if amount > 0 else None
