"""Промокоды: пользователи вводят код и получают рубли, администрация создаёт коды."""
import re
import secrets

from ..framework.registry import registry
from ..services import accounts
from ..util.fmt import SEP, dur, rub
from ..util.pages import paginate

CODE_RE = re.compile(r'^[A-Za-zА-Яа-яЁё0-9_\-]{3,32}$')
MAX_AMOUNT = 100_000_000


class _Stop(Exception):
    pass


def norm_code(raw: str) -> str:
    return (raw or '').strip().upper().replace('Ё', 'Е')


async def activate(ctx, raw_code: str) -> None:
    code = norm_code(raw_code)
    kb = ctx.kb().btn('🎁 Ещё промокод', 'promo').btn('💰 Кошелёк', 'wallet').btn('🏠 Меню', 'menu')
    if not CODE_RE.match(code):
        return await ctx.respond('❗ Промокод может содержать буквы, цифры, «-» и «_» (3-32 символа)', kb)
    promo = await ctx.db.fetchrow('SELECT * FROM promo_codes WHERE code=$1', code)
    if promo is None:
        return await ctx.respond('❌ Такого промокода нет. Проверьте, правильно ли он написан.', kb)
    now = accounts.now()
    if promo['expires_at'] and promo['expires_at'] <= now:
        return await ctx.respond('⌛ Срок действия этого промокода истёк.', kb)
    if promo['max_uses'] and promo['uses'] >= promo['max_uses']:
        return await ctx.respond('😕 Этот промокод уже использован максимальное число раз.', kb)
    await ctx.wallet()
    try:
        async with ctx.db.transaction() as tx:
            row = await tx.fetchrow(
                'UPDATE promo_codes SET uses = uses + 1 WHERE code=$1 AND (max_uses = 0 OR uses < max_uses) '
                'AND (expires_at = 0 OR expires_at > $2) RETURNING amount', code, now)
            if row is None:
                raise _Stop('gone')
            ins = await tx.fetchrow(
                'INSERT INTO promo_uses (code, user_id, scope, ts) VALUES ($1, $2, $3, $4) '
                'ON CONFLICT (code, user_id) DO NOTHING RETURNING code', code, ctx.user_id, ctx.scope, now)
            if ins is None:
                raise _Stop('used')
            await accounts.change(tx, ctx.scope, ctx.user_id, row['amount'], 'rub', 'promo', code)
    except _Stop as stop:
        text = ('ℹ Вы уже активировали этот промокод.' if str(stop) == 'used'
                else '😕 Этот промокод уже недоступен.')
        return await ctx.respond(text, kb)
    balance = (await ctx.wallet())['rub']
    await ctx.respond(f'🎁 Промокод активирован!\n{SEP}\nНачислено: +{rub(promo["amount"])}\n💳 Баланс: {rub(balance)}', kb)


@registry.command('promo', names=['промо', 'промокод', 'promo', 'код'], desc='ввести промокод', section='misc',
                  usage='<код>')
async def cmd_promo(ctx):
    code = ctx.args.strip()
    if code:
        return await activate(ctx, code)
    await ctx.ask('promo', f'🎁 Промокод\n{SEP}\nОтправьте промокод следующим сообщением.\n'
                           'Промокоды публикует администрация - следите за новостями!',
                  ctx.kb().btn('❌ Отмена', 'menu'))


@registry.pending('promo')
async def pending_promo(ctx, data):
    await activate(ctx, ctx.args)


# ---------------------------------------------------------------------------
# Администрация
# ---------------------------------------------------------------------------

def parse_promo_args(argv: list[str]):
    """КОД СУММА [ЛИМИТ] [ЧАСЫ] -> (код, сумма, лимит, часы) или строка с ошибкой."""
    if len(argv) < 2:
        return 'Формат: КОД СУММА [ЛИМИТ АКТИВАЦИЙ] [ЧАСОВ ДЕЙСТВИЯ]\nПример: START 1000 50 24 (или «авто» вместо кода)'
    code = norm_code(argv[0])
    if code in ('АВТО', 'AUTO'):
        code = secrets.token_hex(4).upper()
    if not CODE_RE.match(code):
        return 'Код: 3-32 символа, буквы/цифры/«-»/«_»'
    if not argv[1].isdigit() or not 0 < int(argv[1]) <= MAX_AMOUNT:
        return f'Сумма: целое число от 1 до {MAX_AMOUNT:,}'.replace(',', ' ')
    limit = int(argv[2]) if len(argv) > 2 and argv[2].isdigit() else 0
    hours = int(argv[3]) if len(argv) > 3 and argv[3].isdigit() else 0
    return code, int(argv[1]), limit, hours


async def create_promo(ctx, argv: list[str]):
    parsed = parse_promo_args(argv)
    if isinstance(parsed, str):
        return await ctx.respond('❗ ' + parsed)
    code, amount, limit, hours = parsed
    now = accounts.now()
    row = await ctx.db.fetchrow(
        'INSERT INTO promo_codes (code, amount, max_uses, expires_at, created_by, created_at) '
        'VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT (code) DO NOTHING RETURNING code',
        code, amount, limit, now + hours * 3600 if hours else 0, ctx.user_id, now)
    if row is None:
        return await ctx.respond(f'❗ Промокод {code} уже существует')
    await ctx.respond(
        f'✅ Промокод создан\n{SEP}\nКод: {code}\nНаграда: {rub(amount)}\n'
        f'Активаций: {limit or "без ограничений"}\nСрок: {dur(hours * 3600) if hours else "бессрочно"}',
        ctx.kb().btn('📋 Все промокоды', 'promo_list').btn('➕ Ещё', 'promo_create'))


@registry.command('promo_create', names=['промосоздать', 'promocreate', 'создатьпромо'], desc='создать промокод',
                  section='staff', staff=4, usage='<код|авто> <сумма> [лимит] [часов]')
async def cmd_promo_create(ctx):
    if ctx.argv:
        return await create_promo(ctx, ctx.argv)
    await ctx.ask('promo_create', '➕ Новый промокод\nОтправьте: КОД СУММА [ЛИМИТ] [ЧАСЫ]\n'
                                  'Пример: START 1000 50 24 (код «авто» создаст случайный)',
                  ctx.kb().btn('❌ Отмена', 'admin'))


@registry.pending('promo_create')
async def pending_promo_create(ctx, data):
    if await ctx.role() < 4:
        return
    await create_promo(ctx, ctx.argv)


@registry.command('promo_delete', names=['промоудалить', 'promodelete', 'удалитьпромо'], desc='удалить промокод',
                  section='staff', staff=4, usage='<код>')
async def cmd_promo_delete(ctx):
    if not ctx.argv:
        return await ctx.ask('promo_delete', '🗑 Отправьте код промокода, который нужно удалить',
                             ctx.kb().btn('❌ Отмена', 'admin'))
    await _delete(ctx, ctx.argv[0])


async def _delete(ctx, raw: str):
    code = norm_code(raw)
    row = await ctx.db.fetchrow('DELETE FROM promo_codes WHERE code=$1 RETURNING uses', code)
    if row is None:
        return await ctx.respond(f'❗ Промокод {code} не найден')
    await ctx.db.execute('DELETE FROM promo_uses WHERE code=$1', code)
    await ctx.respond(f'🗑 Промокод {code} удалён (был активирован {row["uses"]} раз)')


@registry.pending('promo_delete')
async def pending_promo_delete(ctx, data):
    if await ctx.role() >= 4 and ctx.argv:
        await _delete(ctx, ctx.argv[0])


@registry.command('promo_list', names=['промолист', 'promolist', 'промокоды'], desc='список промокодов',
                  section='staff', staff=3)
async def cmd_promo_list(ctx):
    rows = await ctx.db.fetch('SELECT * FROM promo_codes ORDER BY created_at DESC')
    page = int(ctx.args) if ctx.args.strip().isdigit() else 0
    items, page, total = paginate(rows, page, 6)
    now = accounts.now()
    lines = [f'🎁 Промокоды | стр. {page + 1}/{total}\n{SEP}']
    if not rows:
        lines.append('Промокодов пока нет.')
    for r in items:
        limit = f'{r["uses"]}/{r["max_uses"]}' if r['max_uses'] else f'{r["uses"]}/∞'
        if r['expires_at'] and r['expires_at'] <= now:
            state = '⌛ истёк'
        elif r['max_uses'] and r['uses'] >= r['max_uses']:
            state = '🚫 исчерпан'
        else:
            state = f'⏳ {dur(r["expires_at"] - now)}' if r['expires_at'] else '✅ активен'
        lines.append(f'{r["code"]} · {rub(r["amount"])} · {limit} · {state}')
    kb = ctx.kb()
    if page > 0:
        kb.btn('◀', 'promo_list', str(page - 1))
    if page < total - 1:
        kb.btn('▶', 'promo_list', str(page + 1))
    if await ctx.role() >= 4:
        kb.btn('➕ Создать', 'promo_create', color='positive').btn('🗑 Удалить', 'promo_delete')
    kb.row().btn('🛠 Панель', 'admin')
    await ctx.respond('\n'.join(lines), kb)
