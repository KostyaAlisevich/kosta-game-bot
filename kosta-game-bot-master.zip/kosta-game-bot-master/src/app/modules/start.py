"""Запуск бота, активация беседы, главное меню и справка по командам."""
from ..framework.registry import registry
from ..roles import DEFAULT_CHAT_ROLES, STAFF, STAFF_EMOJI, STAFF_SHORT, staff_title
from ..services import accounts, chats
from ..util.fmt import SEP, rub
from ..vk import VKAPIError

# Порядок и названия разделов в справке
SECTION_TITLES = {
    'menu': '🏠 Основное',
    'economy': '💰 Экономика',
    'work': '💼 Работа и учёба',
    'business': '🏢 Бизнес и имущество',
    'bank': '🏦 Банк',
    'market': '📈 Биржа',
    'family': '👨‍👩‍👧 Семья и казна',
    'games': '🎮 Игры',
    'misc': '🎁 Прочее',
    'moderation': '🛡 Управление беседой',
    'staff': '🛠 Служебные',
}
SECTION_ORDER = list(SECTION_TITLES)

HELP_LIMIT = 3600


# ---------------------------------------------------------------------------
# Главное меню
# ---------------------------------------------------------------------------

def main_menu_kb(ctx):
    return (
        ctx.kb()
        .btn('💰 Кошелёк', 'wallet', color='primary').btn('💼 Работа', 'jobs').btn('🎓 Учёба', 'study').row()
        .btn('🏢 Бизнес', 'biz').btn('🏦 Банк', 'bank').btn('📈 Рынок', 'market').row()
        .btn('🎮 Игры', 'games').btn('🎁 Промокод', 'promo').btn('🛟 Поддержка', 'support').row()
        .btn('❓ Помощь', 'help')
    )


@registry.command('menu', names=['меню', 'menu', 'главная'], desc='главное меню', section='menu')
async def cmd_menu(ctx):
    wallet = await ctx.wallet()
    place = 'эта беседа' if ctx.is_chat else 'личные сообщения'
    text = (
        f'🏠 Главное меню\n{SEP}\n'
        f'👤 {await ctx.mention()}\n'
        f'💰 Кошелёк: {rub(wallet["rub"])}\n'
        f'📍 Экономика: {place}\n'
        f'{SEP}\n'
        'Выберите раздел кнопками или используйте команды (список: /help)'
    )
    await ctx.respond(text, main_menu_kb(ctx))


# ---------------------------------------------------------------------------
# /start
# ---------------------------------------------------------------------------

@registry.command('start', names=['start', 'начать', 'старт'], desc='запуск бота; в беседе - активация',
                  section='menu')
async def cmd_start(ctx):
    if not ctx.is_chat:
        return await _start_dm(ctx)
    await _start_chat(ctx)


async def _start_dm(ctx):
    wallet = await ctx.wallet()
    text = (
        f'🎉 Добро пожаловать, {await ctx.mention()}!\n{SEP}\n'
        'Это экономический бот: работайте, учитесь, открывайте бизнесы, торгуйте акциями и криптой, '
        'берите кредиты, играйте в игры и поднимайтесь в рейтинге богачей.\n\n'
        f'💰 Ваш стартовый капитал: {rub(wallet["rub"])}\n'
        '➕ Добавьте бота в беседу: напишите там /start, и у беседы появится собственная экономика.\n'
        f'{SEP}\n'
        'Все кнопки находятся под сообщениями. Список команд: /help'
    )
    await ctx.respond(text, main_menu_kb(ctx))


async def _sync_chat_roles(ctx, members) -> tuple[int, int]:
    """Создатель беседы получает роль 100, администраторы - 90 (существующие роли выше не понижаются)."""
    owners = admins = 0
    for m in members:
        if m['id'] <= 0:
            continue
        level = 100 if m['owner'] else 90 if m['admin'] else 0
        if not level:
            continue
        await chats.get_member(ctx.db, ctx.peer_id, m['id'])
        await ctx.db.execute(
            'UPDATE chat_members SET role = CASE WHEN role < $3 THEN $3 ELSE role END '
            'WHERE peer_id=$1 AND user_id=$2', ctx.peer_id, m['id'], level)
        owners += 1 if m['owner'] else 0
        admins += 0 if m['owner'] else 1
    return owners, admins


async def _start_chat(ctx):
    chat = await ctx.chat()
    try:
        members = await ctx.app.vk.members(ctx.peer_id)
    except VKAPIError:
        return await ctx.respond(
            '⚠ Не удалось получить список участников беседы.\n'
            '1) Откройте настройки беседы и выдайте боту права администратора ⭐\n'
            '2) Затем снова нажмите кнопку или напишите /start',
            ctx.kb().btn('🔄 Повторить', 'start', u=0, color='positive'))

    me = next((m for m in members if m['id'] == ctx.user_id), None)
    if me is None or not (me['admin'] or me['owner']):
        return await ctx.respond('🚫 Активировать бота может только создатель или администратор беседы.')

    already = bool(chat['activated'])
    await _sync_chat_roles(ctx, members)
    await ctx.db.execute('UPDATE chats SET activated=1, activated_by=$2 WHERE peer_id=$1', ctx.peer_id, ctx.user_id)

    owner = next((m for m in members if m['owner']), None)
    admins = [m for m in members if m['admin'] and not m['owner'] and m['id'] > 0]
    lines = ['🔄 Роли синхронизированы!' if already else '✅ Бот активирован в этой беседе!', SEP]
    if owner and owner['id'] > 0:
        lines.append(f'👑 Создатель: {await ctx.mention(owner["id"])} (роль 100)')
    lines.append(f'⚙ Администраторов: {len(admins)} (роль 90)')
    lines += [
        '',
        '💰 В каждой беседе своя экономика: кошелёк здесь не связан с личными сообщениями.',
        '📜 Правила беседы: /правила, команды: /help',
    ]
    await ctx.respond('\n'.join(lines), main_menu_kb(ctx))


@registry.on_chat_event
async def bot_membership(app, inc) -> bool:
    """Бота добавили в беседу или удалили из неё."""
    action = inc.action or {}
    member = action.get('member_id')
    gid = await app.vk.group_id()
    if not gid or member != -gid:
        return False
    kind = action.get('type')
    if kind == 'chat_invite_user':
        await chats.get_chat(app.db, inc.peer_id)
        kb = _public_kb('▶ Активировать бота')
        await app.vk.send(
            inc.peer_id,
            '👋 Привет! Я экономический бот и менеджер бесед.\n\n'
            '1) Выдайте мне права администратора ⭐ в настройках беседы\n'
            '2) Нажмите кнопку или напишите /start - и всё заработает\n\n'
            '💡 У каждой беседы своя экономика, а создатель и администраторы получат роли автоматически.',
            kb.to_json())
        return True
    if kind == 'chat_kick_user':
        await app.db.execute('UPDATE chats SET activated=0 WHERE peer_id=$1', inc.peer_id)
        return True
    return False


def _public_kb(label: str):
    from ..framework.keyboards import KB
    return KB(0).btn(label, 'start', u=0, color='positive')


# ---------------------------------------------------------------------------
# /help
# ---------------------------------------------------------------------------

def _cmd_line(cmd) -> str:
    shown = cmd.display or cmd.names
    primary = shown[0] if shown else cmd.key
    latin = next((n for n in shown[1:] if n.isascii() and n != primary), '')
    head = f'/{primary}' + (f' {cmd.usage}' if cmd.usage else '')
    if latin and not cmd.usage:
        head += f' (/{latin})'
    return f'{head} - {cmd.desc}'


def _visible(cmd) -> bool:
    return not cmd.hidden and bool(cmd.names)


def category_commands(cat: str) -> list:
    """Команды категории: 'u' - пользователь, 'c' - беседа, '1'..'8' - должности бота."""
    cmds = [c for c in registry.commands.values() if _visible(c)]
    if cat == 'u':
        cmds = [c for c in cmds if c.staff == 0 and c.level == 0 and c.where != 'chat']
    elif cat == 'c':
        cmds = [c for c in cmds if c.staff == 0 and (c.where == 'chat' or c.level > 0)]
    else:
        cmds = [c for c in cmds if c.staff == int(cat)]
    order = {name: i for i, name in enumerate(SECTION_ORDER)}
    cmds.sort(key=lambda c: (order.get(c.section, 99), c.level, c.names[0] if c.names else c.key))
    return cmds


def help_pages(cat: str) -> list[str]:
    """Тексты страниц справки категории (разбиваются по лимиту длины сообщения)."""
    if cat == 'u':
        title = '👤 Команды пользователя'
    elif cat == 'c':
        title = '🛡 Команды беседы (в скобках - нужная роль в беседе)'
    else:
        title = f'{STAFF_EMOJI[int(cat)]} Должность: {STAFF[int(cat)]}'
    cmds = category_commands(cat)
    if not cmds:
        return [f'{title}\n{SEP}\nОсобых команд у этой должности нет: доступно всё, что есть у должностей ниже.']

    pages, lines, size, last_section = [], [], 0, None
    for cmd in cmds:
        chunk = []
        if cmd.section != last_section and cat in ('u', 'c'):
            chunk.append(f'\n{SECTION_TITLES.get(cmd.section, "•")}')
        line = _cmd_line(cmd)
        if cat == 'c' and cmd.level:
            line += f' ({cmd.level}+)'
        chunk.append(line)
        chunk_text = '\n'.join(chunk)
        if size + len(chunk_text) > HELP_LIMIT and lines:
            pages.append(lines)
            lines, size = [], 0
            if cat in ('u', 'c') and cmd.section in SECTION_TITLES and len(chunk) == 1:
                chunk.insert(0, f'\n{SECTION_TITLES[cmd.section]}')
                chunk_text = '\n'.join(chunk)
        lines.append(chunk_text)
        size += len(chunk_text) + 1
        last_section = cmd.section
    pages.append(lines)
    total = len(pages)
    suffix = lambda i: f' (стр. {i + 1}/{total})' if total > 1 else ''  # noqa: E731
    return [f'{title}{suffix(i)}\n{SEP}' + '\n'.join(p) for i, p in enumerate(pages)]


def _categories(role: int, is_chat: bool) -> list[tuple[str, str]]:
    cats = [('u', STAFF_SHORT[0])]
    if is_chat or role >= 5:      # в личке команды управления экономикой есть у должностей 5+
        cats.append(('c', '🛡 Беседа'))
    cats += [(str(r), STAFF_SHORT[r]) for r in range(1, role + 1)]
    return cats


@registry.command('help', names=['help', 'помощь', 'команды', 'справка', 'хелп'], desc='список команд', section='menu')
async def cmd_help(ctx):
    role = await ctx.role()
    cat, page = 'u', 0
    argv = ctx.argv
    if argv:
        cat = argv[0]
        page = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else 0
    valid = dict(_categories(role, ctx.is_chat))
    if cat not in valid:
        cat, page = 'u', 0
    pages = help_pages(cat)
    page = max(0, min(page, len(pages) - 1))

    kb = ctx.kb()
    for i, (key, label) in enumerate(_categories(role, ctx.is_chat)):
        if i and i % 2 == 0:
            kb.row()
        mark = '• ' if key == cat else ''
        kb.btn(f'{mark}{label}', 'help', key, color='primary' if key == cat else 'secondary')
    if len(pages) > 1:
        kb.row()
        if page > 0:
            kb.btn('◀', 'help', f'{cat} {page - 1}')
        if page < len(pages) - 1:
            kb.btn('▶', 'help', f'{cat} {page + 1}')
    await ctx.respond(pages[page] + f'\n\nВаша должность: {staff_title(role)}', kb)
