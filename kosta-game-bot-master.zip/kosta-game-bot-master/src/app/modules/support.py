"""Поддержка: вопросы пользователей видят и отвечают на них все сотрудники (должность 1 и выше)."""
from ..framework.registry import registry
from ..roles import staff_name
from ..services import accounts
from ..util.fmt import SEP, clip, dur, mention
from ..util.pages import paginate

MAX_TEXT = 1500
MAX_OPEN_PER_USER = 3
COOLDOWN = 20          # секунд между обращениями
PAGE_SIZE = 4
STATUS = {'open': '🆕 новый', 'answered': '💬 отвечен', 'closed': '✅ закрыт'}


async def staff_ids(db) -> list[int]:
    rows = await db.fetch('SELECT id FROM users WHERE role >= 1 AND banned = 0 AND dm_ok = 1')
    return [r['id'] for r in rows]


# ---------------------------------------------------------------------------
# Для пользователей
# ---------------------------------------------------------------------------

async def create_ticket(ctx, text: str) -> None:
    text = text.strip()
    if len(text) < 5:
        return await ctx.respond('❗ Опишите вопрос подробнее (хотя бы несколько слов).')
    now = accounts.now()
    open_count = await ctx.db.fetchval(
        "SELECT COUNT(*) FROM tickets WHERE user_id=$1 AND status != 'closed'", ctx.user_id)
    if open_count >= MAX_OPEN_PER_USER:
        return await ctx.respond(f'⏳ У вас уже {open_count} открытых обращения. Дождитесь ответа поддержки.')
    last = await ctx.db.fetchval('SELECT MAX(created_at) FROM tickets WHERE user_id=$1', ctx.user_id)
    if last and now - last < COOLDOWN:
        return await ctx.respond(f'⏳ Не так быстро: следующее обращение можно отправить через {dur(COOLDOWN - (now - last))}.')
    text = text[:MAX_TEXT]
    tid = await ctx.db.fetchval(
        'INSERT INTO tickets (user_id, peer_id, text, created_at) VALUES ($1, $2, $3, $4) RETURNING id',
        ctx.user_id, ctx.peer_id, text, now)
    await ctx.respond(f'✅ Ваше обращение №{tid} отправлено в поддержку.\nОтвет придёт вам в личные сообщения.',
                      ctx.kb().btn('🏠 Меню', 'menu'))
    name = await ctx.name()
    for sid in await staff_ids(ctx.db):
        kb = ctx.kb()
        kb.btn('✍ Ответить', 'ticket_reply', str(tid), color='positive', u=sid).btn('📋 Тикеты', 'tickets', u=sid)
        await ctx.app.vk.send(
            sid, f'🆕 Новое обращение №{tid}\nОт: {mention(ctx.user_id, name)}\n{SEP}\n{clip(text, 600)}', kb.to_json())


@registry.command('support', names=['поддержка', 'support', 'репорт', 'вопрос'], desc='написать в поддержку',
                  section='misc', usage='<вопрос>')
async def cmd_support(ctx):
    if ctx.args.strip():
        return await create_ticket(ctx, ctx.args)
    mine = await ctx.db.fetch('SELECT * FROM tickets WHERE user_id=$1 ORDER BY id DESC LIMIT 3', ctx.user_id)
    lines = [f'🛟 Поддержка\n{SEP}', 'Отправьте свой вопрос следующим сообщением - его увидят все сотрудники поддержки.']
    if mine:
        lines += ['', 'Ваши обращения:']
        lines += [f'№{t["id"]} · {STATUS[t["status"]]} · {clip(t["text"], 50)}' for t in mine]
    await ctx.ask('support', '\n'.join(lines), ctx.kb().btn('❌ Отмена', 'menu'))


@registry.pending('support')
async def pending_support(ctx, data):
    await create_ticket(ctx, ctx.args)


# ---------------------------------------------------------------------------
# Для сотрудников
# ---------------------------------------------------------------------------

async def _ago(ts: int) -> str:
    return dur(accounts.now() - ts)


@registry.command('tickets', names=['тикеты', 'tickets', 'обращения'], desc='вопросы пользователей', section='staff',
                  staff=1, usage='[страница]')
async def cmd_tickets(ctx):
    argv = ctx.argv
    page = int(argv[0]) if argv and argv[0].isdigit() else 0
    rows = await ctx.db.fetch(
        "SELECT * FROM tickets WHERE status IN ('open', 'answered') ORDER BY CASE WHEN status='open' THEN 0 ELSE 1 END, id")
    items, page, total = paginate(rows, page, PAGE_SIZE)
    lines = [f'📋 Обращения | стр. {page + 1}/{total} · открытых: {len(rows)}\n{SEP}']
    if not rows:
        lines.append('Новых обращений нет 🎉')
    for t in items:
        name = await ctx.name(t['user_id'])
        lines.append(f'№{t["id"]} · {STATUS[t["status"]]} · {mention(t["user_id"], name)} · {await _ago(t["created_at"])} назад\n'
                     f'    {clip(t["text"], 70)}')
    kb = ctx.kb()
    for i, t in enumerate(items):
        if i and i % 2 == 0:
            kb.row()
        kb.btn(f'№{t["id"]}', 'ticket_view', str(t['id']), color='primary' if t['status'] == 'open' else 'secondary')
    kb.row()
    if page > 0:
        kb.btn('◀', 'tickets', str(page - 1))
    if page < total - 1:
        kb.btn('▶', 'tickets', str(page + 1))
    kb.btn('🛠 Панель', 'admin')
    await ctx.respond('\n'.join(lines), kb)


async def _get_ticket(ctx, raw: str):
    if not raw.strip().lstrip('№#').isdigit():
        return None
    return await ctx.db.fetchrow('SELECT * FROM tickets WHERE id=$1', int(raw.strip().lstrip('№#')))


@registry.command('ticket_view', desc='просмотр обращения', section='staff', staff=1, hidden=True)
async def cmd_ticket_view(ctx):
    t = await _get_ticket(ctx, ctx.args)
    if t is None:
        return await ctx.respond('❗ Обращение не найдено', ctx.kb().btn('📋 Тикеты', 'tickets'))
    replies = await ctx.db.fetch('SELECT * FROM ticket_replies WHERE ticket_id=$1 ORDER BY id', t['id'])
    lines = [f'📨 Обращение №{t["id"]} · {STATUS[t["status"]]}\n{SEP}',
             f'От: {mention(t["user_id"], await ctx.name(t["user_id"]))}',
             f'Создано: {await _ago(t["created_at"])} назад', '', t['text']]
    for r in replies:
        lines.append(f'\n💬 {mention(r["staff_id"], await ctx.name(r["staff_id"]))}: {clip(r["text"], 300)}')
    kb = ctx.kb()
    if t['status'] != 'closed':
        kb.btn('✍ Ответить', 'ticket_reply', str(t['id']), color='positive').btn('✅ Закрыть', 'ticket_close', str(t['id']))
    kb.row().btn('📋 К списку', 'tickets')
    await ctx.respond('\n'.join(lines), kb)


@registry.command('ticket_reply', desc='ответить на обращение', section='staff', staff=1, hidden=True)
async def cmd_ticket_reply(ctx):
    t = await _get_ticket(ctx, ctx.args)
    if t is None or t['status'] == 'closed':
        return await ctx.respond('❗ Обращение не найдено или уже закрыто', ctx.kb().btn('📋 Тикеты', 'tickets'))
    await ctx.ask('ticket_reply',
                  f'✍ Ответ на обращение №{t["id"]}\n{SEP}\n{clip(t["text"], 400)}\n\nОтправьте текст ответа следующим сообщением.',
                  ctx.kb().btn('❌ Отмена', 'tickets'), ticket=t['id'])


@registry.pending('ticket_reply')
async def pending_ticket_reply(ctx, data):
    if await ctx.role() < 1:
        return
    await send_reply(ctx, data['ticket'], ctx.args)


async def send_reply(ctx, ticket_id: int, text: str) -> None:
    text = text.strip()
    t = await ctx.db.fetchrow('SELECT * FROM tickets WHERE id=$1', ticket_id)
    if t is None or t['status'] == 'closed':
        return await ctx.respond('❗ Обращение не найдено или уже закрыто')
    if not text:
        return await ctx.respond('❗ Пустой ответ')
    role = await ctx.role()
    await ctx.db.execute('INSERT INTO ticket_replies (ticket_id, staff_id, text, ts) VALUES ($1, $2, $3, $4)',
                         ticket_id, ctx.user_id, text[:MAX_TEXT], accounts.now())
    await ctx.db.execute("UPDATE tickets SET status='answered' WHERE id=$1 AND status='open'", ticket_id)
    msg = (f'📩 Ответ поддержки на обращение №{ticket_id}\n{SEP}\n{text[:MAX_TEXT]}\n\n'
           f'— {mention(ctx.user_id, await ctx.name())} ({staff_name(role)})')
    delivered = await ctx.app.vk.send(t['user_id'], msg, ctx.kb().btn('🛟 Написать ещё', 'support', u=t['user_id']).to_json())
    note = 'Пользователь получил его в личные сообщения.' if delivered else \
        '⚠ Не удалось доставить: пользователь не открывал диалог с ботом. Ответ сохранён.'
    await ctx.respond(f'✅ Ответ на обращение №{ticket_id} отправлен. {note}',
                      ctx.kb().btn('📋 Тикеты', 'tickets').btn('✅ Закрыть', 'ticket_close', str(ticket_id)))


@registry.command('reply', names=['ответ', 'ответить', 'reply'], desc='ответить на обращение', section='staff',
                  staff=1, usage='<номер> <текст>')
async def cmd_reply(ctx):
    argv = ctx.argv
    if len(argv) < 2 or not argv[0].lstrip('№#').isdigit():
        return await ctx.respond('❗ Формат: /ответ <номер обращения> <текст>\nСписок обращений: /тикеты',
                                 ctx.kb().btn('📋 Тикеты', 'tickets'))
    text = ctx.args.split(None, 1)[1]
    await send_reply(ctx, int(argv[0].lstrip('№#')), text)


@registry.command('ticket_close', names=['закрыть', 'closeticket'], desc='закрыть обращение', section='staff',
                  staff=1, usage='<номер>')
async def cmd_ticket_close(ctx):
    t = await _get_ticket(ctx, ctx.args)
    if t is None:
        return await ctx.respond('❗ Формат: /закрыть <номер обращения>', ctx.kb().btn('📋 Тикеты', 'tickets'))
    row = await ctx.db.fetchrow(
        "UPDATE tickets SET status='closed', closed_by=$2, closed_at=$3 WHERE id=$1 AND status != 'closed' RETURNING user_id",
        t['id'], ctx.user_id, accounts.now())
    if row is None:
        return await ctx.respond('ℹ Это обращение уже закрыто', ctx.kb().btn('📋 Тикеты', 'tickets'))
    await ctx.app.vk.send(row['user_id'], f'✅ Ваше обращение №{t["id"]} закрыто. Если вопрос остался - напишите снова: /поддержка')
    await ctx.respond(f'✅ Обращение №{t["id"]} закрыто', ctx.kb().btn('📋 Тикеты', 'tickets'))
