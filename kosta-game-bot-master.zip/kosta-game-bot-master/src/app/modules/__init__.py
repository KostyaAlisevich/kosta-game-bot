"""Подключение всех модулей с командами (импорт регистрирует команды в реестре)."""
import importlib

MODULES = [
    'start',
    'economy',
    'study',
    'work',
    'assets',
    'bank',
    'market',
    'family',
    'treasury',
    'games',
    'promo',
    'support',
    'moderation',
    'admin',
]


async def load_all(app) -> None:
    """Подготовка при старте: данные рынка."""
    from ..services import market_engine
    await market_engine.seed_market(app.db)


# Команды регистрируются при импорте модулей
for _name in MODULES:
    importlib.import_module(f'{__name__}.{_name}')
