"""Управление беседой (как у чат-менеджера): кик, бан, мут, варны, роли, правила, приветствие."""
import re

from ..framework.registry import registry
from ..roles import CHAT_CREATOR, DEFAULT_CHAT_ROLES
from ..services import accounts, chats, wealth
from ..util.fmt import SEP, dur, mention, rub

MAX_MUTE = 7 * 86400
DEFAULT_MUTE = 30 * 60
RULES_LIMIT = 3000
GREETING_LIMIT = 1000


def parse_duration(token: str) -> int | None:
    """'30' / '30м' - минуты, '2ч' - часы, '1д' - дни, '45с' - секунды. Возвращает секунды."""
    m = re.fullmatch(r'(\d+)\s*([смчдmhd]?)', token.strip().lower().replace('мин', 'м'))
    if not m:
        return None
    value, unit = int(m.group(1)), m.group(2) or 'м'
    mult = {'с': 1, 'м': 60, 'm': 60, 'ч': 3600, 'h': 3600, 'д': 86400, 'd': 86400}[unit]
    return value * mult


async def _member(ctx, uid: int):
    return await chats.get_member(ctx.db, ctx.peer_id, uid)


async def _target(ctx, action: str):
    """Цель модерации: (user_id, остаток аргументов). Проверяет, что действие допустимо. None - уже ответили."""
    target, rest = await ctx.target(register=False)
    if target is None:
        await ctx.respond(f'❗ Укажите пользователя: @имя, ссылка, id или ответом на сообщение.\n'
                          f'Пример: /{action} @ivan')
        return None
    if target == ctx.user_id:
        await ctx.respond('❗ Нельзя применять это к себе')
        return None
    actor = await ctx.chat_level()
    if await chats.member_level(ctx.db, ctx.peer_id, target) >= actor:
        await ctx.respond('🚫 У этого участника роль не ниже вашей - действие недоступно')
        return None
    return target, rest


async def _name(ctx, uid: int) -> str:
    await accounts.ensure_target(ctx.app, uid)
    return mention(uid, await accounts.display_name(ctx.app, uid))


# ---------------------------------------------------------------------------
# Хуки: мут и бан беседы, приветствие
# ---------------------------------------------------------------------------

@registry.on_pre_message
async def enforce(app, inc, chat) -> bool:
    """Считает сообщения, удаляет сообщения замученных и забаненных. True - сообщение поглощено."""
    if not chat['activated']:
        return False
    now = accounts.now()
    row = await app.db.fetchrow(
        'INSERT INTO chat_members (peer_id, user_id, msgs, last_msg) VALUES ($1, $2, 1, $3) '
        'ON CONFLICT (peer_id, user_id) DO UPDATE SET msgs = chat_members.msgs + 1, last_msg = EXCLUDED.last_msg '
        'RETURNING muted_until, banned, role', inc.peer_id, inc.from_id, now)
    if row['banned']:
        await app.vk.kick(inc.peer_id, inc.from_id)
        if inc.cmid:
            await app.vk.delete(inc.peer_id, inc.cmid)
        return True
    if row['muted_until'] > now and inc.cmid and not inc.action:
        await app.vk.delete(inc.peer_id, inc.cmid)
        return True
    return False


@registry.on_chat_event
async def member_joined(app, inc) -> bool:
    action = inc.action or {}
    if action.get('type') not in ('chat_invite_user', 'chat_invite_user_by_link'):
        return False
    uid = action.get('member_id')
    chat = await chats.get_chat(app.db, inc.peer_id)
    if not uid or uid <= 0 or not chat['activated']:
        return False
    member = await chats.get_member(app.db, inc.peer_id, uid)
    if member['banned']:
        await app.vk.kick(inc.peer_id, uid)
        await app.vk.send(inc.peer_id, f'🚫 {mention(uid, await accounts.display_name(app, uid))} находится в бане этой беседы и исключён.')
        return True
    if chat['greeting']:
        await accounts.ensure_target(app, uid)
        name = mention(uid, await accounts.display_name(app, uid))
        await app.vk.send(inc.peer_id, chat['greeting'].replace('{имя}', name).replace('{name}', name))
        return True
    return False


# ---------------------------------------------------------------------------
# Кик, бан
# ---------------------------------------------------------------------------

@registry.command('kick', names=['кик', 'kick', 'исключить'], desc='исключить из беседы', section='moderation',
                  where='chat', level=60, usage='<кому> [причина]')
async def cmd_kick(ctx):
    res = await _target(ctx, 'кик')
    if res is None:
        return
    target, rest = res
    ok = await ctx.app.vk.kick(ctx.peer_id, target)
    reason = f'\nПричина: {" ".join(rest)}' if rest else ''
    if not ok:
        return await ctx.respond('⚠ Не удалось исключить участника. Бот должен быть администратором беседы, '
                                 'а исключаемый - не администратором.')
    await ctx.respond(f'👢 {await _name(ctx, target)} исключён(а) из беседы{reason}')


@registry.command('ban', names=['бан', 'ban'], desc='забанить в беседе', section='moderation', where='chat',
                  level=80, usage='<кому> [причина]')
async def cmd_ban(ctx):
    res = await _target(ctx, 'бан')
    if res is None:
        return
    target, rest = res
    await _member(ctx, target)
    await ctx.db.execute('UPDATE chat_members SET banned=1, role=0 WHERE peer_id=$1 AND user_id=$2', ctx.peer_id, target)
    kicked = await ctx.app.vk.kick(ctx.peer_id, target)
    reason = f'\nПричина: {" ".join(rest)}' if rest else ''
    note = '' if kicked else '\n⚠ Исключить не удалось (нужны права администратора у бота), но его сообщения будут удаляться.'
    await ctx.respond(f'⛔ {await _name(ctx, target)} забанен(а) в беседе{reason}{note}',
                      ctx.kb().btn('♻ Разбанить', 'unban', str(target)))


@registry.command('unban', names=['разбан', 'unban'], desc='снять бан в беседе', section='moderation', where='chat',
                  level=80, usage='<кому>')
async def cmd_unban(ctx):
    arg = ctx.args.strip()
    if arg.isdigit() and ctx.via_button:      # кнопка «Разбанить» передаёт id
        target = int(arg)
    else:
        target, _ = await ctx.target(register=False)
    if target is None:
        return await ctx.respond('❗ Укажите пользователя: /разбан @имя')
    row = await ctx.db.fetchrow(
        'UPDATE chat_members SET banned=0 WHERE peer_id=$1 AND user_id=$2 AND banned=1 RETURNING user_id',
        ctx.peer_id, target)
    if row is None:
        return await ctx.respond('ℹ Этот участник не в бане')
    await ctx.respond(f'✅ {await _name(ctx, target)} разбанен(а). Теперь его можно снова пригласить в беседу.')


@registry.command('banlist', names=['банлист', 'banlist'], desc='список забаненных', section='moderation',
                  where='chat', level=60)
async def cmd_banlist(ctx):
    rows = await ctx.db.fetch('SELECT user_id FROM chat_members WHERE peer_id=$1 AND banned=1', ctx.peer_id)
    lines = [f'⛔ Баны беседы\n{SEP}']
    lines += [f'• {await _name(ctx, r["user_id"])}' for r in rows] or ['Список пуст.']
    await ctx.respond('\n'.join(lines))


# ---------------------------------------------------------------------------
# Мут
# ---------------------------------------------------------------------------

@registry.command('mute', names=['мут', 'mute'], desc='заглушить участника', section='moderation', where='chat',
                  level=60, usage='<кому> [время] [причина]')
async def cmd_mute(ctx):
    res = await _target(ctx, 'мут')
    if res is None:
        return
    target, rest = res
    seconds = DEFAULT_MUTE
    if rest:
        parsed = parse_duration(rest[0])
        if parsed is not None:
            seconds, rest = parsed, rest[1:]
    if seconds <= 0 or seconds > MAX_MUTE:
        return await ctx.respond('❗ Время мута: от 1 секунды до 7 суток. Примеры: 30, 2ч, 1д')
    await _member(ctx, target)
    await ctx.db.execute('UPDATE chat_members SET muted_until=$3 WHERE peer_id=$1 AND user_id=$2',
                         ctx.peer_id, target, accounts.now() + seconds)
    reason = f'\nПричина: {" ".join(rest)}' if rest else ''
    await ctx.respond(f'🔇 {await _name(ctx, target)} заглушен(а) на {dur(seconds)}{reason}\n'
                      'Сообщения будут удаляться (бот должен быть администратором).',
                      ctx.kb().btn('🔊 Снять мут', 'unmute', str(target)))


@registry.command('unmute', names=['размут', 'unmute'], desc='снять мут', section='moderation', where='chat',
                  level=60, usage='<кому>')
async def cmd_unmute(ctx):
    arg = ctx.args.strip()
    target = int(arg) if (arg.isdigit() and ctx.via_button) else (await ctx.target(register=False))[0]
    if target is None:
        return await ctx.respond('❗ Укажите пользователя: /размут @имя')
    row = await ctx.db.fetchrow(
        'UPDATE chat_members SET muted_until=0 WHERE peer_id=$1 AND user_id=$2 AND muted_until > $3 RETURNING user_id',
        ctx.peer_id, target, accounts.now())
    if row is None:
        return await ctx.respond('ℹ Этот участник не заглушен')
    await ctx.respond(f'🔊 {await _name(ctx, target)} снова может писать')


@registry.command('mutelist', names=['мутлист', 'mutelist'], desc='список заглушенных', section='moderation',
                  where='chat', level=60)
async def cmd_mutelist(ctx):
    now = accounts.now()
    rows = await ctx.db.fetch('SELECT user_id, muted_until FROM chat_members WHERE peer_id=$1 AND muted_until > $2',
                              ctx.peer_id, now)
    lines = [f'🔇 Заглушённые\n{SEP}']
    lines += [f'• {await _name(ctx, r["user_id"])} - ещё {dur(r["muted_until"] - now)}' for r in rows] or ['Список пуст.']
    await ctx.respond('\n'.join(lines))


# ---------------------------------------------------------------------------
# Предупреждения
# ---------------------------------------------------------------------------

@registry.command('warn', names=['варн', 'warn', 'пред'], desc='выдать предупреждение', section='moderation',
                  where='chat', level=60, usage='<кому> [причина]')
async def cmd_warn(ctx):
    res = await _target(ctx, 'варн')
    if res is None:
        return
    target, rest = res
    chat = await ctx.chat()
    await _member(ctx, target)
    row = await ctx.db.fetchrow(
        'UPDATE chat_members SET warns = warns + 1 WHERE peer_id=$1 AND user_id=$2 RETURNING warns', ctx.peer_id, target)
    warns, limit = row['warns'], chat['warn_limit']
    reason = f'\nПричина: {" ".join(rest)}' if rest else ''
    name = await _name(ctx, target)
    if warns >= limit:
        await ctx.db.execute('UPDATE chat_members SET warns=0 WHERE peer_id=$1 AND user_id=$2', ctx.peer_id, target)
        kicked = await ctx.app.vk.kick(ctx.peer_id, target)
        tail = 'исключён(а) из беседы' if kicked else 'достиг(ла) лимита (исключить не удалось - нужны права бота)'
        return await ctx.respond(f'⚠ {name} получил(а) предупреждение {warns}/{limit}{reason}\n🚪 {name} {tail}')
    await ctx.respond(f'⚠ {name} получил(а) предупреждение {warns}/{limit}{reason}',
                      ctx.kb().btn('➖ Снять варн', 'unwarn', str(target)))


@registry.command('unwarn', names=['снятьварн', 'unwarn', 'разварн'], desc='снять предупреждение', section='moderation',
                  where='chat', level=60, usage='<кому>')
async def cmd_unwarn(ctx):
    arg = ctx.args.strip()
    target = int(arg) if (arg.isdigit() and ctx.via_button) else (await ctx.target(register=False))[0]
    if target is None:
        return await ctx.respond('❗ Укажите пользователя: /снятьварн @имя')
    row = await ctx.db.fetchrow(
        'UPDATE chat_members SET warns = warns - 1 WHERE peer_id=$1 AND user_id=$2 AND warns > 0 RETURNING warns',
        ctx.peer_id, target)
    if row is None:
        return await ctx.respond('ℹ У участника нет предупреждений')
    chat = await ctx.chat()
    await ctx.respond(f'✅ Предупреждение снято: {await _name(ctx, target)} - {row["warns"]}/{chat["warn_limit"]}')


@registry.command('warns', names=['варны', 'warns'], desc='предупреждения участника', section='moderation',
                  where='chat', usage='[кому]')
async def cmd_warns(ctx):
    target, _ = await ctx.target(register=False)
    target = target or ctx.user_id
    chat = await ctx.chat()
    member = await _member(ctx, target)
    await ctx.respond(f'⚠ Предупреждения {await _name(ctx, target)}: {member["warns"]}/{chat["warn_limit"]}')


@registry.command('warnlimit', names=['варнлимит', 'warnlimit'], desc='лимит предупреждений до исключения (2-10)',
                  section='moderation', where='chat', level=90, usage='<число>')
async def cmd_warnlimit(ctx):
    argv = ctx.argv
    if not argv or not argv[0].isdigit() or not 2 <= int(argv[0]) <= 10:
        return await ctx.respond('❗ Укажите число от 2 до 10. Пример: /варнлимит 3')
    await ctx.db.execute('UPDATE chats SET warn_limit=$2 WHERE peer_id=$1', ctx.peer_id, int(argv[0]))
    await ctx.respond(f'✅ Лимит предупреждений: {argv[0]}. После этого участник исключается из беседы.')


# ---------------------------------------------------------------------------
# Роли
# ---------------------------------------------------------------------------

@registry.command('role', names=['роль', 'role'], desc='выдать роль участнику', section='moderation', where='chat',
                  level=90, usage='<кому> <уровень 0-99>')
async def cmd_role(ctx):
    res = await _target(ctx, 'роль')
    if res is None:
        return
    target, rest = res
    if not rest or not rest[0].isdigit():
        return await ctx.respond('❗ Укажите уровень роли: /роль @имя 80 (0 - снять роль). Список ролей: /роли')
    level = int(rest[0])
    actor = await ctx.chat_level()
    if level >= actor or level >= CHAT_CREATOR:
        return await ctx.respond(f'🚫 Выдать можно роль только ниже вашей (до {min(actor - 1, 99)})')
    await chats.set_member_role(ctx.db, ctx.peer_id, target, level)
    name = await chats.role_name(ctx.db, ctx.peer_id, level)
    text = (f'✅ {await _name(ctx, target)}: роль снята' if level == 0
            else f'✅ {await _name(ctx, target)} теперь «{name}» (уровень {level})')
    await ctx.respond(text)


@registry.command('roles', names=['роли', 'roles'], desc='список ролей беседы', section='moderation', where='chat')
async def cmd_roles(ctx):
    custom = await chats.custom_roles(ctx.db, ctx.peer_id)
    names = {**DEFAULT_CHAT_ROLES, **custom}
    counts = {r['role']: r['n'] for r in await ctx.db.fetch(
        'SELECT role, COUNT(*) AS n FROM chat_members WHERE peer_id=$1 AND role > 0 GROUP BY role', ctx.peer_id)}
    lines = [f'🎭 Роли беседы\n{SEP}']
    for level in sorted(names, reverse=True):
        mark = ' ✏' if level in custom else ''
        lines.append(f'{level} - {names[level]}{mark} ({counts.get(level, 0)} чел.)')
    for level in sorted(set(counts) - set(names), reverse=True):
        lines.append(f'{level} - (без названия) ({counts[level]} чел.)')
    lines += ['', 'Выдать: /роль @имя <уровень> · Создать название: /создатьроль <уровень> <название>']
    await ctx.respond('\n'.join(lines))


@registry.command('createrole', names=['создатьроль', 'createrole'], desc='создать (назвать) роль', section='moderation',
                  where='chat', level=90, usage='<уровень> <название>')
async def cmd_createrole(ctx):
    argv = ctx.argv
    actor = await ctx.chat_level()
    if len(argv) < 2 or not argv[0].isdigit():
        return await ctx.respond('❗ Формат: /создатьроль <уровень 1-89> <название>\nПример: /создатьроль 70 Помощник админа')
    level = int(argv[0])
    name = ' '.join(argv[1:])[:24]
    if not 1 <= level < min(actor, 100):
        return await ctx.respond(f'🚫 Уровень роли: от 1 до {min(actor, 100) - 1} (ниже вашей роли)')
    await ctx.db.execute(
        'INSERT INTO chat_roles (peer_id, level, name) VALUES ($1, $2, $3) '
        'ON CONFLICT (peer_id, level) DO UPDATE SET name = EXCLUDED.name', ctx.peer_id, level, name)
    await ctx.respond(f'✅ Роль уровня {level} теперь называется «{name}». Выдать: /роль @имя {level}')


@registry.command('deleterole', names=['удалитьроль', 'deleterole'], desc='удалить своё название роли',
                  section='moderation', where='chat', level=90, usage='<уровень>')
async def cmd_deleterole(ctx):
    argv = ctx.argv
    if not argv or not argv[0].isdigit():
        return await ctx.respond('❗ Формат: /удалитьроль <уровень>')
    level = int(argv[0])
    if level >= await ctx.chat_level():
        return await ctx.respond('🚫 Нельзя менять роли не ниже вашей')
    row = await ctx.db.fetchrow('DELETE FROM chat_roles WHERE peer_id=$1 AND level=$2 RETURNING level', ctx.peer_id, level)
    if row is None:
        return await ctx.respond('ℹ Для этого уровня нет вашего названия')
    await ctx.respond(f'🗑 Название роли уровня {level} удалено (теперь «{await chats.role_name(ctx.db, ctx.peer_id, level)}»)')


@registry.command('staff', names=['админы', 'стафф', 'staff'], desc='участники с ролями', section='moderation',
                  where='chat')
async def cmd_staff(ctx):
    rows = await ctx.db.fetch('SELECT user_id, role FROM chat_members WHERE peer_id=$1 AND role > 0 ORDER BY role DESC',
                              ctx.peer_id)
    lines = [f'👮 Управляющие беседы\n{SEP}']
    for r in rows:
        lines.append(f'{r["role"]} · {await chats.role_name(ctx.db, ctx.peer_id, r["role"])}: {await _name(ctx, r["user_id"])}')
    if not rows:
        lines.append('Пока никого. Роли выдаёт администратор: /роль @имя 60')
    await ctx.respond('\n'.join(lines))


# ---------------------------------------------------------------------------
# Правила и приветствие
# ---------------------------------------------------------------------------

@registry.command('rules', names=['правила', 'rules'], desc='правила беседы (с роли 90 - задать)', section='moderation',
                  where='chat', usage='[текст]')
async def cmd_rules(ctx):
    text = ctx.args.strip()
    chat = await ctx.chat()
    if text:
        if await ctx.chat_level() < 90:
            return await ctx.respond('🚫 Задавать правила может участник с ролью 90 и выше. Прочитать: /правила')
        if text.lower() in ('очистить', 'удалить', 'clear'):
            await ctx.db.execute("UPDATE chats SET rules='' WHERE peer_id=$1", ctx.peer_id)
            return await ctx.respond('🗑 Правила беседы удалены')
        if len(text) > RULES_LIMIT:
            return await ctx.respond(f'❗ Слишком длинный текст: максимум {RULES_LIMIT} символов')
        await ctx.db.execute('UPDATE chats SET rules=$2 WHERE peer_id=$1', ctx.peer_id, text)
        return await ctx.respond('✅ Правила беседы сохранены. Любой участник увидит их по команде /правила')
    if not chat['rules']:
        hint = '\nАдминистратор может задать их: /правила <текст>' if await ctx.chat_level() >= 90 else ''
        return await ctx.respond('📜 Правила беседы пока не заданы.' + hint)
    await ctx.respond(f'📜 Правила беседы\n{SEP}\n{chat["rules"]}')


@registry.command('greeting', names=['приветствие', 'greeting'], desc='приветствие новичков (с роли 90)',
                  section='moderation', where='chat', usage='[текст | выкл]')
async def cmd_greeting(ctx):
    text = ctx.args.strip()
    chat = await ctx.chat()
    if not text:
        if not chat['greeting']:
            return await ctx.respond('👋 Приветствие не задано. Администратор: /приветствие Привет, {имя}! Загляни в /правила')
        return await ctx.respond(f'👋 Приветствие беседы:\n{chat["greeting"]}')
    if await ctx.chat_level() < 90:
        return await ctx.respond('🚫 Менять приветствие может участник с ролью 90 и выше')
    if text.lower() in ('выкл', 'off', 'удалить', 'очистить'):
        await ctx.db.execute("UPDATE chats SET greeting='' WHERE peer_id=$1", ctx.peer_id)
        return await ctx.respond('✅ Приветствие отключено')
    if len(text) > GREETING_LIMIT:
        return await ctx.respond(f'❗ Слишком длинный текст: максимум {GREETING_LIMIT} символов')
    await ctx.db.execute('UPDATE chats SET greeting=$2 WHERE peer_id=$1', ctx.peer_id, text)
    await ctx.respond('✅ Приветствие сохранено. Вместо {имя} подставится упоминание новичка.')


# ---------------------------------------------------------------------------
# Профиль и активность
# ---------------------------------------------------------------------------

@registry.command('profile', names=['профиль', 'кто', 'profile', 'whois'], desc='профиль участника беседы',
                  section='moderation', where='chat', usage='[кому]')
async def cmd_profile(ctx):
    target, _ = await ctx.target(register=False)
    target = target or ctx.user_id
    await accounts.ensure_target(ctx.app, target)
    chat = await ctx.chat()
    member = await _member(ctx, target)
    now = accounts.now()
    rank = await ctx.db.fetchval(
        'SELECT COUNT(*) FROM chat_members WHERE peer_id=$1 AND msgs > $2', ctx.peer_id, member['msgs']) + 1
    capital = await wealth.net_worth(ctx.db, ctx.scope, target)
    status = []
    if member['banned']:
        status.append('⛔ в бане')
    if member['muted_until'] > now:
        status.append(f'🔇 мут ещё {dur(member["muted_until"] - now)}')
    lines = [
        f'👤 Профиль\n{SEP}',
        f'{await _name(ctx, target)}',
        f'🎭 Роль: {await chats.role_name(ctx.db, ctx.peer_id, member["role"])} ({member["role"]})',
        f'⚠ Предупреждения: {member["warns"]}/{chat["warn_limit"]}',
        f'💬 Сообщений: {member["msgs"]} (место #{rank})',
        f'💎 Капитал в этой беседе: {rub(capital)}',
    ]
    if status:
        lines.append(' · '.join(status))
    await ctx.respond('\n'.join(lines))


@registry.command('top', names=['топ', 'top'], desc='самые активные участники беседы', section='moderation',
                  where='chat')
async def cmd_top(ctx):
    rows = await ctx.db.fetch(
        'SELECT user_id, msgs FROM chat_members WHERE peer_id=$1 AND msgs > 0 ORDER BY msgs DESC LIMIT 10', ctx.peer_id)
    lines = [f'🏅 Самые активные\n{SEP}']
    medals = ['🥇', '🥈', '🥉']
    for i, r in enumerate(rows):
        lines.append(f'{medals[i] if i < 3 else str(i + 1) + ".":<3} {await _name(ctx, r["user_id"])} - {r["msgs"]} сообщ.')
    if not rows:
        lines.append('Пока нет данных: считаются сообщения после активации бота.')
    await ctx.respond('\n'.join(lines))
