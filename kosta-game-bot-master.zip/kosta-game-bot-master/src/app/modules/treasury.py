"""Казна беседы, налоги и экономические команды управляющих: выдать, забрать, сбросить."""
from ..framework.registry import registry
from ..services import accounts
from ..util.fmt import SEP, money, rub
from ..util.money import parse_money

MAX_TAX = 30


async def _clear_economy(db, scope: int, uid: int) -> None:
    """Полный сброс экономики игрока в одном scope."""
    for table in ('wallets', 'owned_assets', 'holdings', 'edu_progress', 'game_sessions', 'family_invites', 'transactions'):
        await db.execute(f'DELETE FROM {table} WHERE scope=$1 AND user_id=$2', scope, uid)
    fam = await db.fetchrow('SELECT f.id, f.owner_id FROM family_members m JOIN families f ON f.id = m.family_id '
                            'WHERE m.scope=$1 AND m.user_id=$2', scope, uid)
    if fam is not None:
        if fam['owner_id'] == uid:       # глава сбрасывается - семья распускается
            await db.execute('DELETE FROM family_members WHERE family_id=$1', fam['id'])
            await db.execute('DELETE FROM family_invites WHERE family_id=$1', fam['id'])
            await db.execute('DELETE FROM families WHERE id=$1', fam['id'])
        else:
            await db.execute('DELETE FROM family_members WHERE scope=$1 AND user_id=$2', scope, uid)


# ---------------------------------------------------------------------------
# /казна
# ---------------------------------------------------------------------------

@registry.command('treasury', names=['казна', 'treasury'], desc='казна беседы и налоги', section='family', where='chat')
async def cmd_treasury(ctx):
    chat = await ctx.chat()
    level = await ctx.chat_level()
    lines = [f'🏛 Казна беседы\n{SEP}', f'💰 В казне: {rub(chat["treasury"])}',
             f'📊 Налог: {chat["tax"]}% с зарплат и доходов бизнеса',
             '', 'Налоги пополняют казну, а управляющие беседы могут выплачивать деньги участникам.']
    if level >= 80:
        lines.append('Выплата: /казнавыдать <кому> <сумма> (с роли 80)')
    if level >= 90:
        lines.append(f'Налог: /налог <0-{MAX_TAX}> (с роли 90)')
    await ctx.respond('\n'.join(lines), ctx.kb().btn('🏆 Форбс', 'forbes').btn('🏠 Меню', 'menu'))


@registry.command('tax', names=['налог', 'tax'], desc='налог беседы (0-30%)', section='family', where='chat', level=90,
                  usage='<процент>')
async def cmd_tax(ctx):
    argv = ctx.argv
    if not argv or not argv[0].rstrip('%').isdigit():
        return await ctx.respond(f'❗ Укажите налог в процентах от 0 до {MAX_TAX}. Пример: /налог 10')
    rate = int(argv[0].rstrip('%'))
    if not 0 <= rate <= MAX_TAX:
        return await ctx.respond(f'❗ Налог должен быть от 0 до {MAX_TAX}%')
    await ctx.db.execute('UPDATE chats SET tax=$2 WHERE peer_id=$1', ctx.peer_id, rate)
    await ctx.respond(f'✅ Налог беседы теперь {rate}%')


@registry.command('treasury_give', names=['казнавыдать', 'казна-выдать', 'treasurygive'],
                  desc='выплата из казны', section='family', where='chat', level=80, usage='<кому> <сумма>')
async def cmd_treasury_give(ctx):
    target, rest = await ctx.target()
    parsed = parse_money(rest) if rest else None
    if target is None or parsed is None or parsed[1] != 'rub':
        return await ctx.respond('❗ Формат: /казнавыдать <кому> <сумма в рублях>\nПример: /казнавыдать @ivan 1000')
    amount = parsed[0]
    await accounts.ensure_wallet(ctx.db, ctx.scope, target)
    async with ctx.db.transaction() as tx:
        row = await tx.fetchrow(
            'UPDATE chats SET treasury = treasury - $2 WHERE peer_id=$1 AND treasury >= $2 RETURNING treasury',
            ctx.peer_id, amount)
        if row is None:
            chat = await ctx.chat()
            return await ctx.respond(f'❗ В казне недостаточно средств: {rub(chat["treasury"])}')
        await accounts.change(tx, ctx.scope, target, amount, 'rub', 'treasury', f'выплата от {ctx.user_id}')
    await ctx.respond(f'🏛 Из казны выплачено {rub(amount)} → {await ctx.mention(target)}\n'
                      f'Остаток казны: {rub(row["treasury"])}')


# ---------------------------------------------------------------------------
# /эковыдать, /экозабрать, /экосброс
# ---------------------------------------------------------------------------

@registry.command('eco_give', names=['эковыдать', 'ecogive'], desc='начислить деньги', section='family', level=80,
                  usage='<кому> <сумма>')
async def cmd_eco_give(ctx):
    target, rest = await ctx.target()
    parsed = parse_money(rest) if rest else None
    if target is None or parsed is None:
        return await ctx.respond('❗ Формат: /эковыдать <кому> <сумма> [валюта]\nПример: /эковыдать @ivan 5000')
    minor, cur, _ = parsed
    await accounts.ensure_wallet(ctx.db, ctx.scope, target)
    await accounts.change(ctx.db, ctx.scope, target, minor, cur, 'admin', f'выдал {ctx.user_id}')
    await ctx.respond(f'✅ {await ctx.mention(target)} начислено {money(cur, minor)}')


@registry.command('eco_take', names=['экозабрать', 'ecotake'], desc='списать деньги', section='family', level=80,
                  usage='<кому> <сумма>')
async def cmd_eco_take(ctx):
    target, rest = await ctx.target()
    parsed = parse_money(rest) if rest else None
    if target is None or parsed is None:
        return await ctx.respond('❗ Формат: /экозабрать <кому> <сумма> [валюта]\nПример: /экозабрать @ivan 5000')
    minor, cur, _ = parsed
    w = await accounts.ensure_wallet(ctx.db, ctx.scope, target)
    have = w[cur]
    taken = min(minor, have)
    if taken <= 0:
        return await ctx.respond(f'ℹ У {await ctx.mention(target)} нет такой валюты')
    await accounts.change(ctx.db, ctx.scope, target, -taken, cur, 'admin', f'списал {ctx.user_id}')
    await ctx.respond(f'✅ У {await ctx.mention(target)} списано {money(cur, taken)}'
                      + (f' (запрошено {money(cur, minor)}, больше нет)' if taken < minor else ''))


@registry.command('eco_reset', names=['экосброс', 'ecoreset'], desc='обнулить экономику пользователя в беседе',
                  section='family', level=100, usage='<кому>')
async def cmd_eco_reset(ctx):
    target, _ = await ctx.target()
    if target is None:
        return await ctx.respond('❗ Формат: /экосброс <кому>. Это удалит деньги, имущество, бумаги и дипломы игрока в этой экономике.')
    place = 'этой беседе' if ctx.is_chat else 'личных сообщениях'
    kb = (ctx.kb().btn('✅ Да, обнулить', 'eco_reset_do', str(target), color='negative')
          .btn('❌ Отмена', 'menu'))
    await ctx.respond(f'⚠ Обнулить экономику {await ctx.mention(target)} в {place}?\nЭто действие необратимо.', kb)


@registry.command('eco_reset_do', desc='подтверждение сброса экономики', section='family', level=100, hidden=True)
async def cmd_eco_reset_do(ctx):
    arg = ctx.args.strip()
    if not arg.isdigit():
        return
    target = int(arg)
    async with ctx.db.transaction() as tx:
        await _clear_economy(tx, ctx.scope, target)
    await ctx.respond(f'🧹 Экономика {await ctx.mention(target)} обнулена')
