"""Игры на деньги: монетка, кости, слоты, рулетка, камень-ножницы-бумага и блэкджек."""
import json
import random

from ..framework.registry import registry
from ..services import accounts
from ..util.fmt import SEP, rub
from ..util.money import _value

RNG = random.Random()          # в тестах подменяется на детерминированный
MIN_BET = 10
MAX_BET = 1_000_000
PRESETS = (100, 1000, 10000, 100000)

# коэффициенты выплат (числитель, знаменатель): выплата = ставка * a // b, включая возврат ставки
COIN_PAYOUT = (195, 100)
DICE_PAYOUT = (195, 100)
RPS_PAYOUT = (190, 100)
ROULETTE_COLOR_PAYOUT = (2, 1)
ROULETTE_NUMBER_PAYOUT = (36, 1)
BJ_WIN, BJ_NATURAL = (2, 1), (5, 2)

DIE_FACES = '⚀⚁⚂⚃⚄⚅'
RED_NUMBERS = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}

# слоты: (символ, вес, выплата за три одинаковых в «х ставки»)
SLOT_SYMBOLS = (('🍒', 30, 6), ('🍋', 25, 10), ('🔔', 20, 15), ('⭐', 14, 30), ('7️⃣', 8, 100), ('💎', 3, 500))
SLOT_PAIR_PAYOUT = (7, 10)     # любая пара: возврат 70% ставки


def pay(bet: int, ratio: tuple[int, int]) -> int:
    return bet * ratio[0] // ratio[1]


async def settle(ctx, bet: int, payout: int, note: str) -> int | None:
    """Списывает ставку и начисляет выплату в одной транзакции. None - не хватило денег."""
    async with ctx.db.transaction() as tx:
        if await accounts.change(tx, ctx.scope, ctx.user_id, -bet, 'rub', 'game', note) is None:
            return None
        if payout:
            await accounts.change(tx, ctx.scope, ctx.user_id, payout, 'rub', 'game', note + ' (выигрыш)')
    return (await ctx.wallet())['rub']


async def parse_bet(ctx, token: str | None):
    """Возвращает ставку (int) или None; сама отвечает пользователю при ошибке."""
    w = await ctx.wallet()
    if token is None:
        return None
    value = _value(token, w['rub'])
    bet = int(value) if value else 0
    if bet < MIN_BET:
        await ctx.respond(f'❗ Минимальная ставка: {rub(MIN_BET)}. Пример: /монетка 100')
        return None
    if bet > MAX_BET:
        await ctx.respond(f'❗ Максимальная ставка: {rub(MAX_BET)}')
        return None
    if bet > w['rub']:
        await ctx.respond(f'❗ Недостаточно средств. На руках {rub(w["rub"])}',
                          ctx.kb().btn('💼 Заработать', 'jobs').btn('🎮 Игры', 'games'))
        return None
    return bet


def bet_kb(ctx, cmd: str, extra: str = '', skip_all: bool = False):
    kb = ctx.kb()
    for i, p in enumerate(PRESETS):
        kb.btn(rub(p), cmd, f'{p} {extra}'.strip())
    if not skip_all:
        kb.row().btn('Всё', cmd, f'все {extra}'.strip(), color='negative')
    kb.btn('🎮 Игры', 'games').btn('🏠 Меню', 'menu')
    return kb


def result_text(title: str, lines: list[str], bet: int, payout: int, balance: int) -> str:
    diff = payout - bet
    if diff > 0:
        verdict = f'🎉 Выигрыш: +{rub(diff)}'
    elif diff == 0:
        verdict = '🤝 Ставка возвращена'
    else:
        verdict = f'😔 Проигрыш: −{rub(-diff)}'
    return '\n'.join([f'{title}\n{SEP}', *lines, '', f'Ставка: {rub(bet)}', verdict, f'💳 Баланс: {rub(balance)}'])


def again_kb(ctx, cmd: str, args: str):
    return (ctx.kb().btn('🔁 Ещё раз', cmd, args, color='positive').btn('🎮 Игры', 'games').btn('🏠 Меню', 'menu'))


# ---------------------------------------------------------------------------
# /игры
# ---------------------------------------------------------------------------

@registry.command('games', names=['игры', 'games', 'game'], desc='меню игр', section='games')
async def cmd_games(ctx):
    w = await ctx.wallet()
    text = (
        f'🎮 Игры\n{SEP}\n'
        f'💳 Баланс: {rub(w["rub"])}\n'
        f'Ставки: от {rub(MIN_BET)} до {rub(MAX_BET)}\n\n'
        '🪙 Монетка - угадайте орла или решку\n'
        '🎲 Кости - бросьте кости против бота\n'
        '🎰 Слоты - три барабана, джекпот ×500\n'
        '🎡 Рулетка - цвет, чёт/нечёт или число\n'
        '✂ Камень-ножницы-бумага - сыграйте с ботом\n'
        '🃏 Блэкджек - наберите 21\n\n'
        'Играйте ответственно: это виртуальные деньги, но выигрыш не гарантирован!'
    )
    kb = (ctx.kb()
          .btn('🪙 Монетка', 'coin').btn('🎲 Кости', 'dice').btn('🎰 Слоты', 'slots').row()
          .btn('🎡 Рулетка', 'roulette').btn('✂ КНБ', 'rps').btn('🃏 Блэкджек', 'blackjack').row()
          .btn('🏠 Меню', 'menu'))
    await ctx.respond(text, kb)


# ---------------------------------------------------------------------------
# Монетка
# ---------------------------------------------------------------------------

COIN_SIDES = {'орел': 'орёл', 'орёл': 'орёл', 'о': 'орёл', 'heads': 'орёл', 'решка': 'решка', 'р': 'решка', 'tails': 'решка'}


@registry.command('coin', names=['монетка', 'coin', 'монета'], desc='монетка: орёл или решка', section='games',
                  usage='<ставка> [орёл|решка]')
async def cmd_coin(ctx):
    argv = ctx.argv
    if not argv:
        return await ctx.respond('🪙 Монетка\nУгадайте сторону и получите ×1.95 ставки.\nВыберите ставку:', bet_kb(ctx, 'coin'))
    bet = await parse_bet(ctx, argv[0])
    if bet is None:
        return
    side = COIN_SIDES.get(argv[1].lower()) if len(argv) > 1 else None
    if side is None:
        kb = (ctx.kb().btn('🦅 Орёл', 'coin', f'{bet} орёл', color='primary').btn('🪙 Решка', 'coin', f'{bet} решка', color='primary').row()
              .btn('🎮 Игры', 'games'))
        return await ctx.respond(f'🪙 Ставка {rub(bet)}. Выберите сторону:', kb)
    flip = RNG.choice(('орёл', 'решка'))
    payout = pay(bet, COIN_PAYOUT) if flip == side else 0
    balance = await settle(ctx, bet, payout, 'монетка')
    if balance is None:
        return await ctx.respond('❗ Недостаточно средств')
    await ctx.respond(result_text('🪙 Монетка', [f'Ваш выбор: {side}', f'Выпало: {flip}'], bet, payout, balance),
                      again_kb(ctx, 'coin', f'{bet} {side}'))


# ---------------------------------------------------------------------------
# Кости
# ---------------------------------------------------------------------------

def _dice_line(dice: list[int]) -> str:
    return ' '.join(DIE_FACES[d - 1] for d in dice) + f' = {sum(dice)}'


@registry.command('dice', names=['кости', 'dice', 'кубики'], desc='кости против бота', section='games', usage='<ставка>')
async def cmd_dice(ctx):
    argv = ctx.argv
    if not argv:
        return await ctx.respond('🎲 Кости\nВы и бот бросаете по два кубика: у кого больше - тот выиграл (×1.95). '
                                 'Ничья - ставка возвращается.\nВыберите ставку:', bet_kb(ctx, 'dice'))
    bet = await parse_bet(ctx, argv[0])
    if bet is None:
        return
    mine = [RNG.randint(1, 6), RNG.randint(1, 6)]
    bot = [RNG.randint(1, 6), RNG.randint(1, 6)]
    if sum(mine) > sum(bot):
        payout = pay(bet, DICE_PAYOUT)
    elif sum(mine) == sum(bot):
        payout = bet
    else:
        payout = 0
    balance = await settle(ctx, bet, payout, 'кости')
    if balance is None:
        return await ctx.respond('❗ Недостаточно средств')
    await ctx.respond(result_text('🎲 Кости', [f'Вы: {_dice_line(mine)}', f'Бот: {_dice_line(bot)}'], bet, payout, balance),
                      again_kb(ctx, 'dice', str(bet)))


# ---------------------------------------------------------------------------
# Слоты
# ---------------------------------------------------------------------------

def spin_slots(rng=None) -> list[str]:
    rng = rng or RNG
    symbols = [s for s, _, _ in SLOT_SYMBOLS]
    weights = [w for _, w, _ in SLOT_SYMBOLS]
    return rng.choices(symbols, weights=weights, k=3)


def slot_payout(bet: int, reels: list[str]) -> tuple[int, str]:
    mult = {s: m for s, _, m in SLOT_SYMBOLS}
    if reels[0] == reels[1] == reels[2]:
        return bet * mult[reels[0]], f'ДЖЕКПОТ! Три {reels[0]} - ×{mult[reels[0]]}'
    if len(set(reels)) < 3:
        return pay(bet, SLOT_PAIR_PAYOUT), 'Пара: возврат 70% ставки'
    return 0, 'Совпадений нет'


@registry.command('slots', names=['слоты', 'slots', 'казино', 'casino'], desc='игровой автомат', section='games',
                  usage='<ставка>')
async def cmd_slots(ctx):
    argv = ctx.argv
    if not argv:
        return await ctx.respond('🎰 Слоты\nТри одинаковых символа - крупный выигрыш (🍒×6 … 💎×500), пара возвращает 70% ставки.\n'
                                 'Выберите ставку:', bet_kb(ctx, 'slots'))
    bet = await parse_bet(ctx, argv[0])
    if bet is None:
        return
    reels = spin_slots()
    payout, note = slot_payout(bet, reels)
    balance = await settle(ctx, bet, payout, 'слоты')
    if balance is None:
        return await ctx.respond('❗ Недостаточно средств')
    await ctx.respond(result_text('🎰 Слоты', [f'[ {" | ".join(reels)} ]', note], bet, payout, balance),
                      again_kb(ctx, 'slots', str(bet)))


# ---------------------------------------------------------------------------
# Рулетка
# ---------------------------------------------------------------------------

def roulette_color(n: int) -> str:
    return 'зелёное' if n == 0 else 'красное' if n in RED_NUMBERS else 'чёрное'


ROULETTE_BETS = {
    'красное': 'красное', 'красный': 'красное', 'красн': 'красное', 'red': 'красное', 'к': 'красное',
    'чёрное': 'чёрное', 'черное': 'чёрное', 'чёрный': 'чёрное', 'черный': 'чёрное', 'black': 'чёрное', 'ч': 'чёрное',
    'зеро': 'зеро', 'zero': 'зеро', 'зелёное': 'зеро', 'зеленое': 'зеро',
    'чёт': 'чёт', 'чет': 'чёт', 'чётное': 'чёт', 'четное': 'чёт', 'even': 'чёт',
    'нечёт': 'нечёт', 'нечет': 'нечёт', 'нечётное': 'нечёт', 'нечетное': 'нечёт', 'odd': 'нечёт',
}


def roulette_outcome(choice: str, n: int, bet: int) -> int:
    if choice.isdigit():
        return pay(bet, ROULETTE_NUMBER_PAYOUT) if int(choice) == n else 0
    if choice == 'зеро':
        return pay(bet, ROULETTE_NUMBER_PAYOUT) if n == 0 else 0
    if n == 0:
        return 0
    wins = {'красное': n in RED_NUMBERS, 'чёрное': n not in RED_NUMBERS, 'чёт': n % 2 == 0, 'нечёт': n % 2 == 1}
    return pay(bet, ROULETTE_COLOR_PAYOUT) if wins[choice] else 0


@registry.command('roulette', names=['рулетка', 'roulette'], desc='рулетка: цвет, чёт/нечёт или число',
                  section='games', usage='<ставка> <красное|чёрное|зеро|чёт|нечёт|0-36>')
async def cmd_roulette(ctx):
    argv = ctx.argv
    if not argv:
        return await ctx.respond('🎡 Рулетка\nЦвет и чёт/нечёт - ×2, число (0-36) - ×36.\nВыберите ставку:',
                                 bet_kb(ctx, 'roulette'))
    bet = await parse_bet(ctx, argv[0])
    if bet is None:
        return
    raw = argv[1].lower() if len(argv) > 1 else ''
    choice = ROULETTE_BETS.get(raw)
    if choice is None and raw.isdigit() and 0 <= int(raw) <= 36:
        choice = str(int(raw))
    if choice is None:
        kb = (ctx.kb().btn('🔴 Красное', 'roulette', f'{bet} красное', color='negative')
              .btn('⚫ Чёрное', 'roulette', f'{bet} чёрное', color='primary')
              .btn('🟢 Зеро', 'roulette', f'{bet} зеро', color='positive').row()
              .btn('Чёт', 'roulette', f'{bet} чёт').btn('Нечёт', 'roulette', f'{bet} нечёт').row()
              .btn('🎮 Игры', 'games'))
        return await ctx.respond(f'🎡 Ставка {rub(bet)}. На что ставите?\nЧисло: /рулетка {bet} 17', kb)
    n = RNG.randint(0, 36)
    payout = roulette_outcome(choice, n, bet)
    balance = await settle(ctx, bet, payout, 'рулетка')
    if balance is None:
        return await ctx.respond('❗ Недостаточно средств')
    icon = {'красное': '🔴', 'чёрное': '⚫', 'зелёное': '🟢'}[roulette_color(n)]
    await ctx.respond(
        result_text('🎡 Рулетка', [f'Ваша ставка: {choice}', f'Выпало: {icon} {n}'], bet, payout, balance),
        again_kb(ctx, 'roulette', f'{bet} {choice}'))


# ---------------------------------------------------------------------------
# Камень-ножницы-бумага
# ---------------------------------------------------------------------------

RPS = {'камень': '🪨', 'ножницы': '✂', 'бумага': '📄'}
RPS_BEATS = {'камень': 'ножницы', 'ножницы': 'бумага', 'бумага': 'камень'}
RPS_ALIASES = {'камень': 'камень', 'к': 'камень', 'rock': 'камень', 'ножницы': 'ножницы', 'н': 'ножницы',
               'scissors': 'ножницы', 'бумага': 'бумага', 'б': 'бумага', 'paper': 'бумага'}


@registry.command('rps', names=['кнб', 'rps', 'камень'], desc='камень-ножницы-бумага', section='games',
                  usage='<ставка> [камень|ножницы|бумага]')
async def cmd_rps(ctx):
    argv = ctx.argv
    if not argv:
        return await ctx.respond('✂ Камень-ножницы-бумага\nПобеда - ×1.9, ничья - ставка возвращается.\nВыберите ставку:',
                                 bet_kb(ctx, 'rps'))
    bet = await parse_bet(ctx, argv[0])
    if bet is None:
        return
    mine = RPS_ALIASES.get(argv[1].lower()) if len(argv) > 1 else None
    if mine is None:
        kb = (ctx.kb().btn('🪨 Камень', 'rps', f'{bet} камень', color='primary').btn('✂ Ножницы', 'rps', f'{bet} ножницы', color='primary')
              .btn('📄 Бумага', 'rps', f'{bet} бумага', color='primary').row().btn('🎮 Игры', 'games'))
        return await ctx.respond(f'✂ Ставка {rub(bet)}. Ваш ход:', kb)
    theirs = RNG.choice(list(RPS))
    if mine == theirs:
        payout, note = bet, 'Ничья'
    elif RPS_BEATS[mine] == theirs:
        payout, note = pay(bet, RPS_PAYOUT), 'Вы победили!'
    else:
        payout, note = 0, 'Бот победил'
    balance = await settle(ctx, bet, payout, 'кнб')
    if balance is None:
        return await ctx.respond('❗ Недостаточно средств')
    await ctx.respond(result_text('✂ Камень-ножницы-бумага',
                                  [f'Вы: {RPS[mine]} {mine}', f'Бот: {RPS[theirs]} {theirs}', note], bet, payout, balance),
                      again_kb(ctx, 'rps', f'{bet} {mine}'))


# ---------------------------------------------------------------------------
# Блэкджек
# ---------------------------------------------------------------------------

RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
SUITS = '♠♥♦♣'
SESSION_TTL = 3600


def card_name(card: int) -> str:
    return f'{RANKS[card % 13]}{SUITS[card // 13]}'


def hand_value(cards: list[int]) -> int:
    total, aces = 0, 0
    for c in cards:
        r = RANKS[c % 13]
        if r == 'A':
            total, aces = total + 11, aces + 1
        elif r in ('J', 'Q', 'K'):
            total += 10
        else:
            total += int(r)
    while total > 21 and aces:
        total, aces = total - 10, aces - 1
    return total


def hand_text(cards: list[int], hide_second: bool = False) -> str:
    if hide_second:
        return f'{card_name(cards[0])} 🂠'
    return ' '.join(card_name(c) for c in cards) + f' = {hand_value(cards)}'


def new_deck(rng=None) -> list[int]:
    deck = list(range(52))
    (rng or RNG).shuffle(deck)
    return deck


def dealer_play(dealer: list[int], deck: list[int]) -> None:
    while hand_value(dealer) < 17:
        dealer.append(deck.pop())


def bj_outcome(bet: int, player: list[int], dealer: list[int], natural: bool = False) -> tuple[int, str]:
    """Выплата (с возвратом ставки) и пояснение; дилер уже доиграл."""
    p, d = hand_value(player), hand_value(dealer)
    if p > 21:
        return 0, 'Перебор - вы проиграли'
    if natural:
        return pay(bet, BJ_NATURAL), 'Блэкджек! Выплата 3:2'
    if d > 21:
        return pay(bet, BJ_WIN), 'У дилера перебор - вы победили!'
    if p > d:
        return pay(bet, BJ_WIN), 'Вы победили!'
    if p == d:
        return bet, 'Ничья'
    return 0, 'Дилер набрал больше - вы проиграли'


async def _session(ctx):
    return await ctx.db.fetchrow(
        "SELECT * FROM game_sessions WHERE scope=$1 AND user_id=$2 AND game='blackjack'", ctx.scope, ctx.user_id)


def _bj_kb(ctx, can_double: bool):
    kb = ctx.kb().btn('🃏 Взять', 'blackjack', 'hit', color='positive').btn('✋ Хватит', 'blackjack', 'stand', color='primary')
    if can_double:
        kb.btn('✖2 Удвоить', 'blackjack', 'double', color='negative')
    return kb


def _bj_state_text(state: dict, bet: int, balance: int, intro: str = '') -> str:
    return (f'{intro}🃏 Блэкджек\n{SEP}\n'
            f'Дилер: {hand_text(state["dealer"], hide_second=True)}\n'
            f'Вы: {hand_text(state["player"])}\n\nСтавка: {rub(bet)}')


async def _finish(ctx, state: dict, bet: int, old_data: str, natural: bool = False, bust_check: bool = False):
    """Закрывает партию: дилер добирает, выплата, удаление сессии."""
    deleted = await ctx.db.fetchrow(
        "DELETE FROM game_sessions WHERE scope=$1 AND user_id=$2 AND game='blackjack' AND data=$3 RETURNING bet",
        ctx.scope, ctx.user_id, old_data)
    if deleted is None:      # параллельное нажатие уже завершило партию
        return
    player, dealer, deck = state['player'], state['dealer'], state['deck']
    if hand_value(player) <= 21 and not natural:
        dealer_play(dealer, deck)
    payout, note = bj_outcome(bet, player, dealer, natural)
    if payout:
        await accounts.change(ctx.db, ctx.scope, ctx.user_id, payout, 'rub', 'game', 'блэкджек (выигрыш)')
    balance = (await ctx.wallet())['rub']
    text = result_text('🃏 Блэкджек', [f'Дилер: {hand_text(dealer)}', f'Вы: {hand_text(player)}', note], bet, payout, balance)
    await ctx.respond(text, again_kb(ctx, 'blackjack', str(bet)))


@registry.command('blackjack', names=['блэкджек', 'blackjack', 'bj', '21', 'очко'], desc='блэкджек: наберите 21',
                  section='games', usage='<ставка>')
async def cmd_blackjack(ctx):
    argv = ctx.argv
    sess = await _session(ctx)
    action = argv[0].lower() if argv else ''

    if sess is not None:
        state = json.loads(sess['data'])
        if accounts.now() - sess['ts'] > SESSION_TTL:       # партия брошена - засчитываем «хватит»
            return await _finish(ctx, state, sess['bet'], sess['data'])
        if action in ('hit', 'stand', 'double', 'взять', 'хватит', 'удвоить'):
            return await _bj_action(ctx, sess, state, action)
        text = _bj_state_text(state, sess['bet'], 0, intro='▶ У вас есть незавершённая партия!\n\n')
        return await ctx.respond(text, _bj_kb(ctx, len(state['player']) == 2 and not state.get('doubled')))

    if action in ('hit', 'stand', 'double', 'взять', 'хватит', 'удвоить'):
        return await ctx.respond('ℹ Партия уже завершена. Начните новую:', bet_kb(ctx, 'blackjack'))
    if not argv:
        return await ctx.respond(
            '🃏 Блэкджек\nНаберите больше дилера, но не больше 21. Победа ×2, блэкджек ×2.5.\n'
            'Дилер берёт карты до 17. Удвоить ставку можно на первой раздаче.\nВыберите ставку:', bet_kb(ctx, 'blackjack'))

    bet = await parse_bet(ctx, argv[0])
    if bet is None:
        return
    deck = new_deck()
    state = {'player': [deck.pop(), deck.pop()], 'dealer': [deck.pop(), deck.pop()], 'deck': deck}
    data = json.dumps(state, separators=(',', ':'))
    try:
        async with ctx.db.transaction() as tx:
            if await accounts.change(tx, ctx.scope, ctx.user_id, -bet, 'rub', 'game', 'блэкджек') is None:
                return await ctx.respond('❗ Недостаточно средств')
            await tx.execute(
                "INSERT INTO game_sessions (scope, user_id, game, data, bet, ts) VALUES ($1, $2, 'blackjack', $3, $4, $5)",
                ctx.scope, ctx.user_id, data, bet, accounts.now())
    except Exception:
        # на случай гонки (две быстрые команды): сессия уже существует
        if await _session(ctx) is not None:
            return await cmd_blackjack(ctx)
        raise
    if hand_value(state['player']) == 21:                   # блэкджек с раздачи
        return await _finish(ctx, state, bet, data, natural=True)
    await ctx.respond(_bj_state_text(state, bet, 0), _bj_kb(ctx, True))


async def _bj_action(ctx, sess, state: dict, action: str):
    bet, old = sess['bet'], sess['data']
    if action in ('hit', 'взять'):
        state['player'].append(state['deck'].pop())
        if hand_value(state['player']) >= 21:
            return await _finish(ctx, state, bet, old)
        data = json.dumps(state, separators=(',', ':'))
        row = await ctx.db.fetchrow(
            "UPDATE game_sessions SET data=$3, ts=$4 WHERE scope=$1 AND user_id=$2 AND game='blackjack' AND data=$5 "
            "RETURNING bet", ctx.scope, ctx.user_id, data, accounts.now(), old)
        if row is None:
            return
        return await ctx.respond(_bj_state_text(state, bet, 0), _bj_kb(ctx, False))
    if action in ('stand', 'хватит'):
        return await _finish(ctx, state, bet, old)
    # удвоение: только на первой раздаче, нужна ещё одна ставка
    if len(state['player']) != 2 or state.get('doubled'):
        return await ctx.respond('❗ Удвоить можно только сразу после раздачи')
    async with ctx.db.transaction() as tx:
        if await accounts.change(tx, ctx.scope, ctx.user_id, -bet, 'rub', 'game', 'блэкджек (удвоение)') is None:
            return await ctx.respond('❗ Недостаточно средств для удвоения')
        state['player'].append(state['deck'].pop())
        state['doubled'] = True
        data = json.dumps(state, separators=(',', ':'))
        row = await tx.fetchrow(
            "UPDATE game_sessions SET data=$3, bet=$4, ts=$5 WHERE scope=$1 AND user_id=$2 AND game='blackjack' AND data=$6 "
            "RETURNING bet", ctx.scope, ctx.user_id, data, bet * 2, accounts.now(), old)
        if row is None:
            raise RuntimeError('concurrent blackjack update')
    await _finish(ctx, state, bet * 2, data)
