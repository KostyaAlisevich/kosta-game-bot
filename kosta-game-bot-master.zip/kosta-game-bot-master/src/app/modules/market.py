"""Биржа: акции и криптовалюта с меняющимися ценами, графики, портфель и новости."""
import math
import time

from ..data.market import CRYPTO, STOCKS, TICKERS_BY_SYMBOL, TRADABLE
from ..framework.registry import registry
from ..services import accounts, market_engine
from ..util.fmt import SEP, arrow, fnum, pct, rub, spark
from ..util.money import _value

BUY_FEE = 0.002    # комиссия брокера при покупке
SELL_FEE = 0.002   # и при продаже
ALIASES = {
    'биткоин': 'BTC', 'bitcoin': 'BTC', 'эфир': 'ETH', 'эфириум': 'ETH', 'ethereum': 'ETH',
    'тон': 'TON', 'toncoin': 'TON', 'солана': 'SOL', 'solana': 'SOL', 'доге': 'DOGE', 'dogecoin': 'DOGE',
}


def find_ticker(token: str):
    t = (token or '').strip()
    if not t:
        return None
    sym = ALIASES.get(t.lower(), t.upper())
    tk = TICKERS_BY_SYMBOL.get(sym)
    if tk is not None and tk.kind != 'fx':
        return tk
    low = t.lower().replace('ё', 'е')
    matches = [x for x in TRADABLE if x.name.lower().replace('ё', 'е').startswith(low)]
    return matches[0] if len(matches) == 1 else None


def _price_fmt(price: float) -> str:
    return fnum(price, 2 if price >= 100 else 4)


def _qty_fmt(qty: float) -> str:
    return fnum(qty, 6)


async def _index(db, group, px: dict, ch: dict) -> tuple[float, float]:
    """Индекс группы: средняя цена относительно базовой (=100) и среднее изменение за сутки."""
    value = sum(px[t.symbol] / t.base * 100 for t in group) / len(group)
    change = sum(ch[t.symbol] for t in group) / len(group)
    return value, change


# ---------------------------------------------------------------------------
# /рынок
# ---------------------------------------------------------------------------

@registry.command('market', names=['рынок', 'биржа', 'market'], desc='биржа: индексы, лидеры, события', section='market')
async def cmd_market(ctx):
    px = await market_engine.prices(ctx.db)
    ch = await market_engine.changes(ctx.db)
    s_val, s_ch = await _index(ctx.db, STOCKS, px, ch)
    c_val, c_ch = await _index(ctx.db, CRYPTO, px, ch)
    ranked = sorted(TRADABLE, key=lambda t: ch[t.symbol], reverse=True)
    top, bottom = ranked[:3], ranked[-3:][::-1]
    news = await ctx.db.fetch('SELECT * FROM market_news ORDER BY id DESC LIMIT 3')

    lines = [
        f'📈 Рынок\n{SEP}',
        f'🏢 Индекс акций: {fnum(s_val)} {arrow(s_ch)} {pct(s_ch)}',
        f'🪙 Индекс крипты: {fnum(c_val)} {arrow(c_ch)} {pct(c_ch)}',
        '',
        '🚀 Лидеры роста: ' + ', '.join(f'{t.symbol} {pct(ch[t.symbol])}' for t in top),
        '📉 Лидеры падения: ' + ', '.join(f'{t.symbol} {pct(ch[t.symbol])}' for t in bottom),
    ]
    if news:
        lines += ['', '📰 Последние события:']
        lines += [f'{"📈" if n["pct"] > 0 else "📉"} {n["text"]} ({pct(n["pct"])})' for n in news]
    lines.append('\nИзменение за сутки. Цены виртуальные, меняются каждые несколько минут.')
    kb = (ctx.kb()
          .btn('🏢 Акции', 'stocks', color='primary').btn('🪙 Крипта', 'crypto', color='primary').row()
          .btn('💼 Портфель', 'portfolio').btn('📰 Новости', 'news').btn('💱 Курс', 'rates').row()
          .btn('🏠 Меню', 'menu'))
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# /акции, /крипта
# ---------------------------------------------------------------------------

async def _list(ctx, group, title: str, emoji: str, cmd: str):
    px = await market_engine.prices(ctx.db)
    ch = await market_engine.changes(ctx.db)
    page = 0
    if ctx.args.strip().isdigit():
        page = int(ctx.args.strip())
    per_page = 4 if len(group) > 5 else len(group)
    pages = max(1, math.ceil(len(group) / per_page))
    page = max(0, min(page, pages - 1))
    items = group[page * per_page:(page + 1) * per_page]

    lines = [f'{emoji} {title} | стр. {page + 1}/{pages}\n{SEP}']
    for t in items:
        lines.append(f'{t.emoji} {t.symbol} · {t.name}\n    {_price_fmt(px[t.symbol])} ₽ {arrow(ch[t.symbol])} {pct(ch[t.symbol])}')
    lines.append('\nВыберите бумагу кнопкой: график, покупка и продажа.')
    kb = ctx.kb()
    for i, t in enumerate(items):
        if i and i % 2 == 0:
            kb.row()
        kb.btn(f'{t.emoji} {t.symbol}', 'chart', t.symbol)
    kb.row()
    if page > 0:
        kb.btn('◀', cmd, str(page - 1))
    if page < pages - 1:
        kb.btn('▶', cmd, str(page + 1))
    kb.btn('📈 Рынок', 'market').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


@registry.command('stocks', names=['акции', 'stocks'], desc='котировки акций', section='market')
async def cmd_stocks(ctx):
    await _list(ctx, STOCKS, 'Акции', '🏢', 'stocks')


@registry.command('crypto', names=['крипта', 'крипто', 'crypto', 'криптовалюта'], desc='котировки криптовалют',
                  section='market')
async def cmd_crypto(ctx):
    await _list(ctx, CRYPTO, 'Криптовалюты', '🪙', 'crypto')


# ---------------------------------------------------------------------------
# /график (он же карточка бумаги)
# ---------------------------------------------------------------------------

@registry.command('chart', names=['график', 'chart'], desc='график цены за сутки', section='market',
                  usage='<тикер>')
async def cmd_chart(ctx):
    argv = ctx.argv
    tk = find_ticker(argv[0]) if argv else None
    if tk is None:
        return await ctx.respond(
            '📊 Укажите бумагу. Пример: /график BTC или /график NFTX\nТикеры: '
            + ', '.join(t.symbol for t in TRADABLE),
            ctx.kb().btn('🏢 Акции', 'stocks').btn('🪙 Крипта', 'crypto').btn('📈 Рынок', 'market'))
    hours = 24
    if len(argv) > 1 and argv[1].isdigit():
        hours = max(1, min(24, int(argv[1])))

    price = await market_engine.price(ctx.db, tk.symbol)
    values = await market_engine.history(ctx.db, tk.symbol, hours=hours, points=24)
    ch = await market_engine.change_24h(ctx.db, tk.symbol)
    lines = [f'{tk.emoji} {tk.symbol} · {tk.name}\n{SEP}',
             f'💵 Цена: {_price_fmt(price)} ₽ {arrow(ch)} {pct(ch)} за сутки']
    if len(values) >= 2:
        lines += [f'📊 За {hours} ч: {spark(values)}',
                  f'Мин: {_price_fmt(min(values))} ₽ · Макс: {_price_fmt(max(values))} ₽']
    else:
        lines.append('📊 История пока копится - загляните позже.')
    hold = await ctx.db.fetchrow('SELECT qty, invested FROM holdings WHERE scope=$1 AND user_id=$2 AND symbol=$3',
                                 ctx.scope, ctx.user_id, tk.symbol)
    if hold and hold['qty'] > 0:
        value = hold['qty'] * price
        pnl = value - hold['invested']
        lines.append(f'\n💼 У вас: {_qty_fmt(hold["qty"])} шт. на {rub(int(value))} '
                     f'({"+" if pnl >= 0 else "−"}{rub(abs(int(pnl)))})')
    back = 'stocks' if tk.kind == 'stock' else 'crypto'
    kb = (ctx.kb()
          .btn('Купить 1 000 ₽', 'buy', f'{tk.symbol} на 1000', color='positive')
          .btn('10 000 ₽', 'buy', f'{tk.symbol} на 10000', color='positive')
          .btn('100 000 ₽', 'buy', f'{tk.symbol} на 100000', color='positive').row()
          .btn('Продать 50%', 'sell', f'{tk.symbol} 50%', color='negative')
          .btn('Продать всё', 'sell', f'{tk.symbol} все', color='negative').row()
          .btn('🔄 Обновить', 'chart', tk.symbol).btn('◀ К списку', back).btn('🏠 Меню', 'menu'))
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# /купить, /продать
# ---------------------------------------------------------------------------

class _Stop(Exception):
    pass


def _usage_buy() -> str:
    return ('📈 Покупка на бирже\nФормат: /купить <тикер> <количество> или /купить <тикер> на <сумма ₽>\n'
            'Примеры: /купить NFTX 10, /купить BTC на 5000, /купить TON все')


@registry.command('buy', names=['купить', 'buy'], desc='покупка на бирже', section='market',
                  usage='<тикер> <кол-во | на сумма>')
async def cmd_buy(ctx):
    argv = ctx.argv
    tk = find_ticker(argv[0]) if argv else None
    if tk is None or len(argv) < 2:
        return await ctx.respond(_usage_buy(), ctx.kb().btn('🏢 Акции', 'stocks').btn('🪙 Крипта', 'crypto'))
    w = await ctx.wallet()
    price = await market_engine.price(ctx.db, tk.symbol)
    rest = argv[1:]
    spend = None
    qty = None
    if rest[0].lower() in ('на', 'for') and len(rest) > 1:
        spend = _value(rest[1], w['rub'])
    elif rest[0].lower() in ('все', 'всё', 'all'):
        spend = w['rub']
    elif rest[0].endswith(('₽', 'р', 'руб')):
        spend = _value(rest[0].rstrip('₽рруб'), w['rub'])
    else:
        qty = _value(rest[0], None)
    if spend is None and qty is None:
        return await ctx.respond(_usage_buy())

    if spend is not None:
        qty = spend / (price * (1 + BUY_FEE))
    qty = math.floor(qty) if tk.kind == 'stock' else math.floor(qty * 1_000_000) / 1_000_000
    if qty <= 0:
        return await ctx.respond(f'❗ На такую сумму нельзя купить даже минимальную долю {tk.symbol} '
                                 f'(цена {_price_fmt(price)} ₽)')
    cost = math.ceil(qty * price * (1 + BUY_FEE))
    try:
        async with ctx.db.transaction() as tx:
            if await accounts.change(tx, ctx.scope, ctx.user_id, -cost, 'rub', 'buy', f'{tk.symbol} x{qty}') is None:
                raise _Stop
            await tx.execute(
                'INSERT INTO holdings (scope, user_id, symbol, qty, invested) VALUES ($1, $2, $3, $4, $5) '
                'ON CONFLICT (scope, user_id, symbol) DO UPDATE SET qty = holdings.qty + EXCLUDED.qty, '
                'invested = holdings.invested + EXCLUDED.invested',
                ctx.scope, ctx.user_id, tk.symbol, float(qty), cost)
    except _Stop:
        return await ctx.respond(f'❗ Недостаточно средств: нужно {rub(cost)}, у вас {rub(w["rub"])}',
                                 ctx.kb().btn('💼 Заработать', 'jobs').btn('◀ Назад', 'chart', tk.symbol))
    kb = ctx.kb().btn('📊 График', 'chart', tk.symbol).btn('💼 Портфель', 'portfolio').btn('🏠 Меню', 'menu')
    await ctx.respond(
        f'✅ Покупка выполнена\n{SEP}\n{tk.emoji} {tk.symbol}: {_qty_fmt(qty)} шт. по {_price_fmt(price)} ₽\n'
        f'Списано: {rub(cost)} (включая комиссию {BUY_FEE * 100:g}%)', kb)


@registry.command('sell', names=['продать', 'sell'], desc='продажа на бирже', section='market',
                  usage='<тикер> <кол-во | все>')
async def cmd_sell(ctx):
    argv = ctx.argv
    tk = find_ticker(argv[0]) if argv else None
    if tk is None:
        return await ctx.respond('📉 Продажа на бирже\nФормат: /продать <тикер> <количество | все | 50%>\n'
                                 'Пример: /продать NFTX 5, /продать BTC все',
                                 ctx.kb().btn('💼 Портфель', 'portfolio').btn('📈 Рынок', 'market'))
    hold = await ctx.db.fetchrow('SELECT qty, invested FROM holdings WHERE scope=$1 AND user_id=$2 AND symbol=$3',
                                 ctx.scope, ctx.user_id, tk.symbol)
    if not hold or hold['qty'] <= 0:
        return await ctx.respond(f'ℹ У вас нет {tk.symbol}', ctx.kb().btn('💼 Портфель', 'portfolio').btn('📈 Рынок', 'market'))
    token = argv[1] if len(argv) > 1 else 'все'
    have = hold['qty']
    if token.lower() in ('все', 'всё', 'all'):
        qty = have
    else:
        value = _value(token, have)
        if value is None:
            return await ctx.respond('❗ Укажите количество, «все» или процент. Пример: /продать BTC 50%')
        qty = value if token.endswith('%') else float(value)
        if tk.kind == 'stock' and not token.endswith('%'):
            qty = math.floor(qty)
        elif token.endswith('%'):
            qty = math.floor(qty * 1_000_000) / 1_000_000 if tk.kind == 'crypto' else math.floor(qty)
    if qty <= 0:
        return await ctx.respond('❗ Слишком маленькое количество')
    if qty > have:
        return await ctx.respond(f'❗ У вас только {_qty_fmt(have)} {tk.symbol}')

    price = await market_engine.price(ctx.db, tk.symbol)
    proceeds = math.floor(qty * price * (1 - SELL_FEE))
    left = have - qty
    spent_part = hold['invested'] if qty == have else int(hold['invested'] * qty / have)
    try:
        async with ctx.db.transaction() as tx:
            if left <= 1e-9:
                row = await tx.fetchrow(
                    'DELETE FROM holdings WHERE scope=$1 AND user_id=$2 AND symbol=$3 AND qty=$4 RETURNING symbol',
                    ctx.scope, ctx.user_id, tk.symbol, have)
            else:
                row = await tx.fetchrow(
                    'UPDATE holdings SET qty=$4, invested=$5 WHERE scope=$1 AND user_id=$2 AND symbol=$3 AND qty=$6 '
                    'RETURNING symbol', ctx.scope, ctx.user_id, tk.symbol, left, hold['invested'] - spent_part, have)
            if row is None:
                raise _Stop  # параллельная продажа уже изменила позицию
            await accounts.change(tx, ctx.scope, ctx.user_id, proceeds, 'rub', 'sell', f'{tk.symbol} x{qty}')
    except _Stop:
        return await ctx.respond('⚠ Позиция уже изменилась, повторите команду')
    pnl = proceeds - spent_part
    kb = ctx.kb().btn('💼 Портфель', 'portfolio').btn('📈 Рынок', 'market').btn('🏠 Меню', 'menu')
    await ctx.respond(
        f'✅ Продажа выполнена\n{SEP}\n{tk.emoji} {tk.symbol}: {_qty_fmt(qty)} шт. по {_price_fmt(price)} ₽\n'
        f'Получено: {rub(proceeds)} (комиссия {SELL_FEE * 100:g}%)\n'
        f'Результат сделки: {"+" if pnl >= 0 else "−"}{rub(abs(pnl))}', kb)


# ---------------------------------------------------------------------------
# /портфель
# ---------------------------------------------------------------------------

@registry.command('portfolio', names=['портфель', 'portfolio'], desc='акции и криптовалюта', section='market')
async def cmd_portfolio(ctx):
    rows = await ctx.db.fetch('SELECT * FROM holdings WHERE scope=$1 AND user_id=$2 ORDER BY symbol', ctx.scope, ctx.user_id)
    px = await market_engine.prices(ctx.db)
    w = await ctx.wallet()
    lines = [f'💼 Портфель\n{SEP}']
    total = invested = 0
    items = []
    for r in rows:
        tk = TICKERS_BY_SYMBOL.get(r['symbol'])
        if tk is None or r['qty'] <= 0:
            continue
        value = int(r['qty'] * px[r['symbol']])
        total += value
        invested += r['invested']
        items.append((value, tk))
        pnl = value - r['invested']
        lines.append(f'{tk.emoji} {tk.symbol}: {_qty_fmt(r["qty"])} шт. - {rub(value)} '
                     f'({"+" if pnl >= 0 else "−"}{rub(abs(pnl))})')
    if not items:
        lines.append('Портфель пуст. Купите первые акции или криптовалюту!')
    else:
        pnl = total - invested
        lines += ['', f'💎 Стоимость портфеля: {rub(total)}',
                  f'📊 Результат: {"+" if pnl >= 0 else "−"}{rub(abs(pnl))}']
    lines.append(f'₽ Свободные деньги: {rub(w["rub"])}')
    kb = ctx.kb()
    for value, tk in sorted(items, key=lambda x: -x[0])[:4]:
        kb.btn(f'{tk.emoji} {tk.symbol}', 'chart', tk.symbol)
    kb.row().btn('🏢 Акции', 'stocks').btn('🪙 Крипта', 'crypto').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# /новости
# ---------------------------------------------------------------------------

def _ago(ts: int) -> str:
    d = max(0, accounts.now() - ts)
    if d < 3600:
        return f'{max(1, d // 60)} мин назад'
    if d < 86400:
        return f'{d // 3600} ч назад'
    return f'{d // 86400} д назад'


@registry.command('news', names=['новости', 'news'], desc='новости и события рынка', section='market')
async def cmd_news(ctx):
    rows = await ctx.db.fetch('SELECT * FROM market_news ORDER BY id DESC LIMIT 8')
    lines = [f'📰 Новости рынка\n{SEP}']
    if not rows:
        lines.append('Пока тихо. Важные события появляются время от времени и двигают цены.')
    for n in rows:
        lines.append(f'{"📈" if n["pct"] > 0 else "📉"} {n["text"]} - {pct(n["pct"])} · {_ago(n["ts"])}')
    kb = ctx.kb().btn('📈 Рынок', 'market').btn('🏢 Акции', 'stocks').btn('🪙 Крипта', 'crypto').row().btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)
