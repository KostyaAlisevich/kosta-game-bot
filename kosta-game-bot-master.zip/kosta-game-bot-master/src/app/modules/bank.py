"""Банк: вклад под процент, кредит и кредитный рейтинг."""
from ..framework.registry import registry
from ..services import accounts, banking
from ..services.banking import (
    DEPOSIT_CAP, DEPOSIT_RATE_DAILY, LOAN_FEE_PCT, LOAN_MIN, LOAN_TERM, OVERDUE_PCT, SCORE_MAX, credit_limit,
    score_label,
)
from ..util.fmt import SEP, dur, rub
from ..util.money import _value

DEPOSIT_IN = ('положить', 'внести', 'пополнить', '+', 'in', 'add')
DEPOSIT_OUT = ('снять', 'вывести', '-', 'out', 'withdraw')
LOAN_TAKE = ('взять', 'получить', 'take')
LOAN_PAY = ('погасить', 'вернуть', 'оплатить', 'pay', 'repay')


def _amount(token: str, maximum: int) -> int | None:
    value = _value(token, maximum)
    if value is None:
        return None
    amount = int(value)
    return amount if amount > 0 else None


# ---------------------------------------------------------------------------
# /банк
# ---------------------------------------------------------------------------

@registry.command('bank', names=['банк', 'bank'], desc='вклад, кредит и кредитный рейтинг', section='bank')
async def cmd_bank(ctx):
    w = await banking.refresh(ctx.db, ctx.scope, ctx.user_id)
    now = accounts.now()
    lines = [
        f'🏦 Банк\n{SEP}',
        f'₽ На руках: {rub(w["rub"])}',
        f'💰 Вклад: {rub(w["deposit"])} (+{DEPOSIT_RATE_DAILY * 100:g}% в сутки)',
    ]
    if w['loan']:
        left = w['loan_due'] - now
        state = f'до срока {dur(left)}' if left > 0 else f'⚠ просрочен: штраф {OVERDUE_PCT}% в сутки'
        lines.append(f'💳 Долг: {rub(w["loan"])} ({state})')
    else:
        lines.append('💳 Кредитов нет')
    lines += [
        f'⭐ Кредитный рейтинг: {w["credit_score"]} ({score_label(w["credit_score"])})',
        f'📋 Лимит нового кредита: {rub(credit_limit(w["credit_score"]))}',
        '',
        'Вклад: /вклад положить <сумма>, /вклад снять <сумма>',
        'Кредит: /кредит взять <сумма>, /кредит погасить <сумма>',
    ]
    kb = (ctx.kb().btn('💰 Вклад', 'deposit', color='primary').btn('💳 Кредит', 'loan', color='primary').row()
          .btn('💰 Кошелёк', 'wallet').btn('🏠 Меню', 'menu'))
    await ctx.respond('\n'.join(lines), kb)


# ---------------------------------------------------------------------------
# /вклад
# ---------------------------------------------------------------------------

@registry.command('deposit', names=['вклад', 'deposit'], desc='вклад под процент', section='bank',
                  usage='[положить|снять] <сумма>')
async def cmd_deposit(ctx):
    w = await banking.refresh(ctx.db, ctx.scope, ctx.user_id)
    argv = [a.lower() for a in ctx.argv]
    if argv:
        action = 'in'
        if argv[0] in DEPOSIT_OUT:
            action, argv = 'out', argv[1:]
        elif argv[0] in DEPOSIT_IN:
            argv = argv[1:]
        if not argv:
            return await _deposit_screen(ctx, w)
        if action == 'in':
            return await _deposit_in(ctx, w, argv[0])
        return await _deposit_out(ctx, w, argv[0])
    await _deposit_screen(ctx, w)


async def _deposit_screen(ctx, w, intro: str = ''):
    text = (
        f'{intro}💰 Вклад\n{SEP}\n'
        f'На вкладе: {rub(w["deposit"])}\n'
        f'На руках: {rub(w["rub"])}\n'
        f'Ставка: {DEPOSIT_RATE_DAILY * 100:g}% в сутки, максимум на вкладе {rub(DEPOSIT_CAP)}\n'
        'Проценты начисляются автоматически, снять деньги можно в любой момент.\n\n'
        'Свою сумму: /вклад положить 5000, /вклад снять 2000'
    )
    kb = (ctx.kb()
          .btn('➕ Всё', 'deposit', 'положить все', color='positive').btn('➕ 50%', 'deposit', 'положить 50%').row()
          .btn('➖ Всё', 'deposit', 'снять все', color='negative').btn('➖ 50%', 'deposit', 'снять 50%').row()
          .btn('🏦 Банк', 'bank').btn('🏠 Меню', 'menu'))
    await ctx.respond(text, kb)


async def _deposit_in(ctx, w, token: str):
    amount = _amount(token, w['rub'])
    if amount is None:
        return await ctx.respond('❗ Укажите сумму. Пример: /вклад положить 5000')
    if w['deposit'] + amount > DEPOSIT_CAP:
        amount = DEPOSIT_CAP - w['deposit']
        if amount <= 0:
            return await ctx.respond(f'❗ Достигнут лимит вклада: {rub(DEPOSIT_CAP)}')
    async with ctx.db.transaction() as tx:
        paid = await accounts.change(tx, ctx.scope, ctx.user_id, -amount, 'rub', 'deposit', 'вклад')
        if paid is None:
            return await ctx.respond(f'❗ Недостаточно средств. На руках {rub(w["rub"])}')
        await tx.execute('UPDATE wallets SET deposit = deposit + $3, deposit_ts = $4 WHERE scope=$1 AND user_id=$2',
                         ctx.scope, ctx.user_id, amount, accounts.now())
    w = await ctx.wallet()
    await _deposit_screen(ctx, w, intro=f'✅ Внесено на вклад: {rub(amount)}\n\n')


async def _deposit_out(ctx, w, token: str):
    amount = _amount(token, w['deposit'])
    if amount is None:
        return await ctx.respond('❗ Укажите сумму. Пример: /вклад снять 2000')
    async with ctx.db.transaction() as tx:
        row = await tx.fetchrow(
            'UPDATE wallets SET deposit = deposit - $3 WHERE scope=$1 AND user_id=$2 AND deposit >= $3 '
            'RETURNING deposit', ctx.scope, ctx.user_id, amount)
        if row is None:
            return await ctx.respond(f'❗ На вкладе только {rub(w["deposit"])}')
        await accounts.change(tx, ctx.scope, ctx.user_id, amount, 'rub', 'withdraw', 'вклад')
    w = await ctx.wallet()
    await _deposit_screen(ctx, w, intro=f'✅ Снято с вклада: {rub(amount)}\n\n')


# ---------------------------------------------------------------------------
# /кредит
# ---------------------------------------------------------------------------

@registry.command('loan', names=['кредит', 'loan'], desc='кредит', section='bank', usage='[взять|погасить] <сумма>')
async def cmd_loan(ctx):
    w = await banking.refresh(ctx.db, ctx.scope, ctx.user_id)
    argv = [a.lower() for a in ctx.argv]
    if argv and argv[0] in LOAN_PAY:
        return await _repay(ctx, w, argv[1] if len(argv) > 1 else 'все')
    if argv:
        token = argv[1] if argv[0] in LOAN_TAKE and len(argv) > 1 else argv[0]
        if argv[0] in LOAN_TAKE and len(argv) == 1:
            return await _loan_screen(ctx, w)
        return await _take(ctx, w, token)
    await _loan_screen(ctx, w)


async def _loan_screen(ctx, w, intro: str = ''):
    limit = credit_limit(w['credit_score'])
    now = accounts.now()
    lines = [f'{intro}💳 Кредит\n{SEP}',
             f'⭐ Рейтинг: {w["credit_score"]} из {SCORE_MAX} ({score_label(w["credit_score"])})']
    kb = ctx.kb()
    if w['loan']:
        left = w['loan_due'] - now
        lines.append(f'Долг: {rub(w["loan"])}')
        lines.append(f'Срок: через {dur(left)}' if left > 0 else f'⚠ Просрочено! Штраф {OVERDUE_PCT}% в сутки и минус к рейтингу')
        lines.append('Вовремя погашенный кредит повышает рейтинг.')
        kb.btn('✅ Погасить всё', 'loan', 'погасить все', color='positive').btn('50%', 'loan', 'погасить 50%')
    else:
        lines.append(f'Доступно: от {rub(LOAN_MIN)} до {rub(limit)}')
        lines.append(f'Комиссия {LOAN_FEE_PCT}%, срок {dur(LOAN_TERM)}. Просрочка: штраф {OVERDUE_PCT}% в сутки.')
        lines.append('Свою сумму: /кредит взять 20000')
        if limit >= LOAN_MIN:
            for part in (4, 2, 1):
                amount = limit // part
                if amount >= LOAN_MIN:
                    kb.btn(f'Взять {rub(amount)}', 'loan', f'взять {amount}', color='primary' if part == 1 else 'secondary')
    kb.row().btn('🏦 Банк', 'bank').btn('🏠 Меню', 'menu')
    await ctx.respond('\n'.join(lines), kb)


async def _take(ctx, w, token: str):
    if w['loan']:
        return await ctx.respond('❗ У вас уже есть непогашенный кредит. Сначала погасите его: /кредит погасить все')
    limit = credit_limit(w['credit_score'])
    amount = _amount(token, limit)
    if amount is None:
        return await ctx.respond('❗ Укажите сумму. Пример: /кредит взять 20000')
    if amount < LOAN_MIN:
        return await ctx.respond(f'❗ Минимальный кредит: {rub(LOAN_MIN)}')
    if amount > limit:
        return await ctx.respond(f'❗ Ваш лимит по кредиту: {rub(limit)}. Повышайте рейтинг, вовремя возвращая долги.')
    owed = amount * (100 + LOAN_FEE_PCT) // 100
    due = accounts.now() + LOAN_TERM
    async with ctx.db.transaction() as tx:
        row = await tx.fetchrow(
            'UPDATE wallets SET loan=$3, loan_due=$4, loan_pen_ts=0 WHERE scope=$1 AND user_id=$2 AND loan=0 '
            'RETURNING loan', ctx.scope, ctx.user_id, owed, due)
        if row is None:
            return await ctx.respond('❗ У вас уже есть непогашенный кредит')
        await accounts.change(tx, ctx.scope, ctx.user_id, amount, 'rub', 'loan', 'кредит')
    w = await ctx.wallet()
    await _loan_screen(ctx, w, intro=f'✅ Кредит выдан: {rub(amount)} (к возврату {rub(owed)})\n\n')


async def _repay(ctx, w, token: str):
    if not w['loan']:
        return await ctx.respond('ℹ У вас нет кредитов')
    amount = _amount(token, min(w['loan'], w['rub']))
    if amount is None:
        return await ctx.respond('❗ Укажите сумму или «все». Пример: /кредит погасить 5000')
    amount = min(amount, w['loan'])
    on_time = accounts.now() <= w['loan_due']
    async with ctx.db.transaction() as tx:
        paid = await accounts.change(tx, ctx.scope, ctx.user_id, -amount, 'rub', 'repay', 'кредит')
        if paid is None:
            return await ctx.respond(f'❗ Недостаточно средств. На руках {rub(w["rub"])}')
        row = await tx.fetchrow(
            'UPDATE wallets SET loan = loan - $3 WHERE scope=$1 AND user_id=$2 AND loan >= $3 RETURNING loan',
            ctx.scope, ctx.user_id, amount)
        if row is None:
            return await ctx.respond('❗ Сумма больше долга')
        bonus = ''
        if row['loan'] == 0:
            gain = 10 if on_time else 0
            await tx.execute(
                'UPDATE wallets SET loan_due=0, loan_pen_ts=0, credit_score = '
                'CASE WHEN credit_score + $3 > $4 THEN $4 ELSE credit_score + $3 END WHERE scope=$1 AND user_id=$2',
                ctx.scope, ctx.user_id, gain, SCORE_MAX)
            bonus = '\n⭐ Кредитный рейтинг повышен!' if gain else '\nКредит погашен с просрочкой - рейтинг не вырос.'
    w = await ctx.wallet()
    await _loan_screen(ctx, w, intro=f'✅ Погашено: {rub(amount)}{bonus}\n\n')
