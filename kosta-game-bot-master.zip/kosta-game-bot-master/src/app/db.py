"""Работа с PostgreSQL через asyncpg.

Весь SQL проекта написан в общем подмножестве PostgreSQL/SQLite (параметры $1, $2...,
время - целые секунды Unix, флаги - SMALLINT 0/1), поэтому логику можно проверять и на SQLite.
"""
from contextlib import asynccontextmanager

from .schema import SCHEMA


class Database:
    def __init__(self, dsn: str):
        self.dsn = dsn
        self.pool = None

    async def connect(self) -> None:
        import asyncpg  # импортируем здесь, чтобы тесты работали без asyncpg
        dsn = self.dsn
        if dsn.startswith('postgres://'):  # asyncpg понимает оба варианта, но так надёжнее
            dsn = 'postgresql://' + dsn[len('postgres://'):]
        self.pool = await asyncpg.create_pool(dsn, min_size=1, max_size=10, command_timeout=30)

    async def close(self) -> None:
        if self.pool is not None:
            await self.pool.close()

    async def fetch(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetch(query, *args)

    async def fetchrow(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetchrow(query, *args)

    async def fetchval(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetchval(query, *args)

    async def execute(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.execute(query, *args)

    @asynccontextmanager
    async def transaction(self):
        """Транзакция: все запросы внутри либо применяются вместе, либо откатываются."""
        async with self.pool.acquire() as conn:
            async with conn.transaction():
                yield conn


async def init_schema(db) -> None:
    """Создаёт недостающие таблицы (безопасно запускать при каждом старте)."""
    for statement in SCHEMA:
        await db.execute(statement)
