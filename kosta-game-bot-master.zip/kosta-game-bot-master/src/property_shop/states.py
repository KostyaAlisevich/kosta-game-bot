from vkbottle import BaseStateGroup


class PropertyShopState(BaseStateGroup):
    TRANSPORT = 0   # выбор вида транспорта
    CATEGORY = 1    # список предметов категории
    ITEM = 2        # карточка предмета с кнопкой «Купить»
    INVENTORY = 3   # «Моё имущество»
