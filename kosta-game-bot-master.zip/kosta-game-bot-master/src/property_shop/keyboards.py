from collections.abc import Mapping, Sequence

from vkbottle import Keyboard, Text, KeyboardButtonColor

from .catalog import CATEGORIES_BY_KEY, TRANSPORT_CATEGORIES, Item
from .engine import format_money


def build_category_keyboard(
        page_items: Sequence[Item],
        owned: Mapping[str, int],
        page: int,
        total_pages: int
) -> Keyboard:
    keyboard = Keyboard()

    for i, item in enumerate(page_items):
        if i and i % 2 == 0:
            keyboard.row()
        label = f'✅ {item.title}' if item.key in owned else f'{item.emoji} {item.title}'
        keyboard.add(Text(label, payload={'choice': item.key}), color=KeyboardButtonColor.PRIMARY)

    if total_pages > 1:
        keyboard.row()
        if page > 0:
            keyboard.add(Text('◀ Пред.стр', payload={'choice': 'prev_page'}))
        if page < total_pages - 1:
            keyboard.add(Text('След.стр ▶', payload={'choice': 'next_page'}))

    keyboard.row()
    keyboard.add(Text('◀ Назад', payload={'choice': 'back'}))
    return keyboard


def build_transport_keyboard() -> Keyboard:
    keyboard = Keyboard()
    for i, key in enumerate(TRANSPORT_CATEGORIES):
        if i and i % 2 == 0:
            keyboard.row()
        category = CATEGORIES_BY_KEY[key]
        keyboard.add(
            Text(f'{category.emoji} {category.title}', payload={'choice': key}),
            color=KeyboardButtonColor.PRIMARY
        )
    keyboard.row()
    keyboard.add(Text('◀🏬 В магазин', payload={'choice': 'back'}))
    return keyboard


def build_item_keyboard(item: Item, is_owned: bool) -> Keyboard:
    keyboard = Keyboard()
    if not is_owned:
        keyboard.add(
            Text(f'✅ Купить за {format_money(item.price)}', payload={'choice': 'buy'}),
            color=KeyboardButtonColor.POSITIVE
        )
        keyboard.row()
    keyboard.add(Text('◀ К списку', payload={'choice': 'back'}))
    return keyboard


def build_inventory_keyboard(has_business: bool) -> Keyboard:
    keyboard = Keyboard()
    if has_business:
        keyboard.add(Text('💰 Собрать доход', payload={'choice': 'collect'}), color=KeyboardButtonColor.POSITIVE)
        keyboard.row()
    keyboard.add(Text('🔄 Обновить', payload={'choice': 'refresh'}), color=KeyboardButtonColor.SECONDARY)
    keyboard.row()
    keyboard.add(Text('◀🏬 В магазин', payload={'choice': 'back'}))
    return keyboard
