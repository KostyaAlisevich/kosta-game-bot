from tortoise.exceptions import IntegrityError
from tortoise.expressions import F

from users.models import UserModel
from .catalog import ITEMS_BY_KEY, Item
from .engine import accrued_income, now_ts
from .models import OwnedItem


async def get_owned(user_pk: int) -> dict[str, int]:
    """{ключ предмета: время последнего сбора дохода} для всего, что есть у пользователя."""
    owned = {}
    for row in await OwnedItem.filter(user_id=user_pk):
        if row.item_key in ITEMS_BY_KEY:  # предметы, убранные из каталога, не показываем
            owned[row.item_key] = row.collected_at
    return owned


async def buy_item(user_pk: int, item: Item) -> str:
    """Покупает предмет. Возвращает 'ok', 'already' (уже есть) или 'no_money' (не хватает денег).

    Деньги списываются одним атомарным UPDATE ... WHERE balance >= price,
    поэтому быстрые повторные нажатия не уведут баланс в минус и не приведут к двойной покупке.
    """
    if await OwnedItem.exists(user_id=user_pk, item_key=item.key):
        return 'already'

    paid = await UserModel.filter(pk=user_pk, balance__gte=item.price).update(
        balance=F('balance') - item.price
    )
    if not paid:
        return 'no_money'

    now = now_ts()
    try:
        await OwnedItem.create(user_id=user_pk, item_key=item.key, purchased_at=now, collected_at=now)
    except IntegrityError:
        # Параллельный запрос успел купить этот же предмет раньше - возвращаем деньги
        await UserModel.filter(pk=user_pk).update(balance=F('balance') + item.price)
        return 'already'
    return 'ok'


async def collect_income(user_pk: int) -> int:
    """Забирает накопленный доход со всех бизнесов, возвращает собранную сумму.

    Каждый бизнес «закрывается» атомарным UPDATE ... WHERE collected_at = <прочитанное значение>,
    поэтому параллельные нажатия не приведут к двойной выплате.
    """
    now = now_ts()
    total = 0
    for row in await OwnedItem.filter(user_id=user_pk):
        item = ITEMS_BY_KEY.get(row.item_key)
        if item is None or not item.income_per_hour:
            continue
        amount = accrued_income(item.income_per_hour, row.collected_at, now)
        if amount <= 0:
            continue  # время не трогаем, чтобы не терять доли секунды
        claimed = await OwnedItem.filter(pk=row.pk, collected_at=row.collected_at).update(collected_at=now)
        if claimed:
            total += amount

    if total:
        await UserModel.filter(pk=user_pk).update(balance=F('balance') + total)
    return total
