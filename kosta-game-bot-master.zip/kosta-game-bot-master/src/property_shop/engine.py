"""Логика магазина имущества без зависимостей от ВК и базы данных (поэтому легко тестируется)."""
import math
import time
from collections.abc import Mapping, Sequence

from jobs.engine import format_duration, format_money, paginate  # noqa: F401 (paginate реэкспортируется)

from .catalog import (
    CATEGORIES,
    CATEGORIES_BY_KEY,
    ITEMS_BY_CATEGORY,
    ITEMS_BY_KEY,
    TRANSPORT_CATEGORIES,
    Category,
    Item,
)

# Сколько предметов показывается на одной странице
PAGE_SIZE = 6

# Значения payload, которые заняты навигацией и не могут быть ключами предметов или категорий
RESERVED_CHOICES = frozenset({'back', 'prev_page', 'next_page', 'buy', 'collect', 'refresh'})


def now_ts() -> int:
    """Текущее время, секунды Unix."""
    return int(time.time())


# --- Доход бизнесов ---

def accrued_income(income_per_hour: int, collected_at: int, now: int) -> int:
    """Сколько накопил бизнес с момента последнего сбора (целые доллары, округление вниз)."""
    seconds = max(0, now - collected_at)
    return income_per_hour * seconds // 3600


def payback_hours(item: Item) -> int:
    """За сколько часов бизнес окупится (округление вверх)."""
    return math.ceil(item.price / item.income_per_hour)


# --- Тексты ---

def format_category_page(
        category: Category,
        page_items: Sequence[Item],
        owned: Mapping[str, int],
        page: int,
        total_pages: int
) -> str:
    lines = [
        f'{category.emoji} {category.title} | Страница {page + 1} из {total_pages}',
        category.intro,
        '',
    ]
    for item in page_items:
        mark = ' ✅ куплено' if item.key in owned else ''
        lines.append(f'{item.emoji} {item.title} - {format_money(item.price)}{mark}')
        lines.append(item.description)
        if item.income_per_hour:
            lines.append(f'📈 Доход: {format_money(item.income_per_hour)} в час')
        lines.append('')
    lines.append('Выберите вариант с помощью кнопок 👇')
    return '\n'.join(lines)


def format_item_details(item: Item, balance: int, is_owned: bool) -> str:
    lines = [f'{item.emoji} {item.title}', item.description, '']
    lines.append(f'💵 Цена: {format_money(item.price)}')
    if item.income_per_hour:
        lines.append(f'📈 Доход: {format_money(item.income_per_hour)} в час')
        lines.append(f'⏳ Окупится примерно за {format_duration(payback_hours(item) * 3600)}')
    lines.append(f'💳 Ваш баланс: {format_money(balance)}')
    lines.append('')
    if is_owned:
        lines.append('✅ Это у вас уже есть')
    elif balance < item.price:
        lines.append(f'❗ Не хватает {format_money(item.price - balance)}')
    return '\n'.join(lines).rstrip('\n')


def format_transport_menu(owned: Mapping[str, int]) -> str:
    lines = ['🚗 Транспорт', 'Выберите, что хотите купить:', '']
    for key in TRANSPORT_CATEGORIES:
        category = CATEGORIES_BY_KEY[key]
        items = ITEMS_BY_CATEGORY[key]
        have = sum(1 for item in items if item.key in owned)
        lines.append(f'{category.emoji} {category.title} - {len(items)} моделей (у вас: {have})')
    return '\n'.join(lines)


def total_value(owned: Mapping[str, int]) -> int:
    return sum(ITEMS_BY_KEY[key].price for key in owned if key in ITEMS_BY_KEY)


def total_accrued(owned: Mapping[str, int], now: int) -> int:
    """Сколько всего накоплено доходов со всех бизнесов."""
    return sum(
        accrued_income(ITEMS_BY_KEY[key].income_per_hour, collected_at, now)
        for key, collected_at in owned.items()
        if key in ITEMS_BY_KEY and ITEMS_BY_KEY[key].income_per_hour
    )


def format_inventory(owned: Mapping[str, int], now: int) -> str:
    """owned: {ключ предмета: время последнего сбора дохода}."""
    owned = {key: ts for key, ts in owned.items() if key in ITEMS_BY_KEY}
    if not owned:
        return (
            '🎒 Моё имущество\n\n'
            'У вас пока ничего нет.\n'
            'Загляните в магазин: 🏢 Бизнесы, 🏠 Дома, 🚗 Транспорт'
        )

    lines = ['🎒 Моё имущество', f'💎 Общая стоимость: {format_money(total_value(owned))}', '']

    for category in CATEGORIES:
        items = [item for item in ITEMS_BY_CATEGORY[category.key] if item.key in owned]
        if not items:
            continue
        lines.append(f'{category.emoji} {category.title}:')
        for item in items:
            if item.income_per_hour:
                accrued = accrued_income(item.income_per_hour, owned[item.key], now)
                lines.append(
                    f'{item.emoji} {item.title} - накоплено {format_money(accrued)} '
                    f'({format_money(item.income_per_hour)}/ч)'
                )
            else:
                lines.append(f'{item.emoji} {item.title}')
        lines.append('')

    income_per_hour = sum(
        ITEMS_BY_KEY[key].income_per_hour for key in owned if ITEMS_BY_KEY[key].income_per_hour
    )
    if income_per_hour:
        lines.append(f'📈 Доход бизнесов: {format_money(income_per_hour)} в час')
        lines.append(f'💰 Готово к сбору: {format_money(total_accrued(owned, now))}')

    return '\n'.join(lines).rstrip('\n')
