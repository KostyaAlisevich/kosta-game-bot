from tortoise import Model, fields


class OwnedItem(Model):
    """Предмет из магазина имущества, которым владеет пользователь (каждый предмет - максимум один раз)."""
    user = fields.ForeignKeyField('models.UserModel', on_delete='CASCADE', related_name='owned_items')
    item_key = fields.CharField(max_length=32)
    # Время в секундах Unix. Целые числа, чтобы их можно было точно сравнивать в UPDATE ... WHERE
    purchased_at = fields.BigIntField()
    # До какого момента бизнес уже выплатил доход (для предметов без дохода не используется)
    collected_at = fields.BigIntField()

    class Meta:
        table = 'owned_items'
        unique_together = (('user', 'item_key'),)
