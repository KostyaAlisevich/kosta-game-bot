from vkbottle.bot import Message
from vkbottle.framework.labeler import BotLabeler
from vkbottle.modules import json

from core.loader import bot
from menu.handlers import show_shop_menu
from users.models import UserModel
from users.utils import get_user_balance
from .catalog import (
    CATEGORIES_BY_KEY,
    ITEMS_BY_CATEGORY,
    ITEMS_BY_KEY,
    TRANSPORT_CATEGORIES,
    Item,
)
from .engine import (
    PAGE_SIZE,
    format_category_page,
    format_inventory,
    format_item_details,
    format_money,
    format_transport_menu,
    now_ts,
    paginate,
)
from .keyboards import (
    build_category_keyboard,
    build_inventory_keyboard,
    build_item_keyboard,
    build_transport_keyboard,
)
from .service import buy_item, collect_income, get_owned
from .states import PropertyShopState

bl = BotLabeler()

INVALID_INPUT = '❗ Некорректный ввод! Выберите вариант с помощью кнопок\n\n'


def get_choice(message: Message):
    """Достаёт значение 'choice' из payload нажатой кнопки (или None)."""
    if not message.payload:
        return None
    payload = json.loads(message.payload)
    return payload.get('choice') if isinstance(payload, dict) else None


# ---------------------------------------------------------------------------
# Экраны
# ---------------------------------------------------------------------------

async def show_transport_menu(message: Message, intro: str = ''):
    user = await UserModel.get(vk_id=message.from_id)
    owned = await get_owned(user.pk)
    await message.answer(
        intro + format_transport_menu(owned),
        keyboard=build_transport_keyboard()
    )
    await bot.state_dispenser.set(message.from_id, PropertyShopState.TRANSPORT)


async def show_category(message: Message, category_key: str, page: int = 0, intro: str = ''):
    user = await UserModel.get(vk_id=message.from_id)
    owned = await get_owned(user.pk)

    page_items, page, total_pages = paginate(ITEMS_BY_CATEGORY[category_key], page, PAGE_SIZE)
    await message.answer(
        intro + format_category_page(CATEGORIES_BY_KEY[category_key], page_items, owned, page, total_pages),
        keyboard=build_category_keyboard(page_items, owned, page, total_pages)
    )
    await bot.state_dispenser.set(
        message.from_id, PropertyShopState.CATEGORY, category=category_key, page=page
    )


async def show_item(message: Message, item: Item, page: int, intro: str = ''):
    user = await UserModel.get(vk_id=message.from_id)
    is_owned = item.key in await get_owned(user.pk)
    await message.answer(
        intro + format_item_details(item, user.balance, is_owned),
        keyboard=build_item_keyboard(item, is_owned)
    )
    await bot.state_dispenser.set(
        message.from_id, PropertyShopState.ITEM,
        category=item.category, page=page, item_key=item.key
    )


async def show_inventory(message: Message, intro: str = ''):
    user = await UserModel.get(vk_id=message.from_id)
    owned = await get_owned(user.pk)
    has_business = any(ITEMS_BY_KEY[key].income_per_hour for key in owned)
    await message.answer(
        intro + format_inventory(owned, now_ts()),
        keyboard=build_inventory_keyboard(has_business)
    )
    await bot.state_dispenser.set(message.from_id, PropertyShopState.INVENTORY)


# ---------------------------------------------------------------------------
# Вход из меню магазина
# ---------------------------------------------------------------------------

@bl.private_message(payload={'shop_menu': 'business'})
async def open_business_shop(message: Message):
    await show_category(message, 'business')


@bl.private_message(payload={'shop_menu': 'house'})
async def open_house_shop(message: Message):
    await show_category(message, 'house')


@bl.private_message(payload={'shop_menu': 'transport'})
async def open_transport_menu(message: Message):
    await show_transport_menu(message)


@bl.private_message(payload={'shop_menu': 'property'})
async def open_inventory(message: Message):
    await show_inventory(message)


# ---------------------------------------------------------------------------
# Навигация по состояниям
# ---------------------------------------------------------------------------

@bl.private_message(state=PropertyShopState.TRANSPORT)
async def choose_transport_category(message: Message):
    choice = get_choice(message)
    if choice == 'back':
        await bot.state_dispenser.delete(message.from_id)
        return await show_shop_menu(message)
    if isinstance(choice, str) and choice in TRANSPORT_CATEGORIES:
        return await show_category(message, choice)
    await show_transport_menu(message, intro=INVALID_INPUT)


@bl.private_message(state=PropertyShopState.CATEGORY)
async def browse_category(message: Message):
    state_payload = message.state_peer.payload
    category, page = state_payload['category'], state_payload['page']
    choice = get_choice(message)

    if choice == 'back':
        if category in TRANSPORT_CATEGORIES:
            return await show_transport_menu(message)
        await bot.state_dispenser.delete(message.from_id)
        return await show_shop_menu(message)
    if choice == 'prev_page':
        return await show_category(message, category, page - 1)
    if choice == 'next_page':
        return await show_category(message, category, page + 1)

    item = ITEMS_BY_KEY.get(choice) if isinstance(choice, str) else None
    if item is None or item.category != category:
        return await show_category(message, category, page, intro=INVALID_INPUT)
    await show_item(message, item, page)


@bl.private_message(state=PropertyShopState.ITEM)
async def item_screen(message: Message):
    state_payload = message.state_peer.payload
    item, page = ITEMS_BY_KEY[state_payload['item_key']], state_payload['page']
    choice = get_choice(message)

    if choice == 'back':
        return await show_category(message, item.category, page)
    if choice == 'buy':
        return await purchase(message, item, page)
    await show_item(message, item, page, intro=INVALID_INPUT)


async def purchase(message: Message, item: Item, page: int):
    user = await UserModel.get(vk_id=message.from_id)
    status = await buy_item(user.pk, item)

    if status == 'ok':
        text = f'🥳 Вы приобрели {item.emoji} {item.title} за {format_money(item.price)}!\n'
        if item.income_per_hour:
            text += 'Доход копится каждый час, забирайте его в «🎒 Моё имущество».\n'
        await show_category(message, item.category, page, intro=text + '\n')
    elif status == 'already':
        await show_item(message, item, page, intro='❗ Это у вас уже есть!\n\n')
    else:
        balance = await get_user_balance(message.from_id)
        await show_item(
            message, item, page,
            intro=f'❗ У вас недостаточно средств! Не хватает {format_money(item.price - balance)}\n\n'
        )


@bl.private_message(state=PropertyShopState.INVENTORY)
async def inventory_screen(message: Message):
    choice = get_choice(message)

    if choice == 'back':
        await bot.state_dispenser.delete(message.from_id)
        return await show_shop_menu(message)
    if choice == 'refresh':
        return await show_inventory(message)
    if choice == 'collect':
        user = await UserModel.get(vk_id=message.from_id)
        collected = await collect_income(user.pk)
        if collected:
            balance = await get_user_balance(message.from_id)
            intro = f'💰 Собрано {format_money(collected)}! Баланс: {format_money(balance)}\n\n'
        else:
            intro = '😕 Пока нечего собирать, доход ещё не накопился\n\n'
        return await show_inventory(message, intro=intro)
    await show_inventory(message, intro=INVALID_INPUT)
